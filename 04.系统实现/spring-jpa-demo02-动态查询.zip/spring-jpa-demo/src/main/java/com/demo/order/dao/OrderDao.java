package com.demo.order.dao;

//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort;

//import org.springframework.data.repository.Repository;
//import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.lang.Nullable;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.demo.order.domain.Order;

@Repository
public interface OrderDao extends 
		PagingAndSortingRepository<Order,Long>,JpaSpecificationExecutor<Order>
{
	//1.JPA通过解析方法名创建查询
	public List<Order> findByCodeAndTel(String code,String tel);
	//2.使用 @Query 创建查询
	//@Query("from Order o where o.code = ?1 and o.tel = ?2")//HQL
	@Query(value="select * from t_order o where o.code = ?1 and o.tel = ?2" ,nativeQuery=true)//SQL
	public List<Order> findMethod(String code,String tel);
	//@Query("from Order o where o.code = :code and o.tel = :tel")
	//public List<Order> findMethod2(@Param("code")String code,@Param("tel")String tel);
	
	//3.修改或删除数据 @Modifying 
	@Modifying 
	@Query("update Order o set o.code = ?1 where o.id = ?2")
	public int updateOrder(String code,Long id); 


//	CrudRepository接口：
//	<S extends T> S save(S entity);
//	<S extends T> Iterable<S> saveAll(Iterable<S> entities);
	
//	Optional<T> findById(ID id);
//	boolean existsById(ID id);
	
//	Iterable<T> findAll();
//	Iterable<T> findAllById(Iterable<ID> ids);
	
//	long count();
//	void deleteById(ID id);
//	void delete(T entity);
//	void deleteAll(Iterable<? extends T> entities);
//	void deleteAll();

//	PagingAndSortingRepository extends CrudRepository接口：
//	Iterable<T> findAll(Sort sort);
//	Page<T> findAll(Pageable pageable);
	
	
//	3.动态查询接口JpaSpecificationExecutor		Specification查询条件组
//	Optional<T> findOne(@Nullable Specification<T> spec);
//	List<T> findAll(@Nullable Specification<T> spec);
//	Page<T> findAll(@Nullable Specification<T> spec, Pageable pageable);
//	List<T> findAll(@Nullable Specification<T> spec, Sort sort);
//	long count(@Nullable Specification<T> spec);
}
