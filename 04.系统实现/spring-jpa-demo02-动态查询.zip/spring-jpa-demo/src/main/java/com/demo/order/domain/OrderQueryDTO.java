package com.demo.order.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;
/**
 * 查询条件封装对象
 * 1.接收前端查询条件  setter
 * 2.生成动态的查询条件组Specification
 * @author Benjuming_Lin
 *
 */
public class OrderQueryDTO 
{
	private String code;
	private String tel;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	
	public static Specification<Order> getSpecification(OrderQueryDTO queryDto) {
		return new Specification<Order>() {
			public Predicate toPredicate(Root<Order> root, CriteriaQuery<?> query, CriteriaBuilder cb) 
			{
				List<Predicate> predicates = new ArrayList<Predicate>();
				
				if(queryDto.getCode()!=null && !queryDto.getCode().trim().equals("")) {
					Predicate p1=cb.like(root.get("code").as(String.class), "%"+queryDto.getCode()+"%");
					predicates.add(p1);
				}
				if(queryDto.getTel()!=null && !queryDto.getTel().trim().equals("")) {
					Predicate p2=cb.like(root.get("tel").as(String.class), "%"+queryDto.getTel()+"%");
					predicates.add(p2);
				}
				return cb.and(predicates.toArray(new Predicate[predicates.size()]));
			}
		};
	}
	
}
