package com.demo.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.order.dao.OrderDao;
import com.demo.order.domain.Order;

@Service
@Transactional(readOnly=true)
public class OrderService implements IOrderService 
{
	@Autowired
	private OrderDao orderDao;
	
	@Transactional
	public void save(Order entity) {
		orderDao.save(entity);
	}

	@Transactional
	public void saveAll(List<Order> entities) {
		orderDao.saveAll(entities);

	}

	public Order findById(Long id) {
		return orderDao.findById(id).get();
	}

	public boolean existsById(Long id) {
		return orderDao.existsById(id);
	}

	public List<Order> findAll() {
		return (List<Order>) orderDao.findAll();
	}

	public List<Order> findAllById(List<Long> ids) {
		return (List<Order>) orderDao.findAllById(ids);
	}

	public long count() {
		return orderDao.count();
	}

	@Transactional
	public void deleteById(Long id) {
		orderDao.deleteById(id);

	}

	@Transactional
	public void delete(Order entity) {
		orderDao.delete(entity);
	}

	@Transactional
	public void deleteAll(List<Order> entities) {
		orderDao.deleteAll(entities);

	}

	@Transactional
	public void deleteAll() {
		orderDao.deleteAll();

	}

	public List<Order> findAll(Sort sort) {
		return (List<Order>) orderDao.findAll(sort);
	}

	public Page<Order> findAll(Pageable pageable) {
		return orderDao.findAll(pageable);
	}

	@Override
	public List<Order> findByCodeAndTel(String code, String tel) {
		
		return orderDao.findByCodeAndTel(code, tel);
	}
	@Override
	public List<Order> findMethod(String code, String tel) {
		
		return orderDao.findMethod(code, tel);
	}

	@Transactional
	public int updateOrder(String code, Long id) {
		
		return orderDao.updateOrder(code, id);
	}

	@Override
	public Page<Order> findAll(Specification<Order> spec, Pageable pageable) {
		return orderDao.findAll(spec, pageable);
	}

}
