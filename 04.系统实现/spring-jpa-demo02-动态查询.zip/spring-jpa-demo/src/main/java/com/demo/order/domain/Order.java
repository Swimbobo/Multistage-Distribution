package com.demo.order.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
/*
 * 
 * 1.私有的属性
 * 2.公共的getter和setter
 */
@Entity
@Table(name="t_order")
public class Order 
{
	private Long id;
	private String code;
	private String tel;
	private Date date;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}
	
	public   String getCode() {
		return code;
	}
	
	public String getTel() {
		return tel;
	}
	
	public Date getDate() {
		return date;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", code=" + code + ", tel=" + tel + ", date=" + date + "]";
	}
	
}
