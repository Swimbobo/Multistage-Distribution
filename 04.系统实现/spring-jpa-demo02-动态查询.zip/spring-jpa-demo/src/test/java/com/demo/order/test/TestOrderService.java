package com.demo.order.test;


import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;

import com.demo.order.domain.Order;
import com.demo.order.domain.OrderQueryDTO;
import com.demo.order.service.IOrderService;


public class TestOrderService 
{
	private  IOrderService orderService;
	
	@Before //在测试方法运行之前运行
	public void beforeTest() {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		orderService =context.getBean("orderService", IOrderService.class);
	}


	@Test
	public void testData() {
		for (int i = 1; i <= 1000; i++) {
			Order order = new Order();
			order.setCode("Code:"+i);
			order.setDate(new Date());
			order.setTel("X-999110-222");
			
			orderService.save(order);
		}
	}
	
	@Test
	public void testFindByCodeAndTel() {
		
			
		List<Order> orders= orderService.findByCodeAndTel("Code:989", "X-999110-222");
		
		for (Order order : orders) {
			System.out.println(order);
		}
	}
	
	@Test
	public void testFindMethod() {
		List<Order> orders= orderService.findMethod("Code:989", "X-999110-222");
		
		for (Order order : orders) {
			System.out.println(order);
		}
	}
	
	@Test
	public void testUpdateOrder() {
		orderService.updateOrder("9999999999999", 1001L);
	}
	
	@Test
	public void testFindPage() 
	{
		int page = 1;
		int size = 20;
		
		//Pageable pageable =  PageRequest.of(page-1, size);
		
		//Sort sort = Sort.by(Direction.DESC, "id").and( Sort.by(Direction.ASC, "code"));
		//Pageable pageable =  PageRequest.of(page-1, size,sort);
		
		Pageable pageable =  PageRequest.of(page-1, size, Direction.DESC, "id");
		
		Page<Order> orderPage = orderService.findAll(pageable);
		
		System.out.println("Number第几页:"+orderPage.getNumber());
		System.out.println("NumberOfElements当前页有多少条记录:"+orderPage.getNumberOfElements());
		System.out.println("Size每页多少条记录:"+orderPage.getSize());
		System.out.println("TotalElements总记录数:"+orderPage.getTotalElements());
		System.out.println("TotalPages总页数:"+orderPage.getTotalPages());
		System.out.println("Pageable分页条件对象:"+orderPage.getPageable());
		System.out.println("Sort排序对象:"+orderPage.getSort());

		for (Order order : orderPage.getContent()) {
			System.out.println(order);
		}
	}
	
	
	@Test
	public void testFindPageBySpecification() 
	{
		
		//OrderQueryDTO
		OrderQueryDTO queryDto = new OrderQueryDTO();
		queryDto.setCode("Code:98");
		queryDto.setTel("");

		int page = 1;
		int size = 20;
		
		//Pageable pageable =  PageRequest.of(page-1, size);
		
		//Sort sort = Sort.by(Direction.DESC, "id").and( Sort.by(Direction.ASC, "code"));
		//Pageable pageable =  PageRequest.of(page-1, size,sort);
		
		Pageable pageable =  PageRequest.of(page-1, size, Direction.DESC, "id");
		
		Page<Order> orderPage = orderService.findAll(OrderQueryDTO.getSpecification(queryDto),pageable);
		
		System.out.println("Number第几页:"+orderPage.getNumber());
		System.out.println("NumberOfElements当前页有多少条记录:"+orderPage.getNumberOfElements());
		System.out.println("Size每页多少条记录:"+orderPage.getSize());
		System.out.println("TotalElements总记录数:"+orderPage.getTotalElements());
		System.out.println("TotalPages总页数:"+orderPage.getTotalPages());
		System.out.println("Pageable分页条件对象:"+orderPage.getPageable());
		System.out.println("Sort排序对象:"+orderPage.getSort());

		for (Order order : orderPage.getContent()) {
			System.out.println(order);
		}
	}
	
}
