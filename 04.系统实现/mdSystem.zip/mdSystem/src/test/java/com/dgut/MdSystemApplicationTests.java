package com.dgut;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dgut.test.domain.User;
import com.dgut.test.service.IUserService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MdSystemApplicationTests {

	
	@Autowired
	private IUserService iUserService;
	
	@Test
	public void contextLoads() {
	}
	
	@Test // 测试方法
	public void testSave() {
		System.out.println("123");
		User user=new User();
		user.setId(8L);
		user.setUsername("开心的我");
		user.setPassword("123456");

		iUserService.save(user);

	}

}
