package com.dgut.headquarters.admin.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name ="t_head_admin")
public class Admin {

	private Long managerId;//管理员ID
	private String userName;//	管理员账号
	private String password;//管理员密码
	private String manager_name;//管理员姓名
	private String manager_phone;//管理员手机
	private Date create_time;//创建时间
	private int status;//状态
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getManagerId() {
		return managerId;
	}
	@NotNull
	public String getUserName() {
		return userName;
	}

	@NotNull
	public String getPassword() {
		return password;
	}
	public String getManager_name() {
		return manager_name;
	}

	public String getManager_phone() {
		return manager_phone;
	}
	
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
	public Date getCreate_time() {
		return create_time;
	}
	
	@Column(length = 1)
	public int getStatus() {
		return status;
	}
	public void setManagerId(Long managerId) {
		this.managerId = managerId;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setManager_name(String manager_name) {
		this.manager_name = manager_name;
	}
	public void setManager_phone(String manager_phone) {
		this.manager_phone = manager_phone;
	}
	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	
	
}
