package com.dgut.test.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.dgut.commonPackage.BaseDomain;

@Entity
@Table(name = "t_user")
public class User extends BaseDomain<Long>{
		
	private Long id;
	private String username;
	private String password;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}
	@Column(unique = true, nullable = false)
	@NotNull
	public String getUsername() {
		return username;
	}
	@NotNull
	public String getPassword() {
		return password;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	
}
