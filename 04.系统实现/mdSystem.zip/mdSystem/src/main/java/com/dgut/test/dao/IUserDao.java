package com.dgut.test.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.dgut.test.domain.User;

@Repository
public interface IUserDao extends PagingAndSortingRepository<User, Long> ,JpaSpecificationExecutor<User>{

}
