package com.dgut.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dgut.test.dao.IUserDao;
import com.dgut.test.domain.User;

@Service
@Transactional
public class UserService implements IUserService{

	@Autowired
	private IUserDao iuserdao;
	@Override
	public void save(User user) {
		// TODO Auto-generated method stub
		iuserdao.save(user);
	}

	@Override
	public User findById(Long id) {
		// TODO Auto-generated method stub
		return iuserdao.findById(id).get();
	}

	@Override
	public boolean existsById(Long Long) {
		// TODO Auto-generated method stub
		return iuserdao.existsById(Long);
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return (List<User>) iuserdao.findAll();
	}

	@Override
	public List<User> findAllById(List<Long> ids) {
		// TODO Auto-generated method stub
		return (List<User>) iuserdao.findAllById(ids);
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return iuserdao.count();
	}

	@Override
	public void deleteById(Long Long) {
		// TODO Auto-generated method stub
		iuserdao.deleteById(Long);
	}

	@Override
	public void delete(User entity) {
		// TODO Auto-generated method stub
		iuserdao.delete(entity);
	}

	@Override
	public void deleteAll(List<? extends User> entities) {
		// TODO Auto-generated method stub
		iuserdao.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		iuserdao.deleteAll();
	}

}
