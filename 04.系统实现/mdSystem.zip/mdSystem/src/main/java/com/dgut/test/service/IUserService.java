package com.dgut.test.service;

import java.util.List;

import com.dgut.test.domain.User;

public interface IUserService {
	
	public void save(User user);
	
	public User findById(Long id);
	public boolean existsById(Long Long);
	public List<User> findAll();
	public List<User> findAllById(List<Long> ids);
	
	public long count();
	public void deleteById(Long Long);
	public void delete(User entity);
	public void deleteAll(List<? extends User> entities);
	public void deleteAll();
	
}
