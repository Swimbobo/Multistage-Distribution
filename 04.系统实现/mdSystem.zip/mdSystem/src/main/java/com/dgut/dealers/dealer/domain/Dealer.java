package com.dgut.dealers.dealer.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import com.dgut.commonPackage.BaseDomain;
import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "t__dealer")
public class Dealer extends BaseDomain<Long>{


	//经销商ID，主键，不为空，自增，用于删查改
	private String dealerId;
	//经销商姓名，确认身份
	private String dealerName;
	//经销商电话，取得联系
	private String dealerPhone;
	
	//上级ID，该经销商的上级，有可能是总部管理员有可能是上级经销商
	private String parentId;
	//授权码
	private String	 authorizationCode;
	//微信号
	private String openId;
	//创建时间
	private Date createTime;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public String getDealerId() {
		return dealerId;
	}
	@NotNull
	public String getDealerName() {
		return dealerName;
	}
	
	public String getDealerPhone() {
		return dealerPhone;
	}
	public String getParentId() {
		return parentId;
	}
	@NotNull
	public String getAuthorizationCode() {
		return authorizationCode;
	}
	
	@Column(unique = true, nullable = false)
	@NotNull
	public String getOpenId() {
		return openId;
	}
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
	public Date getCreateTime() {
		return createTime;
	}
	
	
	
	
	public void setDealerId(String dealerId) {
		this.dealerId = dealerId;
	}
	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}
	public void setDealerPhone(String dealerPhone) {
		this.dealerPhone = dealerPhone;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public void setAuthorizationCode(String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}
	public void setOpenId(String openId) {
		this.openId = openId;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	
	
}
