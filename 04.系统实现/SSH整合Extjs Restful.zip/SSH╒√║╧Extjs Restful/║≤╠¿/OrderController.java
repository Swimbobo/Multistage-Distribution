package com.example.demo.order.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.common.beans.BeanUtils;
import com.example.demo.common.web.ExtAjaxResponse;
import com.example.demo.common.web.ExtjsPageRequest;
import com.example.demo.order.domain.Order;
import com.example.demo.order.domain.OrderQueryDTO;
import com.example.demo.order.service.IOrderService;

@RestController
@RequestMapping("/order")
public class OrderController 
{
	@Autowired
	private IOrderService orderService;
	
	@GetMapping
	public Page<Order> getPage(OrderQueryDTO orderQueryDTO , ExtjsPageRequest pageRequest) 
	{
		return orderService.findAll(OrderQueryDTO.getWhereClause(orderQueryDTO), pageRequest.getPageable());
	}
	
	@GetMapping(value="{id}")
	public Order getOne(@PathVariable("id") Long id) 
	{
		return orderService.findById(id).get();
	}

	@DeleteMapping(value="{id}")
	public ExtAjaxResponse delete(@PathVariable("id") Long id) 
	{
		try {
			if(id!=null) {
				orderService.deleteById(id);
			}
			return new ExtAjaxResponse(true,"删除成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"删除失败！");
		}
	}
	
	@PostMapping("/deletes")
	public ExtAjaxResponse deleteRows(@RequestParam(name="ids") Long[] ids) 
	{
		try {
			if(ids!=null) {
				orderService.deleteAll(ids);
			}
			return new ExtAjaxResponse(true,"批量删除成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"批量删除失败！");
		}
	}
	
	
	@PutMapping(value="{id}",consumes=MediaType.APPLICATION_JSON_VALUE)
	public ExtAjaxResponse update(@PathVariable("id") Long myId,@RequestBody Order dto) 
	{
		try {
			Order entity = orderService.findById(myId).get();
			if(entity!=null) {
				BeanUtils.copyProperties(dto, entity);//使用自定义的BeanUtils
				orderService.save(entity);
			}
			return new ExtAjaxResponse(true,"更新成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"更新失败！");
		}
	}
	
	@PostMapping(consumes=MediaType.APPLICATION_JSON_VALUE)
	public ExtAjaxResponse save(@RequestBody Order order) 
	{
		try {
			orderService.save(order);
			return new ExtAjaxResponse(true,"保存成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"保存失败！");
		}
	}
	
	
//	/**
//	 * 测试数据
//	 */
//	@RequestMapping("/data")
//	public String testData() {
//		try {
//			for (int i = 0; i < 100; i++) {
//				Order order = new Order();
//				order.setOrderNumber(i+"");
//				order.setCreateTime(new Date());
//				
//				orderService.save(order);
//			}
//			return "success:true";
//		} catch (Exception e) {
//			return "success:false";
//		}
//	}
	
	
}
