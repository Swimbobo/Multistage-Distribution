package com.hrs.zhanshiyang.test;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestRecordService 
{
	@Autowired
	private IRecordService recordService;
	
	@Test
	public void testData() {
		for (int i = 0; i < 100; i++) {
			RecordDTO dto = new RecordDTO();
			dto.setEmployeeId("000"+i);
			dto.setRecordTime(new Date());
			dto.setRecordContent("批量删除");
			recordService.save(dto);
		}
	}
	

}
