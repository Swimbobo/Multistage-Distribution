package com.hrs.zhanshiyang.test;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.zhanshiyang.template.domain.TemplateDTO;
import com.hrs.zhanshiyang.template.service.ITemplateService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestTemplateService 
{
	@Autowired
	private ITemplateService templateService;
	
	@Test
	public void testSave() {
		for (int i = 0; i < 100; i++) {
			TemplateDTO dto = new TemplateDTO();
			dto.setTemplateHead("12月份奖金");
			dto.setTemplateTimeStart(new Date());
			dto.setTemplateTimeEnd(new Date());
			templateService.save(dto);
		}
	}
	
	@Test
	public void testFindById() {
		TemplateDTO template = new TemplateDTO();
		template = templateService.findById(4L);
		System.out.println(template);
	}
	
	@Test
	public void testDeleteById() {
		templateService.deleteById(40L);
	}
}
