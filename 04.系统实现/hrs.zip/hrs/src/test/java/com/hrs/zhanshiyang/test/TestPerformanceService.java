package com.hrs.zhanshiyang.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.zhanshiyang.performance.domain.PerformanceDTO;
import com.hrs.zhanshiyang.performance.service.IPerformanceService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestPerformanceService 
{
	@Autowired
	private IPerformanceService performanceService;
	
	
	@Test
	@Rollback(value=true)
	public void testData() {
		
		for (Long i = 1L; i < 100; i++) {
			PerformanceDTO dto = new PerformanceDTO();
			dto.setEmployeeId("000"+i);
//			dto.setPerformanceFractionView("60");
			dto.setPerformanceContent("2018年总绩效");
			dto.setPerformanceStatus(true);
			dto.setPerformanceAssessName("Yang");
			dto.setPerformanceStaffName("James");
			dto.setTemplateId(85L);
			performanceService.save(dto);
		}
	}
	
	@Test
	public void testFindAll() {
//		List<PerformanceDTO> dtoLists = performanceService.findAll();
//		for (PerformanceDTO dto : dtoLists) {
//			System.out.println(dto);
//		}
	}
}
