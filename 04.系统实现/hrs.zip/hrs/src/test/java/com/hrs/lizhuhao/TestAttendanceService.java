package com.hrs.lizhuhao;

import java.util.Date;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.hrs.lizhuhao.attendance.domain.AttendanceDTO;
import com.hrs.lizhuhao.attendance.service.IAttendanceService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestAttendanceService {
@Autowired
private  IAttendanceService attendanceService;
	@Test
	public void testData() {
		for (int i = 1; i <= 10; i++) {
			AttendanceDTO attendance = new AttendanceDTO();
			attendance.setEmployeeId("201541402111");
			attendance.setEmployeeName("Alice");
//			attendance.setAttendanceTime(new Date());			
			attendance.setAttendanceStatus("出勤");	
			attendanceService.save(attendance);		
		}
	}
	//@Test
//	public void testFindById() {
//		AttendanceDTO attendance=new AttendanceDTO();
//		attendance=attendanceService.findById(1L);
//		if(attendance!=null)
//		{
//			attendance.setEmployeeId("BBBBBBBB");
//			attendanceService.save(attendance);
//			System.out.println("员工ID："+attendance.getEmployeeId());
//			System.out.println("上午上班时间： "+attendance.getAttendanceAgetTime());
//			System.out.println("上午下班时间： "+attendance.getAttendanceAoutTime());
//			System.out.println("下午上班时间： "+attendance.getAttendanceMgetTime());
//			System.out.println("下午下班时间： "+attendance.getAttendanceMoutTime());
//			System.out.println("出勤状态： "+attendance.getAttendanceState());
//		}
//	}
//	@Test
//	public void deleteById() {
//		attendanceService.deleteById(2L);
//	}
//	
//	@Test
//	public void existsById() {
//		boolean res=attendanceService.existsById(2L);
//		System.out.println(res);
//	}
//	
//	@Test
//	public void count() {
//		System.out.println(attendanceService.count());
//	}
//	
	
}
