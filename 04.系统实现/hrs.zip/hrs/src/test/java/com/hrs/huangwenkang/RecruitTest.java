package com.hrs.huangwenkang;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.huangwenkang.recruit.domain.RecruitDTO;
import com.hrs.huangwenkang.recruit.service.IRecruitService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RecruitTest {
	@Autowired
	private IRecruitService recruitService;
	//增加对象
	@Test
	public void save() {
		for (int i = 0; i < 10; i++) {
			RecruitDTO recruit = new RecruitDTO();
			recruit.setRecruitJob("1");
			recruit.setRecruitNumber1("2");
			recruit.setRecruitRequirement("你好");
			//recruit.setRecruitTreatment("222");
			//recruit.setRecruitAbout("喜洋洋公司");
			recruitService.save(recruit);
		}
	}
	//删除对象
	@Test
	public void deleteById() {
		recruitService.deleteById(2L);
	}
	//查找对象
	@Test
	public void findById() {
		RecruitDTO recruit = recruitService.findById(3L);
		System.out.println(recruit);
	}
	//是否存在对象
	@Test
	public void existsById() {
		boolean res=recruitService.existsById(4L);
		System.out.println(res);
	}
	//求总数
	@Test
	public void count() {
		System.out.println(recruitService.count());
	}
}