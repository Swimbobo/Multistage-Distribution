package com.hrs.zhanshiyang.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.zhanshiyang.log.domain.LogDTO;
import com.hrs.zhanshiyang.log.service.ILogService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestLogService 
{
	@Autowired
	private ILogService logService;
	
	@Test
	public void testData() {
		for (int i = 0; i < 100; i++) {
			LogDTO dto = new LogDTO();
			dto.setEmployeeId("admin");
			logService.save(dto);
		}
	}
	
	@Test
	public void testFindById() {
		LogDTO dto = new LogDTO();
		dto = logService.findById(5L);
		System.out.println(dto);
	}
	
	@Test
	public void testDeleteById() {
		logService.deleteById(60L);
	}
}
