package com.hrs.huangwenkang;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.huangwenkang.entry.domain.EntryDTO;
import com.hrs.huangwenkang.entry.service.IEntryService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EntryTest {
	@Autowired
	private IEntryService entryService;
	
	//增加对象
	@Test
	public void save() {
		for (int i = 0; i < 10; i++) {
			EntryDTO entry = new EntryDTO();
			Date date=new Date();
			entry.setInterviewId1("2");
			entry.setResumeId1("2");
			entry.setEntryName("2");
			entry.setEntrySex("2");
			entry.setEntrybranch("2");
			entry.setEntryposition("2");
			entry.setEntryTel("2");
			entry.setEntryExpectedEntryDate(date);
			entry.setEntryConfirmedEntryDate(date);
			entryService.save(entry);
		}
	}
	//删除对象
	@Test
	public void deleteById() {
		entryService.deleteById(2L);
	}
	
	//查找对象
	@Test
	public void findById() {
		EntryDTO entry = entryService.findById(3L);
		System.out.println(entry);
	}
	//是否存在对象
	@Test
	public void existsById() {
		boolean res=entryService.existsById(2L);
		System.out.println(res);
	}
	//求总数
	@Test
	public void count() {
		System.out.println(entryService.count());
	}
}