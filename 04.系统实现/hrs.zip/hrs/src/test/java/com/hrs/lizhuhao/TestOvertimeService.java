package com.hrs.lizhuhao;
import java.util.Date;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.hrs.lizhuhao.overtime.domain.OvertimeDTO;
import com.hrs.lizhuhao.overtime.service.IOvertimeService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestOvertimeService {
@Autowired
private  IOvertimeService overtimeService;
	@Test
	public void testData() {
		for (int i = 1; i <= 100; i++) {
			OvertimeDTO overtime = new OvertimeDTO();
			//position.setId(i);
			if(i<10) {
				overtime.setEmployeeId("20154140200"+i);
		    }else if (i==100) {
		    	overtime.setEmployeeId("201541402100");
			}else {
				overtime.setEmployeeId("2015414020"+i);
			} 
			overtime.setEmployeeName("Jax");
//			overtime.setOvertimeStartTime(new Date());
//			overtime.setOvertimeEndTime(new Date());
			overtimeService.save(overtime);
		}
	}
	@Test
	public void testData2() {
		for (int i = 1; i <= 10; i++) {
			OvertimeDTO overtime = new OvertimeDTO();
			//position.setId(i);
			
			overtime.setEmployeeId("201541402111");
		   
			overtime.setEmployeeName("Tony");
//			overtime.setOvertimeStartTime(new Date());
//			overtime.setOvertimeEndTime(new Date());
			overtimeService.save(overtime);
		}
	}
	@Test
	public void testFindById() {
		OvertimeDTO overtime=new OvertimeDTO();
		overtime=overtimeService.findById(1L);
		if(overtime!=null)
		{
			overtime.setEmployeeId("BBBBBBBB");
			overtimeService.save(overtime);
			System.out.println("员工ID："+overtime.getEmployeeId());
//			System.out.println("加班开始时间： "+overtime.getOvertimeStartTime());
//			System.out.println("加班下班时间： "+overtime.getOvertimeEndTime());
			System.out.println("审批状态： "+overtime.getOvertimeStatus());
		
		}
	}
	@Test
	public void deleteById() {
		overtimeService.deleteById(2L);
	}
}