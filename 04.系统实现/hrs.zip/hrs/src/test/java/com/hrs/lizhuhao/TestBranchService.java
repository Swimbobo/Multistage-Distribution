package com.hrs.lizhuhao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.lizhuhao.branch.domain.BranchDTO;
import com.hrs.lizhuhao.branch.service.IBranchService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestBranchService {
	@Autowired
	private  IBranchService branchService;
	
	@Test
	public void save() {
		for (int i = 1; i <= 10; i++) {
			BranchDTO dto = new BranchDTO();
			dto.setBranchName("销售部");
			dto.setEmployeeId("1111111111");
			branchService.save(dto);
		}
	}
	
	@Test
	public void findById() {
		BranchDTO branch=branchService.findById(1L);
		System.out.println(branch);
	}
	
	@Test
	public void deleteById() {
		branchService.deleteById(2L);
	}
	
	@Test
	public void existsById() {
		boolean res=branchService.existsById(2L);
		System.out.println(res);
	}
	
	@Test
	public void count() {
		System.out.println(branchService.count());
	}
}