package com.hrs.zhanshiyang.test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.zhanshiyang.bonus.domain.BonusDTO;
import com.hrs.zhanshiyang.bonus.service.IBonusService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestBonusService 
{
	@Autowired
	private IBonusService bonusService;
	
	@Test
	public void testData() {
		for (int i = 0; i < 100; i++) {
			BonusDTO dto = new BonusDTO();
			dto.setEmployeeId("000"+i);
			dto.setBonusSum(new BigDecimal(i+30.5425));
			dto.setBonusYM(new Date());
			dto.setBonusStyle("2018年12月奖金");
			dto.setBonusAddName("James");
			bonusService.save(dto);
		}	
	}

	@Test
	public void testFindAll() {
		List<BonusDTO> dtoLists = new ArrayList<BonusDTO>();
//		dtoLists = bonusService.findAll();
		for (BonusDTO dto : dtoLists) {
			System.out.println(dto);
		}
	}
	
	@Test
	public void testCount() {
//		System.out.println(bonusService.count());
	}
}
