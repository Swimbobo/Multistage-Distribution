package com.hrs.huangwenkang;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.huangwenkang.resume.domain.ResumeDTO;
import com.hrs.huangwenkang.resume.service.IResumeService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ResumeTest {
	@Autowired
	IResumeService resumeService;
	
	@Test
	public void save() {
		for (int i = 0; i < 30; i++) {
			ResumeDTO resume = new ResumeDTO();
			Date date=new Date();
			resume.setResumeName("1");
			resume.setResumeSex("1");
			resume.setResumeTel("123");
			resume.setResumeEmail("123@qq.com");
			resume.setResumeBirth(date);
			resume.setResumeJobWanted("娃哈哈");
			resume.setResumeGraduate("东莞理工学院");
			resume.setResumeEduBackground("本科");
			resume.setResumeWorkYear1("2");
			resume.setResumeAddress("东莞");
			resume.setResumeMajor("计算机科学与技术");
			resume.setResumeGraduateTime(date);
			resume.setResumeStatus("待查阅");
			resume.setResumeJobWanted("JAVA");
			resumeService.save(resume);
		}
	}
	@Test
	public void deleteById() {
		resumeService.deleteById(2L);
	}
	@Test
	public void findById() {
		ResumeDTO resume = resumeService.findById(3L);
		System.out.println(resume);
	}
	@Test
	public void existsById() {
		boolean res=resumeService.existsById(2L);
		System.out.println(res);
	}
	@Test
	public void count() {
		System.out.println(resumeService.count());
	}
}