package com.hrs.youzhenjieTest.employee;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.youzhenjie.contract.domain.Contract;
import com.hrs.youzhenjie.contract.service.IContractService;
import com.hrs.youzhenjie.employee.domain.Employee;
import com.hrs.youzhenjie.employee.service.IEmployeeService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HrsApplicationTests {

	@Autowired
	private IEmployeeService employeeService;

	@Autowired
	private IContractService contraService;

	@Test
	public void saveEmployee() {
		Employee employee = new Employee();
		employee.setEmployeeId(new SimpleDateFormat("yyMMdd").format(new Date()) + "CC52302");
		employee.setEmployeeDepartment("renshibu");
		employee.setEmployeeEntryTime(new Date());
		employee.setEmployeeLeaveTime(new Date());
	
		employeeService.saveOrUpdate(employee);
	}

	@Test
	public void saveContract() {
		for (int i = 0; i < 5; i++) {
			Contract contract=new Contract();
			contract.setEmployeeId("2530"+i);
			contract.setContractStartTime(new Date());
			contract.setContractEndTime(new Date());
			contract.setContractState("未签订");
			contract.setContractType("劳动合同");
			contract.setContractProperties("文本合同");
			//contraService.saveOrUpdate(contract);
		}
		
		
		
	}

	@Test
	public void find() {
		Optional<Employee> employee = employeeService.searchById(3L);

		System.out.println(employee.get().getEmployeeName());
	}

	@Test
	public void findAll() {
		List<Employee> lists = employeeService.searchAll();
		for (Employee employee : lists) {
			System.out.println(employee.getEmployeeId());
		}
	}
	
	
	@Test
	public void testCash(){
		Employee employee = new Employee();
		employee.setEmployeeId(new SimpleDateFormat("yyMMdd").format(new Date()) + "2530");
		employee.setEmployeeDepartment("renshibu");
		employee.setEmployeeEntryTime(new Date());
		employee.setEmployeeLeaveTime(new Date());
		employee.setEmployeeName("James");
		employee.setEmployeeSex("男");
		
		Contract contract=new Contract();
		contract.setEmployeeId(new SimpleDateFormat("yyMMdd").format(new Date()) +"2530");
		contract.setContractStartTime(new Date());
		contract.setContractEndTime(new Date());
		contract.setContractState("未签订");
		contract.setContractType("劳动合同");
		contract.setContractProperties("文本合同");
		
		contract.setEmployee(employee);
		contraService.save(contract);

//		employee.setContract(contract);
//		employeeService.saveOrUpdate(employee);
	}

	@Test
	public void TestName(){
		Employee employee=employeeService.findByEmployeeId("1812212530");
		System.out.println(employee.getEmployeeName());
		System.out.println(employee.getId());
	}
	
	@Test
	public void sqlit(){
		String fileName="xiaohuanren.gif";
		System.out.println(fileName);
		String[] fileParts=fileName.split("\\.");
		for (String string : fileParts) {
			System.out.println(string);
		}
	}
}
