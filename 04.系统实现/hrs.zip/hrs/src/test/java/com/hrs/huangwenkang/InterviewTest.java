package com.hrs.huangwenkang;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.huangwenkang.interview.domain.InterviewDTO;
import com.hrs.huangwenkang.interview.service.IInterviewService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class InterviewTest {
	@Autowired
	private IInterviewService interviewService;
	//增加对象
	@Test
	public void save() {
		for (int i = 0; i < 10; i++) {
			InterviewDTO interview = new InterviewDTO();
			Date date=new Date();
			interview.setInterviewTime(date);
			interview.setResumeId1("2");
			interview.setInterviewPlace("东莞理工学院");
			interview.setInterviewComment("不及格");
			interview.setInterviewRes("pass");
			interviewService.save(interview);
		}
	}
	//删除对象
	@Test
	public void deleteById() {
		interviewService.deleteById(2L);
	}
	//查找对象
	@Test
	public void findById() {
		InterviewDTO interview = interviewService.findById(3L);
		System.out.println(interview);
	}
	//是否存在对象
	@Test
	public void existsById() {
		boolean res=interviewService.existsById(2L);
		System.out.println(res);
	}
	//求总数
	@Test
	public void count() {
		System.out.println(interviewService.count());
	}
}