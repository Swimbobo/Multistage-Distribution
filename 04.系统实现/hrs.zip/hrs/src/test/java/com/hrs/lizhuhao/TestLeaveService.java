package com.hrs.lizhuhao;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.lizhuhao.leave.domain.LeaveDTO;
import com.hrs.lizhuhao.leave.service.ILeaveService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestLeaveService {
@Autowired
private  ILeaveService leaveService;
//@Test
public void testData() {
	for (int i = 1; i <= 5; i++) {
		LeaveDTO leave = new LeaveDTO();
		leave.setEmployeeId("1111111");
		leave.setEmployeeName("lizhuhao");
		leave.setLeaveStartTime(new Date());
		leave.setLeaveEndTime(new Date());
		leave.setLeaveReasion("生病");
//		leave.setLeavePreccessStatus("审核中");
		leaveService.save(leave);
	}
}

@Test
public void testFindById() {
	LeaveDTO leave=new LeaveDTO();
	leave=leaveService.findById(1L);
	if(leave!=null)
	{
		leave.setEmployeeId("BBBBBBBB");
		leaveService.save(leave);
		System.out.println("员工ID："+leave.getEmployeeId());
		System.out.println("姓名： "+leave.getEmployeeName());
		
//		System.out.println("审核状态： "+leave.getLeavePreccessStatus());
	}
}
@Test
public void deleteById() {
	leaveService.deleteById(2L);
}

@Test
public void existsById() {
	boolean res=leaveService.existsById(2L);
	System.out.println(res);
}

@Test
public void count() {
	System.out.println(leaveService.count());
}
}
