package com.hrs.zhanshiyang.test;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.zhanshiyang.welfare.domain.WelfareDTO;
import com.hrs.zhanshiyang.welfare.service.IWelfareService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestWelfareService 
{
	@Autowired
	private IWelfareService welfareService;
	
	@Test
	public void testData() {
		for (int i = 0; i < 100; i++) {
			WelfareDTO welfare = new WelfareDTO();
			welfare.setEmployeeId("000"+i);
			welfare.setWelfareSum(new BigDecimal(i+560));
			welfare.setWelfareYM(new Date());
			welfare.setWelfareStyle("2018年12月福利");
			welfare.setWelfareAddName("James");
			welfareService.save(welfare);
		}
	}
	
	@Test
	public void testFindById() {
		WelfareDTO welfare = new WelfareDTO();
		welfare = welfareService.findById(6L);
		System.out.println(welfare);
	}
	
	@Test
	public void testDeleteById() {
		welfareService.deleteById(30L);
	}
}
