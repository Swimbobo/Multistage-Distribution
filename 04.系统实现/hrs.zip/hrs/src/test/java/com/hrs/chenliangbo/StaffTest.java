package com.hrs.chenliangbo;


import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.chenliangbo.staff.domain.StaffDTO;
import com.hrs.chenliangbo.staff.service.IStaffService;


@RunWith(SpringRunner.class)
@SpringBootTest
public class StaffTest {
	@Autowired
	private IStaffService staffService;
	/* 测试数据    */
	@Test
	public void textdata() {
		int i;
		for(i=1;i<=100;i++) {
		StaffDTO staff = new StaffDTO();
		if(i<10) {
			staff.setStaffName("Alice");
			staff.setEmployeeId("20154140200"+i);
			staff.setBirthday(new Date());
			staff.setStaffSex("女");
			staff.setStaffIdCard("20154140200"+i);
			staff.setStaffAddress("1130"+i);
			staff.setStaffEmail(i+"@qq.com");
			staff.setStaffPhone("1353714460"+i);
	    }else if (i==100) {
	    	staff.setStaffName("Tom");
	    	staff.setEmployeeId("201541402100");
	    	staff.setBirthday(new Date());
	    	staff.setStaffSex("男");
	    	staff.setStaffIdCard("201541402100");
	    	staff.setStaffAddress("11400");
	    	staff.setStaffEmail(i+"@qq.com");
	    	staff.setStaffPhone("13537144700"+i);
		}else {
			staff.setStaffName("Jax");
			staff.setEmployeeId("2015414020"+i);
			staff.setBirthday(new Date());
			staff.setStaffSex("男");
			staff.setStaffIdCard("2015414020"+i);
			staff.setStaffAddress("113"+i);
			staff.setStaffEmail(i+"@qq.com");
			staff.setStaffPhone("135371446"+i);
		} 
		
		staff.setStaffNation("汉");
		staff.setStaffNativePlace("广东省东莞市");
		staff.setStaffHuKouAddress("广东省东莞市");
		staff.setStaffHuKouType("农村户口");
		staff.setStaffEmergencyContactName("警察叔叔");
		staff.setStaffEmergencyContactPhone("110");
		staffService.save(staff);
		}

	}
	
	
}

