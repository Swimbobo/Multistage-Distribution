package com.hrs.zhanshiyang.test;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.zhanshiyang.salary.domain.SalaryDTO;
import com.hrs.zhanshiyang.salary.service.ISalaryService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestSalaryService 
{
	@Autowired
	private ISalaryService salaryService;
	
	@Test
	public void testData() {
		for (int i = 0; i < 100; i++) {
			SalaryDTO salary = new SalaryDTO();
//			salary.setEmploeeId("000"+i);
			salary.setSalaryYM(new Date());
			salary.setSalaryAttendance(new BigDecimal(15.5));
			salary.setSalaryAbsence(new BigDecimal(4.5));
			salary.setSalaryPerleave(new BigDecimal(5));
			salary.setSalarySicleave(new BigDecimal(2));
			salary.setSalaryOvertime(new BigDecimal(12.25));
			salary.setSalaryBasic(new BigDecimal(54254));
			salary.setSalaryAttsub(new BigDecimal(545.4));
			salary.setSalaryInssub(new BigDecimal(578.54));
			salary.setSalaryBeftax(new BigDecimal(54254));
			salary.setSalarySeltax(new BigDecimal(4254));
			salary.setSalaryReal(new BigDecimal(50000));
			salary.setSalaryRemark("12月薪资");
			salaryService.save(salary);
		}
	}
}
