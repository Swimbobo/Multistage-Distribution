package com.hrs.lizhuhao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.lizhuhao.position.domain.PositionDTO;
import com.hrs.lizhuhao.position.service.IPositionService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestPositionService {
	@Autowired
	IPositionService positionService;
	
	@Test
	public void save() {
		for (int i = 1; i <= 100; i++) {
			PositionDTO position = new PositionDTO();
			position.setPositionName("lizhuhao");
			position.setBranchName("人事部");
			positionService.save(position);
		}
	}
	
	@Test
	public void findById() {
		PositionDTO position=new PositionDTO();
		position=positionService.findById(1L);
		if(position!=null)
		{
			position.setPositionName("BBBBBBBB");
			positionService.save(position);
			System.out.println("职位名称："+position.getPositionName());
			
			System.out.println("所属部门： "+position.getBranchName());
		}
	}
	
	@Test
	public void deleteById() {
		positionService.deleteById(2L);
	}
	
	@Test
	public void existsById() {
		boolean res=positionService.existsById(2L);
		System.out.println(res);
	}
	
	@Test
	public void count() {
		System.out.println(positionService.count());
	}
}