package com.hrs.chenliangbo;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hrs.chenliangbo.file.domain.FileDTO;
import com.hrs.chenliangbo.file.service.IFileService;


@RunWith(SpringRunner.class)
@SpringBootTest
public class FileTest {
	@Autowired
	private IFileService fileService;
	/* 测试数据    */
	@Test
	public void textdata() {
		int i;
		for(i=1;i<=10;i++) {
		FileDTO file=new FileDTO();
		if(i<10) {
			file.setEmployeeId("20154140200"+i);
	    }else if (i==100) {
	    	file.setEmployeeId("201541402100");
		}else {
			file.setEmployeeId("2015414020"+i);
		} 
		file.setFileContent("Java工程师");
		file.setFileResults("SSS+");
		file.setFileMajor("计算机科学与技术");
		file.setFileSchool("东莞理工学院");
		file.setFileEduBackground("本科");
		fileService.save(file);
		}
		
	}

}

