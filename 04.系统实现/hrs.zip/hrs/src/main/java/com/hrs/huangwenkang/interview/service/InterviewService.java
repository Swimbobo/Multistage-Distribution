package com.hrs.huangwenkang.interview.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.huangwenkang.interview.dao.InterviewDao;
import com.hrs.huangwenkang.interview.domain.Interview;
import com.hrs.huangwenkang.interview.domain.InterviewDTO;

@Service
@Transactional
public class InterviewService implements IInterviewService{
	@Autowired
	private InterviewDao interviewDao;
	
	//增加对象
	public Interview save(InterviewDTO dto) {
		Interview entity=new Interview();
		InterviewDTO.dto2Entity(dto, entity);
		return interviewDao.save(entity);
	}
	//通过id删除对象
	public void deleteById(Long id) {
		interviewDao.deleteById(id);
	}
	//批量删除
	public void deleteAll(Long[] ids) {
		List<Long> idLists = new ArrayList<Long>(Arrays.asList(ids));
		List<Interview> interviews = (List<Interview>) interviewDao.findAllById(idLists);
		if(interviews!=null) {
			interviewDao.deleteAll(interviews);
		}
	}
	//通过id查找对象
	public InterviewDTO findById(Long id) {
		Interview entity=interviewDao.findById(id).get();
		InterviewDTO dto=new InterviewDTO();
		InterviewDTO.entity2Dto(entity, dto);
		return dto;
	}
	//通过id判断是否存在对象
	public boolean existsById(Long id) {
		return interviewDao.existsById(id);
	}
	//统计表中数据总数
	public long count() {
		return interviewDao.count();
	}
	//查看全部
	public Page<InterviewDTO> findAll(Specification<Interview> spec, Pageable pageable) {
		Page<Interview> entityList=interviewDao.findAll(spec,pageable);
		List<InterviewDTO> dtoList = new ArrayList<InterviewDTO>();
		for(Interview entity:entityList) {
			InterviewDTO dto=new InterviewDTO();
			InterviewDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return new PageImpl<InterviewDTO>(dtoList,pageable,entityList.getTotalElements());
	}
	//修改面试表状态
	public void updateInterviewRes(String interviewRes,Long id) {
		interviewDao.updateInterviewRes(interviewRes,id);
	}
	@Override
	public void updateinterviewComment(String interviewComment, Long id) {
		interviewDao.updateInterviewComment(interviewComment, id);
		
	}
}