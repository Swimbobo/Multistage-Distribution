package com.hrs.zhanshiyang.record.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.domain.RecordQueryDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@RestController
@RequestMapping("/record")
public class RecordController {
	@Autowired
	private IRecordService recordService;
	
//	根据所需字段搜索分页显示，Postman用Params测试
	@GetMapping
	public @ResponseBody Page<RecordDTO> getPage(RecordQueryDTO recordQueryDTO , ExtjsPageRequest pageRequest) 
	{
		return recordService.findAll(RecordQueryDTO.getWhereClause(recordQueryDTO), pageRequest.getPageable());
	}
}
