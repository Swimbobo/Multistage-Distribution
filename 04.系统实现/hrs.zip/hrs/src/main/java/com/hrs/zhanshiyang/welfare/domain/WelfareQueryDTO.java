package com.hrs.zhanshiyang.welfare.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class WelfareQueryDTO {
	private String employeeId;//员工工号ID
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date welfareTimeStart;//搜索时间的左边界
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date welfareTimeEnd;//搜索时间的右边界
	private String welfareStyle;//福利简述
	private BigDecimal welfareSumFrom;//福利金额从
	private BigDecimal welfareSumTo;//福利金额到
	private String welfareAddName;//录入管理员名字
	
	public String getEmployeeId() {
		return employeeId;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getWelfareTimeStart() {
		return welfareTimeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getWelfareTimeEnd() {
		return welfareTimeEnd;
	}
	public String getWelfareStyle() {
		return welfareStyle;
	}
	public BigDecimal getWelfareSumFrom() {
		return welfareSumFrom;
	}
	public BigDecimal getWelfareSumTo() {
		return welfareSumTo;
	}
	public String getWelfareAddName() {
		return welfareAddName;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setWelfareTimeStart(Date welfareTimeStart) {
		this.welfareTimeStart = welfareTimeStart;
	}
	public void setWelfareTimeEnd(Date welfareTimeEnd) {
		this.welfareTimeEnd = welfareTimeEnd;
	}
	public void setWelfareStyle(String welfareStyle) {
		this.welfareStyle = welfareStyle;
	}
	public void setWelfareSumFrom(BigDecimal welfareSumFrom) {
		this.welfareSumFrom = welfareSumFrom;
	}
	public void setWelfareSumTo(BigDecimal welfareSumTo) {
		this.welfareSumTo = welfareSumTo;
	}
	public void setWelfareAddName(String welfareAddName) {
		this.welfareAddName = welfareAddName;
	}

	@SuppressWarnings({ "serial"})
	public static Specification<Welfare> getWhereClause(final WelfareQueryDTO welfareQueryDTO) {
		return new Specification<Welfare>() {
			@Override
			public Predicate toPredicate(Root<Welfare> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
			
				List<Predicate> predicate = new ArrayList<>();
				
				if (StringUtils.isNotBlank(welfareQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + welfareQueryDTO.getEmployeeId() + "%"));
				}
				if (null!=welfareQueryDTO.getWelfareTimeStart()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("welfareYM").as(Date.class),
							welfareQueryDTO.getWelfareTimeStart()));
				}
				if (null!=welfareQueryDTO.getWelfareTimeEnd()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("welfareYM").as(Date.class),
							welfareQueryDTO.getWelfareTimeEnd()));
				}
				if (StringUtils.isNotBlank(welfareQueryDTO.getWelfareStyle())) {
					predicate.add(criteriaBuilder.like(root.get("welfareStyle").as(String.class),
							"%" + welfareQueryDTO.getWelfareStyle() + "%"));
				}
				if(null!=welfareQueryDTO.getWelfareSumFrom()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("welfareSum").as(BigDecimal.class), 
							welfareQueryDTO.getWelfareSumFrom()));
				}
				if(null!=welfareQueryDTO.getWelfareSumTo()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("welfareSum").as(BigDecimal.class), 
							welfareQueryDTO.getWelfareSumTo()));
				}
				if (StringUtils.isNotBlank(welfareQueryDTO.getWelfareAddName())) {
					predicate.add(criteriaBuilder.like(root.get("welfareAddName").as(String.class),
							"%" + welfareQueryDTO.getWelfareAddName() + "%"));
				}
				
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}
