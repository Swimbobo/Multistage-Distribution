package com.hrs.huangwenkang.interview.domain;

import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;

public class InterviewDTO{
	private Long id;							//id
	private String resumeId1;					//简历表id
	private String interviewName;				//面试者姓名
	private String interviewSex;				//面试者性别
	private String interviewTel;				//面试者联系电话
	private String interviewEduBackground;		//面试者最高学历
	private String interviewJobWanted;			//面试职位
	@DateTimeFormat(pattern="yyyy/MM/dd HH:mm:ss")
	private Date interviewTime;					//面试时间
	private String interviewPlace;				//面试地点
	private String interviewComment;			//面试评语
	private String interviewRes;				//面试结果
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getResumeId1() {
		return resumeId1;
	}
	public void setResumeId1(String resumeId1) {
		this.resumeId1 = resumeId1;
	}
	public String getInterviewName() {
		return interviewName;
	}
	public void setInterviewName(String interviewName) {
		this.interviewName = interviewName;
	}
	public String getInterviewSex() {
		return interviewSex;
	}
	public void setInterviewSex(String interviewSex) {
		this.interviewSex = interviewSex;
	}
	public String getInterviewTel() {
		return interviewTel;
	}
	public void setInterviewTel(String interviewTel) {
		this.interviewTel = interviewTel;
	}
	public String getInterviewEduBackground() {
		return interviewEduBackground;
	}
	public void setInterviewEduBackground(String interviewEduBackground) {
		this.interviewEduBackground = interviewEduBackground;
	}
	public String getInterviewJobWanted() {
		return interviewJobWanted;
	}
	public void setInterviewJobWanted(String interviewJobWanted) {
		this.interviewJobWanted = interviewJobWanted;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getInterviewTime() {
		return interviewTime;
	}
	public void setInterviewTime(Date interviewTime) {
		this.interviewTime = interviewTime;
	}
	public String getInterviewPlace() {
		return interviewPlace;
	}
	public void setInterviewPlace(String interviewPlace) {
		this.interviewPlace = interviewPlace;
	}
	public String getInterviewComment() {
		return interviewComment;
	}
	public void setInterviewComment(String interviewComment) {
		this.interviewComment = interviewComment;
	}
	public String getInterviewRes() {
		return interviewRes;
	}
	public void setInterviewRes(String interviewRes) {
		this.interviewRes = interviewRes;
	}
	//前端到后台（接收表单数据）
	public static void dto2Entity(InterviewDTO dto ,Interview entity) {
		//类型转换
		Long i=Long.valueOf(dto.getResumeId1());
		entity.setResumeId(i);
		BeanUtils.copyProperties(dto, entity);
	}
	//后台到前端（返回JSON数据）
	public  static void entity2Dto(Interview entity ,InterviewDTO dto) {
		//类型转换
		Long i=entity.getResumeId();
		String s=Long.toString(i);
		dto.setResumeId1(s);
		BeanUtils.copyProperties(entity,dto);
	}
}