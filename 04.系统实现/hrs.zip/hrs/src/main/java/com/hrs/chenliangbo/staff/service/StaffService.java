package com.hrs.chenliangbo.staff.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.chenliangbo.staff.dao.StaffDao;
import com.hrs.chenliangbo.staff.domain.Staff;
import com.hrs.chenliangbo.staff.domain.StaffDTO;

@Service
@Transactional(readOnly=true)
public class StaffService implements IStaffService{
	@Autowired
	private StaffDao staffDao;
	
	@Transactional
	public void save(StaffDTO staffdto) {
		Staff staff=new Staff();
		StaffDTO.dto2Entity(staffdto, staff);
		staffDao.save(staff);
	}

	@Transactional
	public void save(List<StaffDTO> list) {
		List<Staff> filelist=new ArrayList<Staff>();
		for (StaffDTO dto : list) {
			Staff staff=new Staff();
			StaffDTO.dto2Entity(dto, staff);
			filelist.add(staff);
			
		}
		staffDao.saveAll(filelist);
	}

	public StaffDTO findById(Long id) {
		Staff staff= staffDao.findById(id).get();
		StaffDTO staffDTO=new StaffDTO();
		StaffDTO.entity2Dto(staff, staffDTO);
		return staffDTO;
	}
	
	@Transactional
	public void deleteById(Long id) {
		staffDao.deleteById(id);
	}
	@Transactional
	public void delete(StaffDTO staffdto) {
		Staff staff=new Staff();
		StaffDTO.dto2Entity(staffdto, staff);
		staffDao.delete(staff);	
	}

	
	public Page<StaffDTO> findAll(Specification<Staff> spec, Pageable pageable) {
		Page<Staff> entityList=staffDao.findAll(spec,pageable);
		List<StaffDTO> dtoList = new ArrayList<StaffDTO>();
		for(Staff entity:entityList) {
			StaffDTO dto=new StaffDTO();
			StaffDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return new PageImpl<StaffDTO>(dtoList,pageable,entityList.getTotalElements());
	}
}