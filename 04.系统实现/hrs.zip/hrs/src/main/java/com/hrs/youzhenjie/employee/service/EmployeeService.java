package com.hrs.youzhenjie.employee.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.youzhenjie.employee.dao.IEmployeeDao;
import com.hrs.youzhenjie.employee.domain.Employee;

@Service
@Transactional
public class EmployeeService implements IEmployeeService {

	@Autowired
	private IEmployeeDao employeeDao;

	@Override
	public Employee saveOrUpdate(Employee employee) {
		System.out.println(employee.getEmployeeId());
		return employeeDao.save(employee);
	}
	
	@Override
	public Optional<Employee> searchById(Long id) {
		// TODO Auto-generated method stub
		return employeeDao.findById(id);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Employee> searchAll() {
		// TODO Auto-generated method stub
		return (List<Employee>) employeeDao.findAll();
	}

	@Override
	public Page<Employee> searchAllByPage(Specification<Employee> sepc, Pageable pageable) {
		// TODO Auto-generated method stub
		return employeeDao.findAll(sepc, pageable);
	}

	

	@Override
	public Employee findByEmployeeId(String empid) {
		// TODO Auto-generated method stub
		return employeeDao.findByEmployeeId(empid);
	}
	
	@Override

	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		if (employeeDao.findById(id) != null) {
			employeeDao.deleteById(id);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public long count() {
		// TODO Auto-generated method stub
		return employeeDao.count();
	}

	@Override
	@Transactional(readOnly = true)
	public boolean existsById(Long id) {
		// TODO Auto-generated method stub
		return employeeDao.existsById(id);
	}

	@Override
	public void deleteAll(Long[] ids) {
		 List<Long> empIdLists = new ArrayList<Long>();
		 for (int i = 0; i < ids.length; i++) {
		 empIdLists.add(ids[i]);
		 }
		
		 List<Employee> employees = (List<Employee>) employeeDao.findAllById(empIdLists);
		 if (employees != null) {
		 employeeDao.deleteAll(employees);
		 }
	}

	@Override
	public Employee findByEmployeeName(String employeeName) {
		return employeeDao.findByEmployeeName(employeeName);
	}


}
