package com.hrs.zhanshiyang.performance.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.common.beans.BeanUtils;
import com.hrs.zhanshiyang.performance.dao.PerformanceDao;
import com.hrs.zhanshiyang.performance.domain.Performance;
import com.hrs.zhanshiyang.performance.domain.PerformanceDTO;
import com.hrs.zhanshiyang.template.dao.TemplateDao;
import com.hrs.zhanshiyang.template.domain.Template;

@Service
@Transactional
public class PerformanceService implements IPerformanceService 
{
	@Autowired
	private PerformanceDao performanceDao;
	
	@Autowired
	private TemplateDao templateDao;
	
	@Transactional
	public void save(PerformanceDTO dto) {
		Performance entity = new Performance();
		//类型转换
//		int i = Integer.parseInt(dto.getPerformanceFractionView());
//		entity.setPerformanceFraction(i);
		BeanUtils.copyProperties(dto, entity);
		if(dto.getTemplateId()!=null) {
			Template template = new Template();
			template = templateDao.findById(dto.getTemplateId()).get();
			//建立单向关联关系
			entity.setTemplate(template);
		}
		performanceDao.save(entity);
	}
	
	@Transactional
	public Page<PerformanceDTO> findAll(Specification<Performance> spec, Pageable pageable) {
		Page<Performance> entities = performanceDao.findAll(spec, pageable);
		
		List<PerformanceDTO> dtoLists = new ArrayList<PerformanceDTO>();
		for (Performance entity : entities) {
			PerformanceDTO dto = new PerformanceDTO();
			PerformanceDTO.entity2Dto(entity, dto);
			dtoLists.add(dto);
		}
		return new PageImpl<PerformanceDTO>(dtoLists, pageable, entities.getTotalElements());
	}

}
