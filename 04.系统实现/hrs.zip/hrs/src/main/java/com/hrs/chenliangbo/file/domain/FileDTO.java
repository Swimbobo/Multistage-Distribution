package com.hrs.chenliangbo.file.domain;

import com.hrs.common.beans.BeanUtils;

public class FileDTO {
	private Long id;
	private String employeeId;			//工号
	private String fileContent;			//工作内容
	private String fileResults;			//业绩
	private String fileSchool;			//学校
	private String fileMajor;			//专业
	private String fileEduBackground;	//学历背景
	
	//getters
	public Long getId() {
		return id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public String getFileContent() {
		return fileContent;
	}
	public String getFileResults() {
		return fileResults;
	}
	public String getFileSchool() {
		return fileSchool;
	}
	public String getFileMajor() {
		return fileMajor;
	}
	public String getFileEduBackground() {
		return fileEduBackground;
	}
	
	//setters
	public void setId(Long id) {
		this.id = id;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}
	public void setFileResults(String fileResults) {
		this.fileResults = fileResults;
	}
	public void setFileSchool(String fileSchool) {
		this.fileSchool = fileSchool;
	}
	public void setFileMajor(String fileMajor) {
		this.fileMajor = fileMajor;
	}
	public void setFileEduBackground(String fileEduBackground) {
		this.fileEduBackground = fileEduBackground;
	}
	
	//前端到后台（接收表单数据）
	public  static void dto2Entity(FileDTO dto ,File entity) {
		BeanUtils.copyProperties(dto, entity);
	}
	//后台到前端（返回JSON数据）：find	显示什么数据？
	public  static void entity2Dto(File entity ,FileDTO dto) {
		BeanUtils.copyProperties(entity , dto);
	}
}