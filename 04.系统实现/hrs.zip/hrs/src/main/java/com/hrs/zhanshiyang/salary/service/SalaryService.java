package com.hrs.zhanshiyang.salary.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.zhanshiyang.salary.dao.SalaryDao;
import com.hrs.zhanshiyang.salary.domain.Salary;
import com.hrs.zhanshiyang.salary.domain.SalaryDTO;
import com.hrs.zhanshiyang.salary.service.ISalaryService;

@Service
@Transactional
public class SalaryService implements ISalaryService {
	@Autowired
	private SalaryDao salaryDao;

	@Transactional
	public void save(SalaryDTO dto) {
		Salary entity = new Salary();
		SalaryDTO.dto2Entity(dto, entity);
		salaryDao.save(entity);
	}

	@Transactional
	public SalaryDTO findById(Long id) {
		Salary entity = salaryDao.findById(id).get();
		SalaryDTO dto = new SalaryDTO();
		SalaryDTO.entity2Dto(entity, dto);
		return dto;
	}

	public List<SalaryDTO> findAllById(List<Long> ids) {
		List<Salary> entities = (List<Salary>) salaryDao.findAllById(ids);
		List<SalaryDTO> dtoLists = new ArrayList<SalaryDTO>();
		for (Salary entity : entities) {
			SalaryDTO dto = new SalaryDTO();
			SalaryDTO.entity2Dto(entity, dto);
			dtoLists.add(dto);
		}
		return dtoLists;
	}

	public void deleteById(Long id) {
		salaryDao.deleteById(id);
	}

	public void deleteAll(List<SalaryDTO> dtoLists) {
		List<Salary> entities = new ArrayList<Salary>();
		for (SalaryDTO dto : dtoLists) {
			Salary entity = new Salary();
			SalaryDTO.dto2Entity(dto, entity);
			entities.add(entity);
		}
		salaryDao.deleteAll(entities);
	}

	public Page<SalaryDTO> findAll(Specification<Salary> spec, Pageable pageable) {
		Page<Salary> entities = salaryDao.findAll(spec,pageable);
		
		List<SalaryDTO> dtoLists = new ArrayList<SalaryDTO>();
		for (Salary entity : entities) {
			SalaryDTO dto = new SalaryDTO();
			SalaryDTO.entity2Dto(entity, dto);
			dtoLists.add(dto);
		}
		return new PageImpl<SalaryDTO>(dtoLists, pageable, entities.getTotalElements());
	}
	//查找奖金表
	public BigDecimal findBonus(String employeeId, String date) {
		if(salaryDao.findBonus(employeeId, date)!=null) {
			return salaryDao.findBonus(employeeId, date);
		}
		else {
			return new BigDecimal(0);
		}
	}
	//查找福利表
	public BigDecimal findWelfare(String employeeId, String date) {
		if(salaryDao.findWelfare(employeeId, date)!=null) {
			return salaryDao.findWelfare(employeeId, date);
		}
		else {
			return new BigDecimal(0);
		}
	}
	//查找合同表
	public BigDecimal findContract(String employeeId) {
		if(salaryDao.findContract(employeeId)!=null) {
			return salaryDao.findContract(employeeId);
		}
		else {
			return new BigDecimal(0);
		}
	}
	//查找考勤表
	public int findAttendance(String employeeId, String date) {
		if(salaryDao.findAttendance(employeeId, date)!=0) {
			return salaryDao.findAttendance(employeeId, date);
		}
		else {
			return 0;
		}
	}
	//查找加班表
	public String findOvertime(String employeeId, String date) {
		System.out.println("overTime:"+salaryDao.findOvertime(employeeId, date));
		if(salaryDao.findOvertime(employeeId, date)!=null) {
			return salaryDao.findOvertime(employeeId, date);
		}
		else {
			return null;
		}
	}
	//查找请假
	public String findLeave(String employeeId, String date) {
		if(salaryDao.findLeave(employeeId, date)!=null) {
			return salaryDao.findLeave(employeeId, date);
		}
		else {
			return null;
		}
	}
	//查找出差
	public String findBusiniss(String employeeId, String date) {
		if(salaryDao.findBusiniss(employeeId, date)!=null) {
			return salaryDao.findBusiniss(employeeId, date);
		}
		else {
			return null;
		}
	}
}