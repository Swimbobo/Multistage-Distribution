package com.hrs.chenliangbo.staff.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.chenliangbo.staff.domain.Staff;
import com.hrs.chenliangbo.staff.domain.StaffDTO;

public interface IStaffService {
	public void save(StaffDTO staffdto);	//保存/修改一个记录
	public void save(List<StaffDTO> list);//保存一个数组
	public StaffDTO findById(Long id);	//根据id查找记录
	public void deleteById(Long id);	//根据id删除记录
	public void delete(StaffDTO staffdto); 	//根据实体删除记录
	public Page<StaffDTO> findAll(Specification<Staff> spec, Pageable pageable);//分页查找所有记录
}