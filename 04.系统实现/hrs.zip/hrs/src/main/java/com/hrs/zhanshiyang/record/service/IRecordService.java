package com.hrs.zhanshiyang.record.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.zhanshiyang.record.domain.Record;
import com.hrs.zhanshiyang.record.domain.RecordDTO;

public interface IRecordService 
{
//	CrudRepository接口：
	public void save(RecordDTO dto);
//	PagingAndSortingRepository extends CrudRepository接口：	
	public Page<RecordDTO> findAll(Specification<Record> spec, Pageable pageable);
	
}
