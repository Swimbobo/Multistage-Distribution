package com.hrs.lizhuhao.position.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

public class PositionQueryDTO {
	private String positionName;	//职位名称
    private String branchName;		//所属部门名称
    
	public String getPositionName() {
		return positionName;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
    
	@SuppressWarnings({ "serial"})
	public static Specification<Position> getWhereClause(final PositionQueryDTO positionDTO) {
		return new Specification<Position>() {
			@Override
			public Predicate toPredicate(Root<Position> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();
				if (StringUtils.isNotBlank(positionDTO.getPositionName())) {
					predicate.add(criteriaBuilder.like(root.get("positionName").as(String.class),
							"%" + positionDTO.getPositionName() + "%"));
				}
				if (StringUtils.isNotBlank(positionDTO.getBranchName())) {
					predicate.add(criteriaBuilder.like(root.get("branchName").as(String.class),
							"%" + positionDTO.getBranchName() + "%"));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}