package com.hrs.zhanshiyang.salary.web;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.zhanshiyang.salary.domain.FinalSalary;
import com.hrs.zhanshiyang.salary.domain.SalaryDTO;
import com.hrs.zhanshiyang.salary.domain.SalaryQueryDTO;
import com.hrs.zhanshiyang.salary.service.ISalaryService;

@RestController
@RequestMapping("/salary")
public class SalaryController {
	@Autowired
	private ISalaryService salaryService;
	
	//添加
	@PostMapping
	public ExtAjaxResponse save(@RequestBody SalaryDTO dto) {
		try {
			salaryService.save(dto);
			return new ExtAjaxResponse(true,"保存成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"保存失败！");
		}
	}
	
	//根据id删除数据
	@DeleteMapping(value="{id}")
	public ExtAjaxResponse delete(@PathVariable("id") Long id) {
		try {
			if(id!=null) {
				salaryService.deleteById(id);
			}
			return new ExtAjaxResponse(true,"删除成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"删除失败！");
		}
	}

	//根据数组id批量删除数据
	@PostMapping("/deletes")
	public ExtAjaxResponse deleteRows(@RequestParam(name="ids") Long[] ids) {
		try {
			List<SalaryDTO> dtoLists = new ArrayList<>();
			for (int i = 0; i < ids.length; i++) {
				Long id = ids[i];
				dtoLists.add(salaryService.findById(id));
			}
			if(ids!=null) {
				salaryService.deleteAll(dtoLists);
			}
			return new ExtAjaxResponse(true,"批量删除成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"批量删除失败！");
		}
	}
	
	//根据所需字段搜索分页显示，Postman用Params测试
	@GetMapping
	public Page<SalaryDTO> getPage(SalaryQueryDTO salaryQueryDTO , ExtjsPageRequest pageRequest) 
	{
		return salaryService.findAll(SalaryQueryDTO.getWhereClause(salaryQueryDTO), pageRequest.getPageable());
	}
	
	@PostMapping("/allSalary")
	public FinalSalary allSalary(@RequestParam(name="employeeId") String employeeId,
			@RequestParam(name="salaryYM") String salaryYM) throws ParseException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM");
		Date date= sdf.parse(salaryYM);
		String sql=sdf.format(date);
		FinalSalary dto=new FinalSalary();
		dto.setBonusSum(salaryService.findBonus(employeeId,sql));
		dto.setWelfareSum(salaryService.findWelfare(employeeId,sql));
		dto.setSalaryBasic(salaryService.findContract(employeeId));
		dto.setSalaryAttendance(salaryService.findAttendance(employeeId,sql));
		String overTime=salaryService.findOvertime(employeeId,sql);
		if(overTime==null) {
			dto.setSalaryOvertime(0);
		}else{
			int overTime2=Integer.parseInt(overTime);
			dto.setSalaryOvertime(overTime2);
		}
		String leave=salaryService.findLeave(employeeId,sql);
		if(leave==null) {
			dto.setSalaryPerleave(0);
		}else {
			int leave2=Integer.parseInt(leave);
			dto.setSalaryPerleave(leave2);
		}
		String businiss=salaryService.findBusiniss(employeeId,sql);
		if(businiss==null) {
			dto.setSalaryPerleave(0);
		}else {
			int businiss2=Integer.parseInt(businiss);
			dto.setSalarySicleave(businiss2);
		}
		return dto;
	}
}