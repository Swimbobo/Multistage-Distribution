package com.hrs.lizhuhao.leave.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.hrs.lizhuhao.leave.dao.LeaveDao;
import com.hrs.lizhuhao.leave.domain.Leave;
import com.hrs.lizhuhao.leave.domain.LeaveDTO;

@Service
@Transactional
public class LeaveService implements ILeaveService {
	@Autowired
	private LeaveDao leaveDao;
	
	//增加对象
	public void save(LeaveDTO dto) {
		Leave entity=new Leave();
		LeaveDTO.dto2Entity(dto, entity);
        leaveDao.save(entity);
	}
	//通过id删除对象
	public void deleteById(Long id) {
		leaveDao.deleteById(id);
	}
	//批量删除
	public void deleteAll(Long[] ids) {
		List<Long> idLists = new ArrayList<Long>(Arrays.asList(ids));
		List<Leave> leaves = (List<Leave>) leaveDao.findAllById(idLists);
		if(leaves!=null) {
			leaveDao.deleteAll(leaves);
		}
	}
	//通过ID查找对象
	@Transactional(readOnly=true)
	public LeaveDTO findById(Long id) {
		Leave entity=leaveDao.findById(id).get();
		LeaveDTO dto=new LeaveDTO();
		LeaveDTO.entity2Dto(entity, dto);
		return dto;
	}
	//通过id判断是否存在对象
	public boolean existsById(Long id) {
		return leaveDao.existsById(id);
	}
	//统计表中数据总数
	public long count() {
		return leaveDao.count();
	}
	//查看全部
	@Override
	public Page<LeaveDTO> findAll(Specification<Leave> spec, Pageable pageable) {
		Page<Leave> entityList=leaveDao.findAll(spec,pageable);
		List<LeaveDTO> dtoList = new ArrayList<LeaveDTO>();
		for(Leave entity:entityList) {
			LeaveDTO dto=new LeaveDTO();
			LeaveDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return new PageImpl<LeaveDTO>(dtoList,pageable,entityList.getTotalElements());
	}
}