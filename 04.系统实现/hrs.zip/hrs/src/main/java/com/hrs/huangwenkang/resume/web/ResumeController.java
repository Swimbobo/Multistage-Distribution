package com.hrs.huangwenkang.resume.web;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.common.beans.BeanUtils;
import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.huangwenkang.resume.domain.ResumeDTO;
import com.hrs.huangwenkang.resume.domain.ResumeQueryDTO;
import com.hrs.huangwenkang.resume.service.IResumeService;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@RestController
@RequestMapping("/resume")
public class ResumeController {
	@Autowired
	private IResumeService resumeService;
	@Autowired
	private IRecordService recordService;
	
	//显示全部数据
	@GetMapping
	public @ResponseBody Page<ResumeDTO> getPage(ResumeQueryDTO resumeQueryDTO,ExtjsPageRequest pageRequest){
		return resumeService.findAll(ResumeQueryDTO.getWhereClause(resumeQueryDTO),pageRequest.getPageable());
	}
	//查看简历详细信息
	@PostMapping(value="{id}")
	public ResumeDTO getOne(@PathVariable("id") String id){
		Long i=Long.valueOf(id);
		ResumeDTO resume=resumeService.findById(i);
		return resume;
	}
	//增加数据
	@PostMapping
	public @ResponseBody ExtAjaxResponse save(@RequestBody ResumeDTO resume){
		try {
			resumeService.save(resume);
			return new ExtAjaxResponse(true,"保存成功！");
		}catch(Exception e) {
			return new ExtAjaxResponse(true,"保存失败！");
			}
	}
	//修改数据(restful)
	@PutMapping(value="{id}",consumes=MediaType.APPLICATION_JSON_VALUE)
	public ExtAjaxResponse update(@PathVariable("id") Long myId,@RequestBody ResumeDTO dto) {
		try {
			ResumeDTO resume = resumeService.findById(myId);
			if(resume!=null) {
				BeanUtils.copyProperties(dto, resume);//使用自定义的BeanUtils
				resumeService.save(resume);
				writeLog("不通过");
			}
			return new ExtAjaxResponse(true,"更新成功！");
		}catch(Exception e) {
			return new ExtAjaxResponse(true,"更新失败！");
			}
	}
	//日志操作
	public void writeLog(String operation){
		HttpServletRequest request=((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session=request.getSession();
		String employeeId=SessionUtil.getEmployeeId(session);
		RecordDTO recordDTO=new RecordDTO();
		recordDTO.setEmployeeId(employeeId);
		recordDTO.setRecordContent(operation+" 简历信息成功");
		recordDTO.setRecordTime(new Date());
		recordService.save(recordDTO);
	}
}