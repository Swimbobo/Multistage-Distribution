package com.hrs.huangwenkang.resume.domain;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;

import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_resume")
public class Resume extends BaseDomain<Long>{
	private String resumeName;				//姓名
	private String resumeSex;				//性别
	private String resumeTel;				//联系电话
	private String resumeEmail;				//邮箱
	@DateTimeFormat(pattern="yyyy/MM")
	private Date resumeBirth;				//出生年月
	private String resumeGraduate;			//毕业院校
	@DateTimeFormat(pattern="yyyy/MM")
	private Date resumeGraduateTime;		//毕业年月
	private String resumeMajor;				//所修专业
	private int resumeWorkYear;				//工作年限
	private String resumeAddress;			//住址
	private String resumeJobWanted;			//应聘职位
	private String resumeExperience;		//个人经历
	private String resumeSupplement;		//补充内容
	private String resumeEduBackground;		//学历背景
	private String resumeStatus;			//简历状态
	
	//getters
	@Column(nullable=false)
	public String getResumeName() {
		return resumeName;
	}
	@Column(nullable=false)
	public String getResumeSex() {
		return resumeSex;
	}
	@Column(nullable=false)
	public String getResumeTel() {
		return resumeTel;
	}
	@Column(nullable=false)
	public String getResumeEmail() {
		return resumeEmail;
	}
	//显示XXXX-XX-XX
	@Column(nullable=false)
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM",timezone="GMT+8")
	public Date getResumeBirth() {
		return resumeBirth;
	}
	@Column(nullable=false)
	public String getResumeGraduate() {
		return resumeGraduate;
	}
	//显示XXXX-XX-XX
	@Column(nullable=false)
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM",timezone="GMT+8")
	public Date getResumeGraduateTime() {
		return resumeGraduateTime;
	}
	@Column(nullable=false)
	public String getResumeMajor() {
		return resumeMajor;
	}
	@Column(nullable=false)
	public int getResumeWorkYear() {
		return resumeWorkYear;
	}
	@Column(nullable=false)
	public String getResumeAddress() {
		return resumeAddress;
	}
	@Column(nullable=false)
	public String getResumeJobWanted() {
		return resumeJobWanted;
	}
	public String getResumeExperience() {
		return resumeExperience;
	}
	public String getResumeSupplement() {
		return resumeSupplement;
	}
	@Column(nullable=false)
	public String getResumeEduBackground() {
		return resumeEduBackground;
	}
	@Column(nullable=false)
	public String getResumeStatus() {
		return resumeStatus;
	}
	
	//setters
	public void setResumeName(String resumeName) {
		this.resumeName = resumeName;
	}
	public void setResumeSex(String resumeSex) {
		this.resumeSex = resumeSex;
	}
	public void setResumeTel(String resumeTel) {
		this.resumeTel = resumeTel;
	}
	public void setResumeEmail(String resumeEmail) {
		this.resumeEmail = resumeEmail;
	}
	public void setResumeBirth(Date resumeBirth) {
		this.resumeBirth = resumeBirth;
	}
	public void setResumeGraduate(String resumeGraduate) {
		this.resumeGraduate = resumeGraduate;
	}
	public void setResumeGraduateTime(Date resumeGraduateTime) {
		this.resumeGraduateTime = resumeGraduateTime;
	}
	public void setResumeMajor(String resumeMajor) {
		this.resumeMajor = resumeMajor;
	}
	public void setResumeWorkYear(int resumeWorkYear) {
		this.resumeWorkYear = resumeWorkYear;
	}
	public void setResumeAddress(String resumeAddress) {
		this.resumeAddress = resumeAddress;
	}
	public void setResumeJobWanted(String resumeJobWanted) {
		this.resumeJobWanted = resumeJobWanted;
	}
	public void setResumeExperience(String resumeExperience) {
		this.resumeExperience = resumeExperience;
	}
	public void setResumeSupplement(String resumeSupplement) {
		this.resumeSupplement = resumeSupplement;
	}
	public void setResumeEduBackground(String resumeEduBackground) {
		this.resumeEduBackground = resumeEduBackground;
	}
	public void setResumeStatus(String resumeStatus) {
		this.resumeStatus = resumeStatus;
	}
}