package com.hrs.huangwenkang.recruit.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.huangwenkang.recruit.domain.Recruit;

@Repository
public interface RecruitDao extends JpaSpecificationExecutor<Recruit>,PagingAndSortingRepository<Recruit,Long>{}