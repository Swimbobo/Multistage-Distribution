package com.hrs.chenliangbo.staff.domain;

import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;

public class StaffDTO {
	private Long id;
	private String staffName;	//姓名
	private String employeeId;	//工号
	@DateTimeFormat(pattern="yyyy/MM/dd") 
	private Date birthday;      //出生日期
	private String staffSex;	//性别
	private String staffIdCard;	//身份证号码
	private String staffPhone;	//联系方式
	private String staffEmail;	//邮箱
	private String staffAddress;//家庭住址
	private String staffNation;	//民族
	private String staffNativePlace;//籍贯
	private String staffHuKouAddress;//户口所在地
	private String staffHuKouType;//户口类型
	private String staffEmergencyContactName;//紧急联系人
	private String staffEmergencyContactPhone;//紧急联系人电话
	
	//getters
	public Long getId() {
		return id;
	}
	public String getStaffName() {
		return staffName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getBirthday() {
		return birthday;
	}
	public String getStaffSex() {
		return staffSex;
	}
	public String getStaffIdCard() {
		return staffIdCard;
	}
	public String getStaffPhone() {
		return staffPhone;
	}
	public String getStaffEmail() {
		return staffEmail;
	}
	public String getStaffAddress() {
		return staffAddress;
	}
	public String getStaffNation() {
		return staffNation;
	}
	public String getStaffNativePlace() {
		return staffNativePlace;
	}
	public String getStaffHuKouAddress() {
		return staffHuKouAddress;
	}
	public String getStaffHuKouType() {
		return staffHuKouType;
	}
	public String getStaffEmergencyContactName() {
		return staffEmergencyContactName;
	}
	public String getStaffEmergencyContactPhone() {
		return staffEmergencyContactPhone;
	}
	//setters
	public void setId(Long id) {
		this.id = id;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public void setStaffSex(String staffSex) {
		this.staffSex = staffSex;
	}
	public void setStaffIdCard(String staffIdCard) {
		this.staffIdCard = staffIdCard;
	}
	public void setStaffPhone(String staffPhone) {
		this.staffPhone = staffPhone;
	}
	public void setStaffEmail(String staffEmail) {
		this.staffEmail = staffEmail;
	}
	public void setStaffAddress(String staffAddress) {
		this.staffAddress = staffAddress;
	}
	public void setStaffNation(String staffNation) {
		this.staffNation = staffNation;
	}
	public void setStaffNativePlace(String staffNativePlace) {
		this.staffNativePlace = staffNativePlace;
	}
	public void setStaffHuKouAddress(String staffHuKouAddress) {
		this.staffHuKouAddress = staffHuKouAddress;
	}
	public void setStaffHuKouType(String staffHuKouType) {
		this.staffHuKouType = staffHuKouType;
	}
	public void setStaffEmergencyContactName(String staffEmergencyContactName) {
		this.staffEmergencyContactName = staffEmergencyContactName;
	}
	public void setStaffEmergencyContactPhone(String staffEmergencyContactPhone) {
		this.staffEmergencyContactPhone = staffEmergencyContactPhone;
	}
	//前端到后台（接收表单数据）
	public static void dto2Entity(StaffDTO dto,Staff entity){
		BeanUtils.copyProperties(dto, entity);
	}
	//后台到前端（返回JSON数据）：find	显示什么数据？
	public static void entity2Dto(Staff entity,StaffDTO dto){
		BeanUtils.copyProperties(entity , dto);
	}
}