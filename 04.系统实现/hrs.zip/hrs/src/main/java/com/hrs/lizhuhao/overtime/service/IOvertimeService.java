package com.hrs.lizhuhao.overtime.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import com.hrs.lizhuhao.overtime.domain.Overtime;
import com.hrs.lizhuhao.overtime.domain.OvertimeDTO;

public interface IOvertimeService {
	public void save(OvertimeDTO dto);					//增加对象
	public void deleteById(Long id);					//通过id删除对象
	public void deleteAll(Long[] ids);					//批量删除
	public OvertimeDTO findById(Long id);				//通过id查找对象
	public long count();								//统计数据总数	
	public Page<OvertimeDTO> findAll(Specification<Overtime> spec,Pageable pageable);
}