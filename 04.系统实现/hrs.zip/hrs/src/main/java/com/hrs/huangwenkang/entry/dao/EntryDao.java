package com.hrs.huangwenkang.entry.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.huangwenkang.entry.domain.Entry;

@Repository
public interface EntryDao extends JpaSpecificationExecutor<Entry>,PagingAndSortingRepository<Entry,Long>{
	//修改入职表状态
	@Modifying
	@Query(value="update t_entry set entryStatus='已入职' where id=?1",nativeQuery=true)
	public void updateEntryRes(Long id);
	
	
}