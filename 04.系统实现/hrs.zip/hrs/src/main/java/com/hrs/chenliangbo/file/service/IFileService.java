package com.hrs.chenliangbo.file.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.chenliangbo.file.domain.File;
import com.hrs.chenliangbo.file.domain.FileDTO;

public interface IFileService {
	public void save(FileDTO filedto);	//保存/修改一个记录
	public void save(List<FileDTO> list);//保存一个数组
	public FileDTO findById(Long id);	//根据id查找记录
	public void deleteById(Long id);	//根据id删除记录
	public void delete(FileDTO filedto); 	//根据实体删除记录
	public Page<FileDTO> findAll(Specification<File> spec, Pageable pageable);//分页查找所有记录
}