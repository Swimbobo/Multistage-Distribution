package com.hrs.zhanshiyang.record.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.zhanshiyang.record.dao.RecordDao;
import com.hrs.zhanshiyang.record.domain.Record;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@Service
@Transactional
public class RecordService implements IRecordService 
{
	@Autowired
	private RecordDao recordDao;

	@Transactional
	public void save(RecordDTO dto) {
		Record entity = new Record();
		RecordDTO.dto2Entity(dto, entity);
		recordDao.save(entity);
	}

	public Page<RecordDTO> findAll(Specification<Record> spec, Pageable pageable) {
		Page<Record> entities = recordDao.findAll(spec,pageable);
		
		List<RecordDTO> dtoLists = new ArrayList<RecordDTO>();
		for (Record entity : entities) {
			RecordDTO dto = new RecordDTO();
			RecordDTO.entity2Dto(entity, dto);
			dtoLists.add(dto);
		}
		return new PageImpl<RecordDTO>(dtoLists, pageable, entities.getTotalElements());
	}

}