package com.hrs.huangwenkang.entry.domain;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;

import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_entry")
public class Entry extends BaseDomain<Long>{
	private Long interviewId;					//面试表id
	private Long resumeId;						//简历表id
	private String entryName;					//姓名
	private String entrySex;					//性别
	private String entrybranch;					//部门
	private String entryposition;				//职位
	private String entryTel;					//联系电话
	@DateTimeFormat(pattern="yyyy/MM/dd")
	private Date entryExpectedEntryDate;		//预计入职日期
	@DateTimeFormat(pattern="yyyy/MM/dd")
	private Date entryConfirmedEntryDate;		//确认入职日期
	private String entryStatus;					//待入职状态
	
	//构造函数
	public Entry() {
		this.entryStatus="待入职";
	}
	//getters
	@Column(nullable=false)
	public Long getInterviewId() {
		return interviewId;
	}
	@Column(nullable=false)
	public Long getResumeId() {
		return resumeId;
	}
	@Column(nullable=false)
	public String getEntryName() {
		return entryName;
	}
	@Column(nullable=false)
	public String getEntrySex() {
		return entrySex;
	}
	public String getEntrybranch() {
		return entrybranch;
	}
	@Column(nullable=false)
	public String getEntryposition() {
		return entryposition;
	}
	@Column(nullable=false)
	public String getEntryTel() {
		return entryTel;
	}
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getEntryExpectedEntryDate() {
		return entryExpectedEntryDate;
	}
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getEntryConfirmedEntryDate() {
		return entryConfirmedEntryDate;
	}
	@Column(nullable=false,columnDefinition="varchar(255) default '待入职'")
	public String getEntryStatus() {
		return entryStatus;
	}
	//setters
	public void setInterviewId(Long interviewId) {
		this.interviewId = interviewId;
	}
	public void setResumeId(Long resumeId) {
		this.resumeId = resumeId;
	}
	public void setEntryName(String entryName) {
		this.entryName = entryName;
	}
	public void setEntrySex(String entrySex) {
		this.entrySex = entrySex;
	}
	public void setEntrybranch(String entrybranch) {
		this.entrybranch = entrybranch;
	}
	public void setEntryposition(String entryposition) {
		this.entryposition = entryposition;
	}
	public void setEntryTel(String entryTel) {
		this.entryTel = entryTel;
	}
	public void setEntryExpectedEntryDate(Date entryExpectedEntryDate) {
		this.entryExpectedEntryDate = entryExpectedEntryDate;
	}
	public void setEntryConfirmedEntryDate(Date entryConfirmedEntryDate) {
		this.entryConfirmedEntryDate = entryConfirmedEntryDate;
	}
	public void setEntryStatus(String entryStatus) {
		this.entryStatus = entryStatus;
	}
}