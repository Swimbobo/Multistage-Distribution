package com.hrs.zhanshiyang.log.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.zhanshiyang.log.domain.Log;
import com.hrs.zhanshiyang.log.service.ILogService;

@RestController
public class LoginController {
	@Autowired
	private ILogService logService;
	
    /* 登录系统*/
	@RequestMapping(value = "/login")
    public @ResponseBody ExtAjaxResponse log(@RequestParam("employeeId") String employeeId, @RequestParam("logPassword") String logPassword, HttpSession session) {
        Log log=logService.Login(employeeId, logPassword);
        if(log!=null) {
		    SessionUtil.setUser(session, log);
		    session.setAttribute("employeeId",employeeId);
		    Map<String,String> map=new HashMap<String, String>();
		    map.put("employeeId", employeeId);
            map.put("msg", "登录成功!");
            return new ExtAjaxResponse(true,map);
        } else {
        	return new ExtAjaxResponse(false,"登录失败!帐号或者密码有误!请重新登录!");
        }
    }
//	@RequestMapping(value = "/reset")
//    public @ResponseBody ExtAjaxResponse reset(@RequestParam("employeeId") String employeeId, @RequestParam("logPassword") String logPassword, @RequestParam("logNewPassword") String logNewPassword) {
//        Log log=logService.Login(employeeId, logPassword);
//        if(log!=null) {
//        	System.out.println(log.getEmployeeId());
//	        log.setLogPassword(logNewPassword);
//	    	logService.saveByEntity(log);
//		    Map<String,String> map=new HashMap<String, String>();
//            map.put("msg", "修改成功!");
//            return new ExtAjaxResponse(true,map);
//        } else {
//        	return new ExtAjaxResponse(false,"修改失败!帐号或者密码有误!");
//        }
//    }
	/*注销*/
	 @RequestMapping(value = "/logout")
    public @ResponseBody ExtAjaxResponse logout(HttpSession session){
    	try {
    		SessionUtil.removeAttribute(session);
        	return new ExtAjaxResponse(true,"登出成功!");
		} catch (Exception e) {
			return new ExtAjaxResponse(false,"登出失败!");
		}
    }
	 @PostMapping("/getSession")
	 public ExtAjaxResponse getSession() {
		HttpServletRequest request=((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session=request.getSession();
		String id=SessionUtil.getEmployeeId(session);
		String name=SessionUtil.getEmployeeName(session);
		Map<String,String> map=new HashMap<String,String>();
		map.put("EmployeeId",id);
		map.put("EmployeeName",name);
		return new ExtAjaxResponse(true,map);
	}
}