package com.hrs.zhanshiyang.record.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_record")
public class Record extends BaseDomain<Long> {
	private String employeeId;//员工工号ID
	private String recordContent;//操作内容
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date recordTime;//操作时间
	
//	getters
	@Column(nullable=false)
	public String getEmployeeId() {
		return employeeId;
	}
	@Column(nullable=false)
	public String getRecordContent() {
		return recordContent;
	}
	@Column(nullable=false)
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getRecordTime() {
		return recordTime;
	}
	
//	setters
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setRecordContent(String recordContent) {
		this.recordContent = recordContent;
	}
	public void setRecordTime(Date recordTime) {
		this.recordTime = recordTime;
	}
}
