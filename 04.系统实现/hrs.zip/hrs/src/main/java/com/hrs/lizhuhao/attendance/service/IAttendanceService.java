package com.hrs.lizhuhao.attendance.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import com.hrs.lizhuhao.attendance.domain.Attendance;
import com.hrs.lizhuhao.attendance.domain.AttendanceDTO;

public interface IAttendanceService {
	public void save(AttendanceDTO dto);		//增加对象
	public AttendanceDTO findById(Long id);		//通过ID查找对象
	public boolean existsById(Long id);			//通过id判断是否存在对象
	public long count();						//统计表中数据总数
	public void deleteById(Long id);			//通过ID删除对象
	public void deleteAll(Long[] ids);			//批量删除对象
	public List<AttendanceDTO> findByIdDate(String employeeId,String attendanceDate);
	public Page<AttendanceDTO> findAll(Specification<Attendance> spec,Pageable pageable);//分页查询	
}