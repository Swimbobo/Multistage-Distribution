package com.hrs.zhanshiyang.log.domain;

import com.hrs.common.beans.BeanUtils;

public class LogDTO {
	private Long id;
	private String employeeId;//员工工号ID
	private String employeeName;//员工姓名
	private String logPassword;//员工登录密码（初始密码为123456）
	private String logPermission;//员工的权限设置（0-9，权限逐级递减，默认权限最小）
	
	public Long getId() {
		return id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public String getLogPassword() {
		return logPassword;
	}
	public String getLogPermission() {
		return logPermission;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setLogPassword(String logPassword) {
		this.logPassword = logPassword;
	}
	public void setLogPermission(String logPermission) {
		this.logPermission = logPermission;
	}
	
	//前端到后台（接收表单数据）:save 和 update	如何维护关联关系？
	public  static void dto2Entity(LogDTO dto ,Log entity) {
		BeanUtils.copyProperties(dto, entity);	
	}
	//后台到前端（返回JSON数据）：find	显示什么数据？
	public  static void entity2Dto(Log entity ,LogDTO dto) {
		BeanUtils.copyProperties(entity , dto);
	}	
}