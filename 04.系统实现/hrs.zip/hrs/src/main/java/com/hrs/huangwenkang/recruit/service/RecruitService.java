package com.hrs.huangwenkang.recruit.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.huangwenkang.recruit.dao.RecruitDao;
import com.hrs.huangwenkang.recruit.domain.Recruit;
import com.hrs.huangwenkang.recruit.domain.RecruitDTO;

@Service
@Transactional
public class RecruitService implements IRecruitService{
	@Autowired
	private RecruitDao recruitDao;
	
	//增加对象
	public Recruit save(RecruitDTO dto) {
		Recruit entity=new Recruit();
		RecruitDTO.dto2Entity(dto, entity);
		return recruitDao.save(entity);
	}
	//通过id删除对象
	public void deleteById(Long id) {
		recruitDao.deleteById(id);
	}
	//批量删除
	public void deleteAll(Long[] ids) {
		List<Long> idLists = new ArrayList<Long>(Arrays.asList(ids));
		List<Recruit> recruits = (List<Recruit>) recruitDao.findAllById(idLists);
		if(recruits!=null) {
			recruitDao.deleteAll(recruits);
		}
	}
	//通过ID查找对象
	public RecruitDTO findById(Long id) {
		Recruit entity=recruitDao.findById(id).get();
		RecruitDTO dto=new RecruitDTO();
		RecruitDTO.entity2Dto(entity, dto);
		return dto;
	}
	//通过id判断是否存在对象
	public boolean existsById(Long id) {
		return recruitDao.existsById(id);
	}
	//统计表中数据总数
	public long count() {
		return recruitDao.count();
	}
	//查看全部
	public Page<RecruitDTO> findAll(Specification<Recruit> spec, Pageable pageable) {
		Page<Recruit> entityList=recruitDao.findAll(spec,pageable);
		List<RecruitDTO> dtoList = new ArrayList<RecruitDTO>();
		for(Recruit entity:entityList) {
			RecruitDTO dto=new RecruitDTO();
			RecruitDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return new PageImpl<RecruitDTO>(dtoList,pageable,entityList.getTotalElements());
	}
}