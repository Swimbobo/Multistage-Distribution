package com.hrs.lizhuhao.overtime.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.hrs.lizhuhao.overtime.dao.OvertimeDao;
import com.hrs.lizhuhao.overtime.domain.Overtime;
import com.hrs.lizhuhao.overtime.domain.OvertimeDTO;

@Service
@Transactional
public class OvertimeService implements IOvertimeService {
	@Autowired
	private OvertimeDao overtimeDao;
	
	//增加对象
	public void save(OvertimeDTO dto) {
		Overtime entity=new Overtime();
		OvertimeDTO.dto2Entity(dto, entity);
        overtimeDao.save(entity);
	}
	//通过id删除对象
	public void deleteById(Long id) {
		overtimeDao.deleteById(id);
	}
	//批量删除
	public void deleteAll(Long[] ids) {
		List<Long> idLists = new ArrayList<Long>(Arrays.asList(ids));
		List<Overtime> overtimes = (List<Overtime>)overtimeDao.findAllById(idLists);
		if(overtimes!=null) {
			overtimeDao.deleteAll(overtimes);
		}
	}
	//通过ID查找对象
	@Transactional(readOnly=true)
	public OvertimeDTO findById(Long id) {
		Overtime entity=overtimeDao.findById(id).get();
		OvertimeDTO dto=new OvertimeDTO();
		OvertimeDTO.entity2Dto(entity, dto);
		return dto;
	}
	//查看全部
	@Override
	public Page<OvertimeDTO> findAll(Specification<Overtime> spec, Pageable pageable) {
		Page<Overtime> entityList=overtimeDao.findAll(spec,pageable);
		List<OvertimeDTO> dtoList = new ArrayList<OvertimeDTO>();
		for(Overtime entity:entityList) {
			OvertimeDTO dto=new OvertimeDTO();
			OvertimeDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return new PageImpl<OvertimeDTO>(dtoList,pageable,entityList.getTotalElements());
	}
	//统计表中数据总数
	public long count() {
		return overtimeDao.count();
	}
}