package com.hrs.zhanshiyang.bonus.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_bonus")
public class Bonus extends BaseDomain<Long> {
	private String employeeId;//员工工号ID
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date bonusYM;//奖金时间（年月）
	private String bonusStyle;//奖金简述
	private BigDecimal bonusSum;//奖金金额
	private String bonusAddName;//录入管理员名字
	private String bonusRemark;//备注
	
//	getters
	@Column(name="employeeId",nullable=false)
	public String getEmployeeId() {
		return employeeId;
	}
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	@Column(name="bonusYM",nullable=false)
	public Date getBonusYM() {
		return bonusYM;
	}
	@Column(name="bonusStyle",nullable=false)
	public String getBonusStyle() {
		return bonusStyle;
	}
	@Column(name="bonusSum",nullable=false,scale=2)
	public BigDecimal getBonusSum() {
		return bonusSum;
	}
	@Column(name="bonusAddName",nullable=false)
	public String getBonusAddName() {
		return bonusAddName;
	}
	@Column(name="bonusRemark")
	public String getBonusRemark() {
		return bonusRemark;
	}
	
//	setters
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setBonusYM(Date bonusYM) {
		this.bonusYM = bonusYM;
	}
	public void setBonusStyle(String bonusStyle) {
		this.bonusStyle = bonusStyle;
	}
	public void setBonusSum(BigDecimal bonusSum) {
		this.bonusSum = bonusSum;
	}
	public void setBonusAddName(String bonusAddName) {
		this.bonusAddName = bonusAddName;
	}
	public void setBonusRemark(String bonusRemark) {
		this.bonusRemark = bonusRemark;
	}
}
