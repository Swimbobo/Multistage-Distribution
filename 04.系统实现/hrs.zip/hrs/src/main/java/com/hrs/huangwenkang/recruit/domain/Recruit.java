package com.hrs.huangwenkang.recruit.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_recruit")
public class Recruit extends BaseDomain<Long>{
	private String recruitJob;				//需求职位
	private int recruitNumber;				//招聘人数
	private String recruitRequirement;		//岗位需求
	private String recruitTreatment;		//公司待遇
	private String recruitAbout;			//关于公司
	
	public Recruit() {
		this.recruitTreatment="待遇非常好";
		this.recruitAbout="我们是一家很好的公司";
	}
	//getters
	@Column(nullable=false)
	public String getRecruitJob() {
		return recruitJob;
	}
	@Column(nullable=false)
	public int getRecruitNumber() {
		return recruitNumber;
	}
	@Column(nullable=false)
	public String getRecruitRequirement() {
		return recruitRequirement;
	}
	@Column(nullable=false,columnDefinition="varchar(255) default '待遇非常好'")
	public String getRecruitTreatment() {
		return recruitTreatment;
	}
	@Column(nullable=false,columnDefinition="varchar(255) default '我们是一家很好的公司'")
	public String getRecruitAbout() {
		return recruitAbout;
	}
	//setters
	public void setRecruitJob(String recruitJob) {
		this.recruitJob = recruitJob;
	}
	public void setRecruitNumber(int recruitNumber) {
		this.recruitNumber = recruitNumber;
	}
	public void setRecruitRequirement(String recruitRequirement) {
		this.recruitRequirement = recruitRequirement;
	}
	public void setRecruitTreatment(String recruitTreatment) {
		this.recruitTreatment = recruitTreatment;
	}
	public void setRecruitAbout(String recruitAbout) {
		this.recruitAbout = recruitAbout;
	}
}