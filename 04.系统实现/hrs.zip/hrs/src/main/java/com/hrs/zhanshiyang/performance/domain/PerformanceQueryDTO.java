package com.hrs.zhanshiyang.performance.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.zhanshiyang.template.domain.Template;

public class PerformanceQueryDTO {
	private Long id;
	private String employeeId;//员工工号ID
	private Long performanceFractionFrom;//员工的绩效分数
	private Long performanceFractionTo;//员工的绩效分数
	private String performanceContent;//经理对属下员工的评估内容描述
	private Boolean performanceStatus;//评估状态（默认值为0，评估完成为1）
	private String performanceAssessName;//评估人的名字（自动获取）
	private String performanceStaffName;//被评估人的名字（模板发布时自动获取）
	
	private String templateHead;//评估模板标题
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date templateTimeStart;//搜索时间的左边界
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date templateTimeEnd;//搜索时间的右边界
	
	public Long getId() {
		return id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public Long getPerformanceFractionFrom() {
		return performanceFractionFrom;
	}
	public Long getPerformanceFractionTo() {
		return performanceFractionTo;
	}
	public String getPerformanceContent() {
		return performanceContent;
	}
	public Boolean getPerformanceStatus() {
		return performanceStatus;
	}
	public String getPerformanceAssessName() {
		return performanceAssessName;
	}
	public String getPerformanceStaffName() {
		return performanceStaffName;
	}
	public String getTemplateHead() {
		return templateHead;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getTemplateTimeStart() {
		return templateTimeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getTemplateTimeEnd() {
		return templateTimeEnd;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setPerformanceFractionFrom(Long performanceFractionFrom) {
		this.performanceFractionFrom = performanceFractionFrom;
	}
	public void setPerformanceFractionTo(Long performanceFractionTo) {
		this.performanceFractionTo = performanceFractionTo;
	}
	public void setPerformanceContent(String performanceContent) {
		this.performanceContent = performanceContent;
	}
	public void setPerformanceStatus(Boolean performanceStatus) {
		this.performanceStatus = performanceStatus;
	}
	public void setPerformanceAssessName(String performanceAssessName) {
		this.performanceAssessName = performanceAssessName;
	}
	public void setPerformanceStaffName(String performanceStaffName) {
		this.performanceStaffName = performanceStaffName;
	}
	public void setTemplateHead(String templateHead) {
		this.templateHead = templateHead;
	}
	public void setTemplateTimeStart(Date templateTimeStart) {
		this.templateTimeStart = templateTimeStart;
	}
	public void setTemplateTimeEnd(Date templateTimeEnd) {
		this.templateTimeEnd = templateTimeEnd;
	}
	
	@SuppressWarnings({ "serial"})
	public static Specification<Performance> getWhereClause(final PerformanceQueryDTO performanceQueryDTO) {
		return new Specification<Performance>() {
			@Override
			public Predicate toPredicate(Root<Performance> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
			
				List<Predicate> predicate = new ArrayList<>();
				
				if (StringUtils.isNotBlank(performanceQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + performanceQueryDTO.getEmployeeId() + "%"));
				}
				if (null!=performanceQueryDTO.getPerformanceFractionFrom()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("performanceFraction").as(Long.class),
							performanceQueryDTO.getPerformanceFractionFrom()));
				}
				if (null!=performanceQueryDTO.getPerformanceFractionTo()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("performanceFraction").as(Long.class),
							performanceQueryDTO.getPerformanceFractionTo()));
				}
				if (StringUtils.isNotBlank(performanceQueryDTO.getPerformanceContent())) {
					predicate.add(criteriaBuilder.like(root.get("performanceContent").as(String.class),
							"%" + performanceQueryDTO.getPerformanceContent() + "%"));
				}
				if (null!=performanceQueryDTO.getPerformanceStatus()) {
					predicate.add(criteriaBuilder.equal(root.get("performanceStatus").as(Boolean.class),
							performanceQueryDTO.getPerformanceStatus()));
				}
				if (StringUtils.isNotBlank(performanceQueryDTO.getPerformanceAssessName())) {
					predicate.add(criteriaBuilder.like(root.get("performanceAssessName").as(String.class),
							"%" + performanceQueryDTO.getPerformanceAssessName() + "%"));
				}
				if (StringUtils.isNotBlank(performanceQueryDTO.getPerformanceStaffName())) {
					predicate.add(criteriaBuilder.like(root.get("performanceStaffName").as(String.class),
							"%" + performanceQueryDTO.getPerformanceStaffName() + "%"));
				}
				
				if (StringUtils.isNotBlank(performanceQueryDTO.getTemplateHead())) {
					Join<Performance,Template> join=root.join("template",JoinType.LEFT);
					predicate.add(criteriaBuilder.like(join.get("templateHead").as(String.class),
							"%" + performanceQueryDTO.getTemplateHead() + "%"));
				}
				if (null!=performanceQueryDTO.getTemplateTimeStart()) {
					Join<Performance,Template> join=root.join("template",JoinType.LEFT);
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(join.get("templateTimeStart").as(Date.class),
							performanceQueryDTO.getTemplateTimeStart()));
				}
				if (null!=performanceQueryDTO.getTemplateTimeEnd()) {
					Join<Performance,Template> join=root.join("template",JoinType.LEFT);
					predicate.add(criteriaBuilder.lessThanOrEqualTo(join.get("templateTimeEnd").as(Date.class),
							performanceQueryDTO.getTemplateTimeEnd()));
				}
				
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}
