package com.hrs.zhanshiyang.record.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.zhanshiyang.record.domain.Record;

@Repository
public interface RecordDao extends 
		PagingAndSortingRepository<Record,Long>,JpaSpecificationExecutor<Record>
{

}
