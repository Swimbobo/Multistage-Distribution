package com.hrs.youzhenjie.contract.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.youzhenjie.contract.domain.Contract;
import com.hrs.youzhenjie.contract.domain.ContractAndEmployeeDTO;
import com.hrs.youzhenjie.employee.domain.Employee;

public interface IContractService {
	/*
	 * 查
	 */
	// 通过ID查询
	public ContractAndEmployeeDTO searchById(Long id);

	// 查询所有(没有分页)
	public List<ContractAndEmployeeDTO> searchAll();

	// 查询所有(分页）
	public Page<ContractAndEmployeeDTO> searchAllByPage(Specification<Contract> sepc, Pageable pageable);

	//通过名字查询
		public Contract findByEmployeeId(String name);
	/*
	 * 增&&改&& 删 软删除： 删除员工相当于update员工的在职状态为0
	 */
	public void saveOrUpdate(ContractAndEmployeeDTO contract);

	//测试
	
	public void save(Contract contract);
	// 预留删除接口：
	public void deleteById(Long id);

	public void deleteAll(Long[] ids);

	// 统计
	public long count();

	// 是否存在
	public boolean existsById(Long id);

}
