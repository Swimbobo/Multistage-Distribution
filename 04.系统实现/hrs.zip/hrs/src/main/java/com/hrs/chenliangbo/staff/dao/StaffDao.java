package com.hrs.chenliangbo.staff.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import com.hrs.chenliangbo.staff.domain.Staff;

@Repository
public interface StaffDao extends PagingAndSortingRepository<Staff,Long>,JpaSpecificationExecutor<Staff> {}