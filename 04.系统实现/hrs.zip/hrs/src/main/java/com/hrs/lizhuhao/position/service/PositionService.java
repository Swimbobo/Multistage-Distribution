package com.hrs.lizhuhao.position.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.lizhuhao.position.dao.PositionDao;
import com.hrs.lizhuhao.position.domain.Position;
import com.hrs.lizhuhao.position.domain.PositionDTO;

@Service
@Transactional
public class PositionService implements IPositionService {
	@Autowired
	private PositionDao positionDao;
	
	//增加对象
	@SuppressWarnings("static-access")
	public void save(PositionDTO dto) {
		Position entity=new Position();
		dto.dto2Entity(dto, entity);
        positionDao.save(entity);
	}
	//通过id删除对象
	public void deleteById(Long id) {
		positionDao.deleteById(id);
	}
	//批量删除
	public void deleteAll(Long[] ids) {
		List<Long> idLists = new ArrayList<Long>(Arrays.asList(ids));
		List<Position> positions = (List<Position>) positionDao.findAllById(idLists);
		if(positions!=null) {
			positionDao.deleteAll(positions);
		}
	}
	//通过ID查找对象
	@Transactional(readOnly=true)
	public PositionDTO findById(Long id) {
		Position entity=positionDao.findById(id).get();
		PositionDTO dto=new PositionDTO();
		PositionDTO.entity2Dto(entity, dto);
		return dto;
	
	}
	//通过id判断是否存在对象
	public boolean existsById(Long id) {
		return positionDao.existsById(id);
	}
	//统计表中数据总数
	public long count() {
		return positionDao.count();
	}
	//通过职位名查找对应的部门
	public List<PositionDTO> findBranchName(String positionName) {
		List<Position> entityList=positionDao.findBranchName(positionName);
		List<PositionDTO> dtoList = new ArrayList<PositionDTO>();
		for (Position entity : entityList) {
			PositionDTO dto=new PositionDTO();
			PositionDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return dtoList;
	}
	//通过部门名查找对应的职位
	public List<PositionDTO> findPosition(String branchName) {
		List<Position> entityList=positionDao.findPosition(branchName);
		List<PositionDTO> dtoList = new ArrayList<PositionDTO>();
		for (Position entity : entityList) {
			PositionDTO dto=new PositionDTO();
			PositionDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return dtoList;
	}
	//查看全部
	public Page<PositionDTO> findAll(Specification<Position> spec, Pageable pageable) {
		Page<Position> entityList=positionDao.findAll(spec,pageable);
		List<PositionDTO> dtoList = new ArrayList<PositionDTO>();
		for(Position entity:entityList) {
			PositionDTO dto=new PositionDTO();
			PositionDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return new PageImpl<PositionDTO>(dtoList,pageable,entityList.getTotalElements());
	}
	//删除全部
	public void deleteAll(List<PositionDTO> dtoLists) {
		List<Position> entities = new ArrayList<Position>();
		for (PositionDTO positionDTO : dtoLists) {
			Position entity = new Position();
			PositionDTO.dto2Entity(positionDTO, entity);
			entities.add(entity);
		}
		positionDao.deleteAll(entities);
	}
}