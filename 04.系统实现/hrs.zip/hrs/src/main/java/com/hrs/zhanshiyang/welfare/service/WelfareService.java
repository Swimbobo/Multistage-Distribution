package com.hrs.zhanshiyang.welfare.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.zhanshiyang.welfare.dao.WelfareDao;
import com.hrs.zhanshiyang.welfare.domain.Welfare;
import com.hrs.zhanshiyang.welfare.domain.WelfareDTO;
import com.hrs.zhanshiyang.welfare.service.IWelfareService;

@Service
@Transactional
public class WelfareService implements IWelfareService 
{
	@Autowired
	private WelfareDao welfareDao;

	@Transactional
	public void save(WelfareDTO dto) {
		Welfare entity = new Welfare();
		WelfareDTO.dto2Entity(dto, entity);
		welfareDao.save(entity);
	}
	
	@Transactional
	public WelfareDTO findById(Long id) {
		Welfare entity = welfareDao.findById(id).get();
		WelfareDTO dto = new WelfareDTO();
		WelfareDTO.entity2Dto(entity, dto);
		return dto;
	}

	public void deleteById(Long id) {
		welfareDao.deleteById(id);
	}

	public void deleteAll(List<WelfareDTO> dtoLists) {
		List<Welfare> entities = new ArrayList<Welfare>();
		
		for (WelfareDTO dto : dtoLists) {
			Welfare entity = new Welfare();
			WelfareDTO.dto2Entity(dto, entity);
			entities.add(entity);
		}
		welfareDao.deleteAll(entities);
	}

	public Page<WelfareDTO> findAll(Specification<Welfare> spec, Pageable pageable) {
		Page<Welfare> entities = welfareDao.findAll(spec,pageable);
		
		List<WelfareDTO> dtoLists = new ArrayList<WelfareDTO>();
		for (Welfare entity : entities) {
			WelfareDTO dto = new WelfareDTO();
			WelfareDTO.entity2Dto(entity, dto);
			dtoLists.add(dto);
		}
		return new PageImpl<WelfareDTO>(dtoLists, pageable, entities.getTotalElements());
	}

}
