package com.hrs.common.beans;
import java.util.ArrayList;
import java.util.List;

public class NavigationTree {
	private boolean expended;
	private String text;    //文本信息
	private String iconCls; //图标
	private String viewType;//视图
	private boolean leaf;   //是否叶子节点
	private boolean selectable; //是否可选
	private List<NavigationTree> children = new ArrayList<>(); //子节点

	public NavigationTree(boolean expended, String text, String iconCls,String viewType, boolean leaf,boolean selectable, List<NavigationTree> childrens) {
		this.expended = expended;
		this.text = text;
		this.iconCls = iconCls;
		this.viewType = viewType;
		this.leaf = leaf;
		this.selectable = selectable;
		this.children = childrens;
	}

	public boolean isExpended() {
		return expended;
	}

	public void setExpended(boolean expended) {
		this.expended = expended;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getIconCls() {
		return iconCls;
	}

	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}

	public boolean isLeaf() {
		return leaf;
	}

	public void setLeaf(boolean leaf) {
		this.leaf = leaf;
	}

	public boolean isSelectable() {
		return selectable;
	}

	public void setSelectable(boolean selectable) {
		this.selectable = selectable;
	}

	public List<NavigationTree> getChildren() {
		return children;
	}

	public void setChildren(List<NavigationTree> children) {
		this.children = children;
	}

	public String getViewType() {
		return viewType;
	}

	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	
}
