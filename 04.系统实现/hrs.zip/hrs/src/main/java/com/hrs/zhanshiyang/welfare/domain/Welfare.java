package com.hrs.zhanshiyang.welfare.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_welfare")
public class Welfare extends BaseDomain<Long> {
	private String employeeId;//员工工号ID
	@DateTimeFormat(pattern = "yyyy/MM")
	private Date welfareYM;//福利时间（年月）
	private String welfareStyle;//福利简述
	private BigDecimal welfareSum;//福利金额
	private String welfareAddName;//录入管理员名字
	private String welfareRemark;//备注
	
//	getters
	@Column(nullable=false)
	public String getEmployeeId() {
		return employeeId;
	}
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM",timezone="GMT+8")
	@Column(nullable=false)
	public Date getWelfareYM() {
		return welfareYM;
	}
	@Column(nullable=false)
	public String getWelfareStyle() {
		return welfareStyle;
	}
	@Column(nullable=false,scale=2)
	public BigDecimal getWelfareSum() {
		return welfareSum;
	}
	@Column(nullable=false)
	public String getWelfareAddName() {
		return welfareAddName;
	}
	public String getWelfareRemark() {
		return welfareRemark;
	}
	
//	setters
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setWelfareYM(Date welfareYM) {
		this.welfareYM = welfareYM;
	}
	public void setWelfareStyle(String welfareStyle) {
		this.welfareStyle = welfareStyle;
	}
	public void setWelfareSum(BigDecimal welfareSum) {
		this.welfareSum = welfareSum;
	}
	public void setWelfareAddName(String welfareAddName) {
		this.welfareAddName = welfareAddName;
	}
	public void setWelfareRemark(String welfareRemark) {
		this.welfareRemark = welfareRemark;
	}
}
