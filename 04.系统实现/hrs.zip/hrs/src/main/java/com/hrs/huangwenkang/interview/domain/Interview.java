package com.hrs.huangwenkang.interview.domain;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;

import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_interview")
public class Interview extends BaseDomain<Long>{
	private Long resumeId;						//简历表id
	private String interviewName;				//面试者姓名
	private String interviewSex;				//面试者性别
	private String interviewTel;				//面试者联系电话
	private String interviewEduBackground;		//面试者最高学历
	private String interviewJobWanted;			//面试职位
	@DateTimeFormat(pattern="yyyy/MM/dd HH:mm:ss")
	private Date interviewTime;					//面试时间
	private String interviewPlace;				//面试地点
	private String interviewComment;			//面试评语
	private String interviewRes;				//面试结果
	
	//构造函数
	public Interview() {
		this.interviewPlace="公司本部";
		this.interviewRes="等待面试";
	}
	//getters
	@Column(nullable=false)
	public Long getResumeId() {
		return resumeId;
	}
	@Column(nullable=false)
	public String getInterviewName() {
		return interviewName;
	}
	@Column(nullable=false)
	public String getInterviewSex() {
		return interviewSex;
	}
	@Column(nullable=false)
	public String getInterviewTel() {
		return interviewTel;
	}
	@Column(nullable=false)
	public String getInterviewEduBackground() {
		return interviewEduBackground;
	}
	@Column(nullable=false)
	public String getInterviewJobWanted() {
		return interviewJobWanted;
	}
	//显示XXXX/XX/XX xx:xx:xxx
	@Column(nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getInterviewTime() {
		return interviewTime;
	}
	@Column(nullable=false,columnDefinition="varchar(255) default '公司本部'")
	public String getInterviewPlace() {
		return interviewPlace;
	}
	public String getInterviewComment() {
		return interviewComment;
	}
	@Column(nullable=false,columnDefinition="varchar(255) default '等待面试'")
	public String getInterviewRes() {
		return interviewRes;
	}
	//setters
	public void setResumeId(Long resumeId) {
		this.resumeId = resumeId;
	}
	public void setInterviewName(String interviewName) {
		this.interviewName = interviewName;
	}
	public void setInterviewSex(String interviewSex) {
		this.interviewSex = interviewSex;
	}
	public void setInterviewTel(String interviewTel) {
		this.interviewTel = interviewTel;
	}
	public void setInterviewEduBackground(String interviewEduBackground) {
		this.interviewEduBackground = interviewEduBackground;
	}
	public void setInterviewJobWanted(String interviewJobWanted) {
		this.interviewJobWanted = interviewJobWanted;
	}
	public void setInterviewTime(Date interviewTime) {
		this.interviewTime = interviewTime;
	}
	public void setInterviewPlace(String interviewPlace) {
		this.interviewPlace = interviewPlace;
	}
	public void setInterviewComment(String interviewComment) {
		this.interviewComment = interviewComment;
	}
	public void setInterviewRes(String interviewRes) {
		this.interviewRes = interviewRes;
	}
}