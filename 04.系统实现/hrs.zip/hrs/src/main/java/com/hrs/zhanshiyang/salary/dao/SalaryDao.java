package com.hrs.zhanshiyang.salary.dao;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.zhanshiyang.salary.domain.Salary;

@Repository
public interface SalaryDao extends 
PagingAndSortingRepository<Salary,Long>,JpaSpecificationExecutor<Salary>{
	//查找奖金表
	@Query(value="select sum(bonusSum) from t_bonus where employeeId=?1 and date_format(bonusYM,'%Y-%m')=?2",nativeQuery=true)
	public BigDecimal findBonus(String employeeId,String date);
	//查找福利表
	@Query(value="select sum(welfareSum) from t_welfare where employeeId=?1 and date_format(welfareYM,'%Y-%m')=?2",nativeQuery=true)
	public BigDecimal findWelfare(String employeeId,String date);
	//查找合同表
	@Query(value="select contractSalary from t_contract where employeeId=?1",nativeQuery=true)
	public BigDecimal findContract(String employeeId);
	//查找考勤表
	@Query(value="select count(attendanceStatus) from t_attendance where employeeId=?1 and date_format(attendanceDate,'%Y-%m')=?2 and attendanceStatus='出勤'",nativeQuery=true)
	public int findAttendance(String employeeId,String date);
	//查找加班表
	@Query(value="select sum(hour) from t_overtime where employeeId=?1 and date_format(overtimeDate,'%Y-%m')=?2 and overtimeStatus='审核通过'",nativeQuery=true)
	//public int findOvertime(String employeeId,String date);
	public String findOvertime(String employeeId,String date);
	//查找请假
	@Query(value="select sum(days) from t_leave where employeeId=?1 and date_format(leaveEndTime,'%Y-%m')=?2 and leaveProcessStatus='通过' and leaveType='事假'",nativeQuery=true)
	public String findLeave(String employeeId,String date);
	//查找出差
	@Query(value="select sum(days) from t_leave where employeeId=?1 and date_format(leaveEndTime,'%Y-%m')=?2 and leaveProcessStatus='通过' and leaveType='出差'",nativeQuery=true)
	public String findBusiniss(String employeeId,String date);
}