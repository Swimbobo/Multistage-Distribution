package com.hrs.lizhuhao.branch.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.lizhuhao.branch.domain.Branch;

@Repository
public interface BranchDao extends PagingAndSortingRepository<Branch,Long>,JpaSpecificationExecutor<Branch>{}