package com.hrs.zhanshiyang.template.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class TemplateQueryDTO {
	private String templateHead;//评估模板标题
	private Boolean templateStatus;//评估模板的发布状态（默认值为false，评估完成为true）
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date templateTimeStart;//搜索时间的左边界
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date templateTimeEnd;//搜索时间的右边界
	
	public String getTemplateHead() {
		return templateHead;
	}
	public Boolean getTemplateStatus() {
		return templateStatus;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getTemplateTimeStart() {
		return templateTimeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getTemplateTimeEnd() {
		return templateTimeEnd;
	}

	public void setTemplateHead(String templateHead) {
		this.templateHead = templateHead;
	}

	public void setTemplateStatus(Boolean templateStatus) {
		this.templateStatus = templateStatus;
	}

	public void setTemplateTimeStart(Date templateTimeStart) {
		this.templateTimeStart = templateTimeStart;
	}

	public void setTemplateTimeEnd(Date templateTimeEnd) {
		this.templateTimeEnd = templateTimeEnd;
	}

	@SuppressWarnings({ "serial"})
	public static Specification<Template> getWhereClause(final TemplateQueryDTO templateQueryDTO) {
		return new Specification<Template>() {
			@Override
			public Predicate toPredicate(Root<Template> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
			
				List<Predicate> predicate = new ArrayList<>();
				
				if (StringUtils.isNotBlank(templateQueryDTO.getTemplateHead())) {
					predicate.add(criteriaBuilder.like(root.get("templateHead").as(String.class),
							"%" + templateQueryDTO.getTemplateHead() + "%"));
				}
				if (null!=templateQueryDTO.getTemplateStatus()) {
					predicate.add(criteriaBuilder.equal(root.get("templateStatus").as(Boolean.class),
							templateQueryDTO.getTemplateStatus()));
				}
				if (null!=templateQueryDTO.getTemplateTimeStart()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("templateTimeEnd").as(Date.class),
							templateQueryDTO.getTemplateTimeStart()));
				}
				if (null!=templateQueryDTO.getTemplateTimeEnd()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("templateTimeEnd").as(Date.class),
							templateQueryDTO.getTemplateTimeEnd()));
				}
				
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}
