package com.hrs.lizhuhao.attendance.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_attendance")
public class Attendance extends BaseDomain<Long> {
	private String employeeId;			//员工工号
	private String employeeName;		//员工姓名
	@DateTimeFormat(pattern="yyyy/MM/dd")
	private Date attendanceDate;		//打卡年月日
	@DateTimeFormat(pattern="yyyy/MM/dd HH:mm:ss")
	private Date attendanceTimeOne;		//上班打卡时间
	@DateTimeFormat(pattern="yyyy/MM/dd HH:mm:ss")
	private Date attendanceTimeTwo;		//下班打卡时间
	private String attendanceStatus="缺勤";//出勤状态
	
	//getters
	@Column(nullable=false)
	public String getEmployeeId() {
		return employeeId;
	}
	@Column(nullable=false)
	public String getEmployeeName() {
		return employeeName;
	}
	@Column(nullable=false)
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getAttendanceDate() {
		return attendanceDate;
	}
	@Column(nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getAttendanceTimeOne() {
		return attendanceTimeOne;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	 public Date getAttendanceTimeTwo() {
		return attendanceTimeTwo;
	}
	@Column(nullable=false)
	public String getAttendanceStatus() {
		return attendanceStatus;
	}
	//setters
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setAttendanceDate(Date attendanceDate) {
		this.attendanceDate = attendanceDate;
	}
	public void setAttendanceTimeOne(Date attendanceTimeOne) {
		this.attendanceTimeOne = attendanceTimeOne;
	}
	public void setAttendanceTimeTwo(Date attendanceTimeTwo) {
		this.attendanceTimeTwo = attendanceTimeTwo;
	}
	public void setAttendanceStatus(String attendanceStatus) {
		this.attendanceStatus = attendanceStatus;
	}
}