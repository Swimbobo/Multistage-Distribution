package com.hrs.lizhuhao.branch.domain;

import com.hrs.common.beans.BeanUtils;

public class BranchDTO {
	private Long id;				//id
	private String branchName;		//部门名称
	private String employeeId;		//部门负责人工号
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	//前端到后台（接收表单数据）
	public static void dto2Entity(BranchDTO dto ,Branch entity) {
		BeanUtils.copyProperties(dto, entity);
	}
	//后台到前端（返回JSON数据）
	public  static void entity2Dto(Branch entity ,BranchDTO dto) {
		BeanUtils.copyProperties(entity,dto);
	}
}