package com.hrs.huangwenkang.recruit.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

public class RecruitQueryDTO {
	private String recruitJob;				//需求职位
	private String recruitNumber;			//招聘人数
	private String recruitRequirement;		//岗位需求
	private String recruitAbout;			//关于公司
	
	public String getRecruitJob() {
		return recruitJob;
	}
	public void setRecruitJob(String recruitJob) {
		this.recruitJob = recruitJob;
	}
	public String getRecruitNumber() {
		return recruitNumber;
	}
	public void setRecruitNumber(String recruitNumber) {
		this.recruitNumber = recruitNumber;
	}
	public String getRecruitRequirement() {
		return recruitRequirement;
	}
	public void setRecruitRequirement(String recruitRequirement) {
		this.recruitRequirement = recruitRequirement;
	}
	public String getRecruitAbout() {
		return recruitAbout;
	}
	public void setRecruitAbout(String recruitAbout) {
		this.recruitAbout = recruitAbout;
	}
	
	@SuppressWarnings({ "serial"})
	public static Specification<Recruit> getWhereClause(final RecruitQueryDTO recruitQueryDTO) {
		return new Specification<Recruit>() {
			@Override
			public Predicate toPredicate(Root<Recruit> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();
				if (StringUtils.isNotBlank(recruitQueryDTO.getRecruitJob())) {
					predicate.add(criteriaBuilder.like(root.get("recruitJob").as(String.class),
							"%" + recruitQueryDTO.getRecruitJob() + "%"));
				}
				if (StringUtils.isNotBlank(recruitQueryDTO.getRecruitNumber())) {
					predicate.add(criteriaBuilder.like(root.get("recruitNumber").as(String.class),
							"%"+recruitQueryDTO.getRecruitNumber()+"%"));
				}
				if (StringUtils.isNotBlank(recruitQueryDTO.getRecruitRequirement())) {
					predicate.add(criteriaBuilder.like(root.get("recruitRequirement").as(String.class),
							"%"+recruitQueryDTO.getRecruitRequirement()+"%"));
				}
				if (StringUtils.isNotBlank(recruitQueryDTO.getRecruitAbout())) {
					predicate.add(criteriaBuilder.like(root.get("recruitAbout").as(String.class),
							"%"+recruitQueryDTO.getRecruitAbout()+"%"));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}