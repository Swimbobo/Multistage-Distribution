package com.hrs.lizhuhao.position.domain;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_position")
public class Position extends BaseDomain<Long> {
	private String positionName;		//职位名称
    private String branchName;			//所属部门名称
    
    //getters
	@Column(nullable=false)
	public String getPositionName() {
		return positionName;
	}
	@Column(nullable=false)
	public String getBranchName() {
		return branchName;
	}
	//setters
	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
}