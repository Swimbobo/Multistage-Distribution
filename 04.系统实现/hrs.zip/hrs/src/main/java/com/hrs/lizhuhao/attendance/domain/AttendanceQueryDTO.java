package com.hrs.lizhuhao.attendance.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.SessionUtil;

public class AttendanceQueryDTO {
	private String employeeId;//工号
	private String employeeName;//员工姓名
	@DateTimeFormat(pattern="yyyy/MM/dd")  
	private Date timeStart;//开始日期
	@DateTimeFormat(pattern="yyyy/MM/dd") 
	private Date timeEnd;//开始日期
	private String attendanceStatus;//出勤状态
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getTimeStart() {
		return timeStart;
	}
	public void setTimeStart(Date timeStart) {
		this.timeStart = timeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getTimeEnd() {
		return timeEnd;
	}
	public void setTimeEnd(Date timeEnd) {
		this.timeEnd = timeEnd;
	}
	public String getAttendanceStatus() {
		return attendanceStatus;
	}
	public void setAttendanceStatus(String attendanceStatus) {
		this.attendanceStatus = attendanceStatus;
	}
	@SuppressWarnings({ "serial"})
	public static Specification<Attendance> getWhereClause(final AttendanceQueryDTO attendanceQueryDTO) {
		return new Specification<Attendance>() {
			@Override
			public Predicate toPredicate(Root<Attendance> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
			
				List<Predicate> predicate = new ArrayList<>();
				
				if (StringUtils.isNotBlank(attendanceQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + attendanceQueryDTO.getEmployeeId() + "%"));
				}
				if (StringUtils.isNotBlank(attendanceQueryDTO.getEmployeeName())) {
					predicate.add(criteriaBuilder.like(root.get("employeeName").as(String.class),
							"%" + attendanceQueryDTO.getEmployeeName() + "%"));
				}
				if (null!=attendanceQueryDTO.getTimeStart()){
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("attendanceDate").as(Date.class),
							attendanceQueryDTO.getTimeStart()));
				}
				if (null!=attendanceQueryDTO.getTimeEnd()){
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("attendanceDate").as(Date.class),
							attendanceQueryDTO.getTimeEnd()));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
				}
			};
		}
	@SuppressWarnings({ "serial"})
	public static Specification<Attendance> getWhereByEmployeeId(final AttendanceQueryDTO attendanceQueryDTO) {
		return new Specification<Attendance>() {
			@Override
			public Predicate toPredicate(Root<Attendance> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
			
				List<Predicate> predicate=new ArrayList<>();
				HttpServletRequest request=((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
				HttpSession session=request.getSession();
				String emp=SessionUtil.getEmployeeId(session);
				
				predicate.add(criteriaBuilder.equal(root.get("employeeId").as(String.class),emp));
				
				if (StringUtils.isNotBlank(attendanceQueryDTO.getEmployeeName())) {
					predicate.add(criteriaBuilder.like(root.get("employeeName").as(String.class),
							"%" + attendanceQueryDTO.getEmployeeName() + "%"));
				}
				if (null!=attendanceQueryDTO.getTimeStart()){
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("attendanceDate").as(Date.class),
							attendanceQueryDTO.getTimeStart()));
				}
				if (null!=attendanceQueryDTO.getTimeEnd()){
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("attendanceDate").as(Date.class),
							attendanceQueryDTO.getTimeEnd()));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}