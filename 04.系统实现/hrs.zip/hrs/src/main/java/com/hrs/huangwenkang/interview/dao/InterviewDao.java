package com.hrs.huangwenkang.interview.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.huangwenkang.interview.domain.Interview;

@Repository
public interface InterviewDao extends JpaSpecificationExecutor<Interview>,PagingAndSortingRepository<Interview,Long>{
	//修改面试表状态
	@Modifying
	@Query(value="update t_interview set interviewRes=?1 where id=?2",nativeQuery=true)
	public void updateInterviewRes(String interviewRes,Long id);
	
	@Modifying
	@Query(value="update t_interview set interviewComment=?1 where id=?2",nativeQuery=true)
	public void updateInterviewComment(String interviewComment,Long id);
}