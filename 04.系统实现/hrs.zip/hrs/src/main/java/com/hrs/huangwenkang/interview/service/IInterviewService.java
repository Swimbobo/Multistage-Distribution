package com.hrs.huangwenkang.interview.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.huangwenkang.interview.domain.Interview;
import com.hrs.huangwenkang.interview.domain.InterviewDTO;

public interface IInterviewService {
	public Interview save(InterviewDTO dto);		//增加对象
	public void deleteById(Long id);				//通过id删除对象
	public void deleteAll(Long[] ids);				//批量删除
	public InterviewDTO findById(Long id);			//通过id查找对象
	public boolean existsById(Long id);				//通过id判断是否存在对象
	public long count();							//统计表中数据总数
	public void updateInterviewRes(String interviewRes,Long id);//修改面试表状态
	public void updateinterviewComment(String interviewComment,Long id);//修改评语
	public Page<InterviewDTO> findAll(Specification<Interview> spec, Pageable pageable);
}