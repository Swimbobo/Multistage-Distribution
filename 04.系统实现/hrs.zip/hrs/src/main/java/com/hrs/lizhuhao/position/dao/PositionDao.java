package com.hrs.lizhuhao.position.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.lizhuhao.position.domain.Position;

@Repository
public interface PositionDao extends PagingAndSortingRepository<Position, Long>,JpaSpecificationExecutor<Position>{
	//通过职位名查找对应的部门
	@Query(value="select * from t_position where positionName=?1",nativeQuery=true)
	public List<Position> findBranchName(String positionName);
	
	//通过部门名查找对应的职位
	@Query(value="select * from t_position where branchName=?1",nativeQuery=true)
	public List<Position> findPosition(String branchName);
}