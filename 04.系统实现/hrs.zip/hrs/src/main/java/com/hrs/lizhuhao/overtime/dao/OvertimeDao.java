package com.hrs.lizhuhao.overtime.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.lizhuhao.overtime.domain.Overtime;

@Repository
public interface OvertimeDao extends PagingAndSortingRepository<Overtime, Long>,JpaSpecificationExecutor<Overtime> {
	public Overtime findByEmployeeId(String employeeId);
}