package com.hrs.zhanshiyang.performance.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.zhanshiyang.performance.domain.Performance;

@Repository
public interface PerformanceDao extends 
		PagingAndSortingRepository<Performance,Long>,JpaSpecificationExecutor<Performance>
{

}
