package com.hrs.zhanshiyang.bonus.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.zhanshiyang.bonus.dao.BonusDao;
import com.hrs.zhanshiyang.bonus.domain.Bonus;
import com.hrs.zhanshiyang.bonus.domain.BonusDTO;

@Service
@Transactional
public class BonusService implements IBonusService 
{
	@Autowired
	private BonusDao bonusDao;

	@Transactional
	public void save(BonusDTO dto) {
		Bonus entity = new Bonus();
		BonusDTO.dto2Entity(dto, entity);
		bonusDao.save(entity);
	}

	@Transactional
	public BonusDTO findById(Long id) {
		Bonus entity = bonusDao.findById(id).get();
		BonusDTO dto = new BonusDTO();
		BonusDTO.entity2Dto(entity, dto);
		return dto;
	}

	public void deleteById(Long id) {
		bonusDao.deleteById(id);
	}

	public void deleteAll(List<BonusDTO> dtoLists) {
		List<Bonus> entities = new ArrayList<Bonus>();
		
		for (BonusDTO dto : dtoLists) {
			Bonus entity = new Bonus();
			BonusDTO.dto2Entity(dto, entity);
			entities.add(entity);
		}
		bonusDao.deleteAll(entities);
	}

	public Page<BonusDTO> findAll(Specification<Bonus> spec, Pageable pageable) {
		Page<Bonus> entities = bonusDao.findAll(spec,pageable);
		
		List<BonusDTO> dtoLists = new ArrayList<BonusDTO>();
		for (Bonus entity : entities) {
			BonusDTO dto = new BonusDTO();
			BonusDTO.entity2Dto(entity, dto);
			dtoLists.add(dto);
		}
		return new PageImpl<BonusDTO>(dtoLists, pageable, entities.getTotalElements());
	}
}
