package com.hrs.chenliangbo.file.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.chenliangbo.file.domain.File;

@Repository
public interface FileDao extends PagingAndSortingRepository<File,Long>,JpaSpecificationExecutor<File>{
}