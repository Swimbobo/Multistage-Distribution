package com.hrs.chenliangbo.file.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.chenliangbo.file.dao.FileDao;
import com.hrs.chenliangbo.file.domain.File;
import com.hrs.chenliangbo.file.domain.FileDTO;

@Service
@Transactional(readOnly=true)
public class FileService implements IFileService{
	@Autowired
	private FileDao fileDao;
	
	@Transactional
	public void save(FileDTO filedto) {
		File file=new File();
		FileDTO.dto2Entity(filedto, file);
		fileDao.save(file);
	}

	@Transactional
	public void save(List<FileDTO> list) {
		List<File> filelist=new ArrayList<File>();
		for (FileDTO dto : list) {
			File file=new File();
			FileDTO.dto2Entity(dto, file);
			filelist.add(file);
			
		}
		fileDao.saveAll(filelist);
	}

	public FileDTO findById(Long id) {
		File file= fileDao.findById(id).get();
		FileDTO fileDTO=new FileDTO();
		FileDTO.entity2Dto(file, fileDTO);
		return fileDTO;
	}
	

	

	@Transactional
	public void deleteById(Long id) {
		fileDao.deleteById(id);
	}
	@Transactional
	public void delete(FileDTO filedto) {
		File file=new File();
		FileDTO.dto2Entity(filedto, file);
	    fileDao.delete(file);	
	}

	public Page<FileDTO> findAll(Specification<File> spec, Pageable pageable) {
		Page<File> entityList=fileDao.findAll(spec,pageable);
		List<FileDTO> dtoList = new ArrayList<FileDTO>();
		for(File entity:entityList) {
			FileDTO dto=new FileDTO();
			FileDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return new PageImpl<FileDTO>(dtoList,pageable,entityList.getTotalElements());
	}
}