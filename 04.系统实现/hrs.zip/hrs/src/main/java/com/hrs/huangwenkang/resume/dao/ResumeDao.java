package com.hrs.huangwenkang.resume.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.huangwenkang.resume.domain.Resume;

@Repository
public interface ResumeDao extends JpaSpecificationExecutor<Resume>,PagingAndSortingRepository<Resume,Long>{
	//修改简历状态
	@Modifying
	@Query(value="update t_resume set resumeStatus=?1 where id=?2",nativeQuery=true)
	public void updateResumeStatus(String resumeStatus,Long id);
}