package com.hrs.zhanshiyang.record.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;

public class RecordDTO {
	private Long id;
	private String employeeId;//员工工号ID
	private String recordContent;//操作内容
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date recordTime;//操作时间
	
	public Long getId() {
		return id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public String getRecordContent() {
		return recordContent;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getRecordTime() {
		return recordTime;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setRecordContent(String recordContent) {
		this.recordContent = recordContent;
	}
	public void setRecordTime(Date recordTime) {
		this.recordTime = recordTime;
	}
	
	//前端到后台（接收表单数据）:save 和 update	如何维护关联关系？
	public  static void dto2Entity(RecordDTO dto ,Record entity) {
		BeanUtils.copyProperties(dto, entity);	
	}
	//后台到前端（返回JSON数据）：find	显示什么数据？
	public  static void entity2Dto(Record entity ,RecordDTO dto) {
		BeanUtils.copyProperties(entity , dto);
	}
	
}
