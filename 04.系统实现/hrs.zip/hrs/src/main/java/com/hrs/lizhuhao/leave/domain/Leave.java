package com.hrs.lizhuhao.leave.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_leave")
public class Leave extends BaseDomain<Long>{
	private String employeeId;			//员工工号
	private String employeeName;		//员工姓名
	private Date leaveStartTime;		//开始时间
	private Date leaveEndTime;			//结束时间
	private int days;					//请假天数
	private String leaveReasion;		//请假原因
	private String leaveType;			//请假类型（病假，出差）
	private String leaveProcessStatus="待审核";//审核状态（待审核，通过，未通过）
	
	//getters
	@Column(nullable=false)
	public String getEmployeeId() {
		return employeeId;
	}
	@Column(nullable=false)
	public String getEmployeeName() {
		return employeeName;
	}
	@Column(nullable=false)
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getLeaveStartTime() {
		return leaveStartTime;
	}
	@Column(nullable=false)
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getLeaveEndTime() {
		return leaveEndTime;
	}
	@Column(nullable=false)
	public int getDays() {
		return days;
	}
	@Column(nullable=false)
	public String getLeaveReasion() {
		return leaveReasion;
	}
	@Column(nullable=false)
	public String getLeaveType() {
		return leaveType;
	}
	@Column(nullable=false)
	public String getLeaveProcessStatus() {
		return leaveProcessStatus;
	}
	//setters
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setLeaveStartTime(Date leaveStartTime) {
		this.leaveStartTime = leaveStartTime;
	}
	public void setLeaveEndTime(Date leaveEndTime) {
		this.leaveEndTime = leaveEndTime;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public void setLeaveReasion(String leaveReasion) {
		this.leaveReasion = leaveReasion;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public void setLeaveProcessStatus(String leavePreccessStatus) {
		this.leaveProcessStatus = leavePreccessStatus;
	}
}