package com.hrs.huangwenkang.resume.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

public class ResumeQueryDTO {
	private String resumeJobWanted;			//应聘职位
	private String resumeGraduate;			//毕业院校
	private String resumeMajor;				//所修专业
	private String resumeEduBackground;		//学历背景
	private String resumeStatus;			//简历状态
	public String getResumeJobWanted() {
		return resumeJobWanted;
	}
	public void setResumeJobWanted(String resumeJobWanted) {
		this.resumeJobWanted = resumeJobWanted;
	}
	public String getResumeGraduate() {
		return resumeGraduate;
	}
	public void setResumeGraduate(String resumeGraduate) {
		this.resumeGraduate = resumeGraduate;
	}
	public String getResumeMajor() {
		return resumeMajor;
	}
	public void setResumeMajor(String resumeMajor) {
		this.resumeMajor = resumeMajor;
	}
	public String getResumeEduBackground() {
		return resumeEduBackground;
	}
	public void setResumeEduBackground(String resumeEduBackground) {
		this.resumeEduBackground = resumeEduBackground;
	}
	public String getResumeStatus() {
		return resumeStatus;
	}
	public void setResumeStatus(String resumeStatus) {
		this.resumeStatus = resumeStatus;
	}
	//查询待查阅的简历
	@SuppressWarnings({ "serial"})
	public static Specification<Resume> getWhereClause(final ResumeQueryDTO resumeQueryDTO) {
		return new Specification<Resume>() {
			@Override
			public Predicate toPredicate(Root<Resume> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();
				if (StringUtils.isNotBlank(resumeQueryDTO.getResumeJobWanted())) {
					predicate.add(criteriaBuilder.like(root.get("resumeJobWanted").as(String.class),
							"%" + resumeQueryDTO.getResumeJobWanted()+"%"));
				}
				if (StringUtils.isNotBlank(resumeQueryDTO.getResumeGraduate())) {
					predicate.add(criteriaBuilder.like(root.get("resumeGraduate").as(String.class),
							"%"+resumeQueryDTO.getResumeGraduate()+"%"));
				}
				if (StringUtils.isNotBlank(resumeQueryDTO.getResumeMajor())) {
					predicate.add(criteriaBuilder.like(root.get("resumeMajor").as(String.class),
							"%"+resumeQueryDTO.getResumeMajor()+"%"));
				}
				if (StringUtils.isNotBlank(resumeQueryDTO.getResumeEduBackground())) {
					predicate.add(criteriaBuilder.like(root.get("resumeEduBackground").as(String.class),
							"%"+resumeQueryDTO.getResumeEduBackground()+"%"));
				}
				if (StringUtils.isNotBlank(resumeQueryDTO.getResumeStatus())) {
					predicate.add(criteriaBuilder.equal(root.get("resumeStatus").as(String.class),
							resumeQueryDTO.getResumeStatus()));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}