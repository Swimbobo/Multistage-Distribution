package com.hrs.huangwenkang.entry.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.huangwenkang.entry.dao.EntryDao;
import com.hrs.huangwenkang.entry.domain.Entry;
import com.hrs.huangwenkang.entry.domain.EntryDTO;

@Service
@Transactional
public class EntryService implements IEntryService{
	@Autowired
	private EntryDao entryDao;
	
	//增加对象
	public Entry save(EntryDTO dto) {
		Entry entity=new Entry();
		EntryDTO.dto2Entity(dto, entity);
		return entryDao.save(entity);
	}
	//通过id删除对象
	public void deleteById(Long id) {
		entryDao.deleteById(id);
	}
	//批量删除
	public void deleteAll(Long[] ids) {
		List<Long> idLists = new ArrayList<Long>(Arrays.asList(ids));
		List<Entry> entrys = (List<Entry>)entryDao.findAllById(idLists);
		if(entrys!=null) {
			entryDao.deleteAll(entrys);
		}
	}
	//通过id查找对象
	public EntryDTO findById(Long id) {
		Entry entity=entryDao.findById(id).get();
		EntryDTO dto=new EntryDTO();
		EntryDTO.entity2Dto(entity, dto);
		return dto;
	}
	//通过id判断是否存在对象
	public boolean existsById(Long id) {
		return entryDao.existsById(id);
	}
	//统计表中数据总数
	public long count() {
		return entryDao.count();
	}
	//查看全部
	public Page<EntryDTO> findAll(Specification<Entry> spec, Pageable pageable) {
		Page<Entry> entityList=entryDao.findAll(spec,pageable);
		List<EntryDTO> dtoList = new ArrayList<EntryDTO>();
		for(Entry entity:entityList) {
			EntryDTO dto=new EntryDTO();
			EntryDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return new PageImpl<EntryDTO>(dtoList,pageable,entityList.getTotalElements());
	}
	//修改入职表状态
	public void updateEntryRes(Long id) {
		entryDao.updateEntryRes(id);
	}
}