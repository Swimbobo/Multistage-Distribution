package com.hrs.lizhuhao.branch.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

public class BranchQueryDTO {
	private String branchName;		//部门名称
	private String employeeId;		//部门负责人工号
	
	//get
	public String getBranchName() {
		return branchName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	//set
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	@SuppressWarnings({ "serial"})
	public static Specification<Branch> getWhereClause(final BranchQueryDTO branchQueryDTO) {
		return new Specification<Branch>() {
			@Override
			public Predicate toPredicate(Root<Branch> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();
				if (StringUtils.isNotBlank(branchQueryDTO.getBranchName())) {
					predicate.add(criteriaBuilder.like(root.get("branchName").as(String.class),
							"%" + branchQueryDTO.getBranchName() + "%"));
				}
				if (StringUtils.isNotBlank(branchQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + branchQueryDTO.getEmployeeId() + "%"));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}