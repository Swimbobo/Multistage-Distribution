package com.hrs.lizhuhao.leave.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import com.hrs.lizhuhao.leave.domain.Leave;
import com.hrs.lizhuhao.leave.domain.LeaveDTO;

public interface ILeaveService {
	public void save(LeaveDTO dto);						//增加对象
	public void deleteById(Long id);					//通过id删除对象
	public void deleteAll(Long[] ids);					//批量删除
	public LeaveDTO findById(Long id);					//通过id查找对象
	public boolean existsById(Long id);					//通过id判断是否存在对象
	public long count();								//统计表中数据总数
	public Page<LeaveDTO> findAll(Specification<Leave> spec,Pageable pageable);
}