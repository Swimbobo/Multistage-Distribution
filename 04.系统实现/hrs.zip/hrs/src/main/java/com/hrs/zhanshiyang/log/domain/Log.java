package com.hrs.zhanshiyang.log.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_log")
public class Log extends BaseDomain<Long> {
	private String employeeId;//员工工号ID
	private String employeeName;//员工姓名
	private String logPassword;//员工登录密码（初始密码为123456）
	private String logPermission;//员工的权限设置（0-9，权限逐级递减，默认权限最小）
	
	public Log() {
		this.logPassword="123456";
		this.logPermission="9";
	}
	
//	getters
	@Column(nullable=false)
	public String getEmployeeId() {
		return employeeId;
	}
	@Column(nullable=false)
	public String getEmployeeName() {
		return employeeName;
	}
	@Column(nullable=false,columnDefinition="varchar(50) default '123456'")
	public String getLogPassword() {
		return logPassword;
	}
	@Column(nullable=false,length=1,columnDefinition="varchar(1) default '9'")
	public String getLogPermission() {
		return logPermission;
	}
	
//	setters
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setLogPassword(String logPassword) {
		this.logPassword = logPassword;
	}
	public void setLogPermission(String logPermission) {
		this.logPermission = logPermission;
	}
}