package com.hrs.chenliangbo.staff.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.SessionUtil;

public class StaffQueryDTO {
	private Long id;
	private String staffName;	//姓名
	private String employeeId;	//工号
	@DateTimeFormat(pattern="yyyy/MM/dd") 
	private Date birthday;      //出生日期
	private String staffSex;	//性别
	private String staffIdCard;	//身份证号码
	private String staffPhone;	//联系方式
	private String staffEmail;	//邮箱
	private String staffAddress;//家庭住址
	private String staffNation;	//民族
	private String staffNativePlace;//籍贯
	private String staffHuKouAddress;//户口所在地
	private String staffHuKouType;//户口类型
	private String staffEmergencyContactName;//紧急联系人
	private String staffEmergencyContactPhone;//紧急联系人电话
	
	public Long getId() {
		return id;
	}
	public String getStaffName() {
		return staffName;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getBirthday() {
		return birthday;
	}
	public String getStaffSex() {
		return staffSex;
	}
	public String getStaffIdCard() {
		return staffIdCard;
	}
	public String getStaffPhone() {
		return staffPhone;
	}
	public String getStaffEmail() {
		return staffEmail;
	}
	public String getStaffAddress() {
		return staffAddress;
	}
	public String getStaffNation() {
		return staffNation;
	}
	public String getStaffNativePlace() {
		return staffNativePlace;
	}
	public String getStaffHuKouAddress() {
		return staffHuKouAddress;
	}
	public String getStaffHuKouType() {
		return staffHuKouType;
	}
	public String getStaffEmergencyContactName() {
		return staffEmergencyContactName;
	}
	public String getStaffEmergencyContactPhone() {
		return staffEmergencyContactPhone;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public void setStaffSex(String staffSex) {
		this.staffSex = staffSex;
	}
	public void setStaffIdCard(String staffIdCard) {
		this.staffIdCard = staffIdCard;
	}
	public void setStaffPhone(String staffPhone) {
		this.staffPhone = staffPhone;
	}
	public void setStaffEmail(String staffEmail) {
		this.staffEmail = staffEmail;
	}
	public void setStaffAddress(String staffAddress) {
		this.staffAddress = staffAddress;
	}
	public void setStaffNation(String staffNation) {
		this.staffNation = staffNation;
	}
	public void setStaffNativePlace(String staffNativePlace) {
		this.staffNativePlace = staffNativePlace;
	}
	public void setStaffHuKouAddress(String staffHuKouAddress) {
		this.staffHuKouAddress = staffHuKouAddress;
	}
	public void setStaffHuKouType(String staffHuKouType) {
		this.staffHuKouType = staffHuKouType;
	}
	public void setStaffEmergencyContactName(String staffEmergencyContactName) {
		this.staffEmergencyContactName = staffEmergencyContactName;
	}
	public void setStaffEmergencyContactPhone(String staffEmergencyContactPhone) {
		this.staffEmergencyContactPhone = staffEmergencyContactPhone;
	}

	@SuppressWarnings({ "serial"})
	public static Specification<Staff> getWhereClause(final StaffQueryDTO staffQueryDTO) {
		return new Specification<Staff>() {
			@Override
			public Predicate toPredicate(Root<Staff> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();
				if (StringUtils.isNotBlank(staffQueryDTO.getStaffName())) {
					predicate.add(criteriaBuilder.like(root.get("staffName").as(String.class),
							"%" + staffQueryDTO.getStaffName() + "%"));
				}
				if (StringUtils.isNotBlank(staffQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + staffQueryDTO.getEmployeeId() + "%"));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
	@SuppressWarnings({ "serial"})
	public static Specification<Staff> getWhereByEmployeeId(final StaffQueryDTO staffQueryDTO) {
		return new Specification<Staff>() {
			@Override
			public Predicate toPredicate(Root<Staff> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();//条件数组
				HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
				HttpSession  session=request.getSession();
				String emp=SessionUtil.getEmployeeId(session);
				if (StringUtils.isNotBlank(staffQueryDTO.getStaffName())) {
					predicate.add(criteriaBuilder.like(root.get("staffName").as(String.class),
							"%" + staffQueryDTO.getStaffName() + "%"));
				}
				predicate.add(criteriaBuilder.equal(root.get("employeeId").as(String.class),emp));
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}