package com.hrs.youzhenjie.employee.web;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.common.beans.BeanUtils;
import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.huangwenkang.entry.service.IEntryService;
import com.hrs.youzhenjie.employee.domain.Employee;
import com.hrs.youzhenjie.employee.domain.EmployeeQueryDTO;
import com.hrs.youzhenjie.employee.service.IEmployeeService;
import com.hrs.zhanshiyang.log.domain.Log;
import com.hrs.zhanshiyang.log.domain.LogDTO;
import com.hrs.zhanshiyang.log.service.ILogService;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@RestController
@RequestMapping(value = "employee")
public class EmployeeController {

	@Autowired
	private IEmployeeService employeeService;

	@Autowired
	private ILogService logService;
	
	@Autowired
	private IEntryService entryService;
	
	@Autowired
	private IRecordService recordService;
	// 花名册的主页 分页+显示所有信息
	/*
	 * 查询所有
	 */
	@GetMapping
	public Page<Employee> findAll(EmployeeQueryDTO dto, ExtjsPageRequest pageRequest) {
		return employeeService.searchAllByPage(dto.getWhereClause(dto), pageRequest.getPageable());

	}

	/*
	 * 查询一个
	 */
	@GetMapping(value = "{id}")
	public Employee findOne(@PathVariable Long id) {
		System.out.println(id);
		return employeeService.searchById(id).get();
	}

	/*
	 * 添加数据
	 */
	@PostMapping("/save")
	public ExtAjaxResponse save(@RequestParam(value = "id") String id,
			@RequestParam(value = "resumeId") String resumeId,
			@RequestParam(value = "entryName") String entryName,
			@RequestParam(value = "entrySex") String entrySex,
			@RequestParam(value = "entrybranch") String entrybranch,
			@RequestParam(value = "entryposition") String entryposition,
			@RequestParam(value = "entryTel") String entryTel,
			@RequestParam(value = "entryConfirmedEntryDate") String entryConfirmedEntryDate) throws ParseException{
		
		//String类型转换为Long
		Long i=Long.valueOf(id);

		
		int resume=Integer.valueOf(resumeId);		
		Employee domain=new Employee();
		Date date=new Date(entryConfirmedEntryDate);
		//String类型转换为Date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Date dateSql = sdf.parse(entryConfirmedEntryDate);
		
		domain.setEmployeeName(entryName);//姓名
		domain.setEmployeeSex(entrySex);//性别
		domain.setEmployeeDepartment(entrybranch);//部门
		domain.setEmployeePosition(entryposition);//职位
		domain.setEmployeeTel(entryTel);//电话
		domain.setEmployeeState("1");//状态
		domain.setEmployeeEntryTime(dateSql);//入职时间
		
		//Log表
		LogDTO log=new LogDTO();
		String partId;
		if(resume<10) {
			//工号自定义
			partId=new SimpleDateFormat("yyMMdd").format(date)+"0"+resumeId;
			domain.setEmployeeId(partId);
			System.out.println("Loging start");
			log.setEmployeeId(partId);
			System.out.println("Loging end");
		}else {
			partId=new SimpleDateFormat("yyMMdd").format(date)+resumeId;
			domain.setEmployeeId(partId);
			log.setEmployeeId(partId);
			log.setEmployeeName(entryName);
			log.setLogPermission("9");
		}
		try {
			//写入employee表
			employeeService.saveOrUpdate(domain);
			
			//更新状态
			entryService.updateEntryRes(i);

			//写入log登录表
			logService.save(log);
			
			//日志
			writeLog("修改待入职表状态并添加");
			
			return new ExtAjaxResponse(true,"保存成功！");
		}catch(Exception e) {
			return new ExtAjaxResponse(true,"保存失败！");
			}
		}

	/*
	 * 更新update
	 */
	@PutMapping(value = "{id}")
	public ExtAjaxResponse update(@PathVariable("id") Long id, @RequestBody Employee employeedto) {
		System.out.println("update-------------------------" + id);
		try {
			Employee emp = employeeService.searchById(id).get();
			if (emp != null) {
				BeanUtils.copyProperties(employeedto, emp);// 使用自定义的BeanUtils
				employeeService.saveOrUpdate(emp);
				
				//日志
				writeLog("修改");
			}
			return new ExtAjaxResponse(true, "更新成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(false, "更新失败！");
		}
	}

	/*
	 * 更新状态
	 */
	/*
	 * 删除 设置state为0
	 */
	// 删除
	@DeleteMapping(value = "{id}")
	public ExtAjaxResponse delete(@PathVariable("id") Long id) {
		System.out.println("单个删除-- -------------------------------------------id:" + id);
		try {
			if (id != null) {
				employeeService.deleteById(id);
				//日志
				writeLog("删除");
			}
			return new ExtAjaxResponse(true, "删除成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(false, "删除失败！");
		}
	}

	@PostMapping("/deletes")
	public ExtAjaxResponse deleteRows(@RequestParam(name = "ids") Long[] ids) {
		System.out.println("批量删除-----------------");
		for (int i = 0; i < ids.length; i++) {
			System.out.println(ids[i]);
			writeLog("批量删除：删除");
		}
		
		try {
			if (ids != null) {
				employeeService.deleteAll(ids);
			}
			return new ExtAjaxResponse(true, "批量删除成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(false, "批量删除失败！");
		}
	}
	
	@RequestMapping(value = "/findByEmployeeId")
    public @ResponseBody ExtAjaxResponse findByEmployeeId(@RequestParam("employeeId") String employeeId) {
        System.out.println(employeeId);
		Employee emp=employeeService.findByEmployeeId(employeeId);
        if(emp!=null) {
		    Map<String,String> map=new HashMap<String, String>();
		    map.put("employeeName", emp.getEmployeeName());
		    System.out.println("123"+emp.getEmployeeName());

            map.put("msg", "获取成功!");
            return new ExtAjaxResponse(true,map);
        } else {
        	return new ExtAjaxResponse(false,"获取失败");
        }
    }
	
	//日志方法
	public void writeLog(String operation){
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession  session=request.getSession();
		String employeeId=SessionUtil.getEmployeeId(session);
		
		RecordDTO recordDTO = new RecordDTO();
		recordDTO.setEmployeeId(employeeId);
		recordDTO.setRecordContent(operation+" 员工信息成功");
		recordDTO.setRecordTime(new Date());
		recordService.save(recordDTO);

	}
}
