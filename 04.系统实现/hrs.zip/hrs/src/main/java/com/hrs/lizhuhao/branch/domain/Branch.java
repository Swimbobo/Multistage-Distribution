package com.hrs.lizhuhao.branch.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_branch")
public class Branch extends BaseDomain<Long> {
	private String branchName;		//部门名称
	private String employeeId;		//部门负责人工号
	
	//getters
	@Column(nullable=false)
	public String getBranchName() {
		return branchName;
	}
	@Column(nullable=false)
	public String getEmployeeId() {
		return employeeId;
	}
	//setters
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
}