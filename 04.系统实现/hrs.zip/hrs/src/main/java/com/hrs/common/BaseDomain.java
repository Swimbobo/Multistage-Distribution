package com.hrs.common;

import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class BaseDomain <PK extends Serializable>{
	private PK id;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	public PK getId() {
		return id;
	}
	public void setId(PK id) {
		this.id = id;
	}
}