package com.hrs.zhanshiyang.bonus.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class BonusQueryDTO {
	private String employeeId;//员工工号ID
	@DateTimeFormat(pattern="yyyy/MM/dd")
	private Date bonusTimeStart;//搜索时间的左边界
	@DateTimeFormat(pattern="yyyy/MM/dd")
	private Date bonusTimeEnd;//搜索时间的右边界
	private String bonusStyle;//奖金简述
	private BigDecimal bonusSumFrom;//奖金金额从
	private BigDecimal bonusSumTo;//奖金金额到
	private String bonusAddName;//录入管理员名字
	
	public String getEmployeeId() {
		return employeeId;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getBonusTimeStart() {
		return bonusTimeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getBonusTimeEnd() {
		return bonusTimeEnd;
	}
	public String getBonusStyle() {
		return bonusStyle;
	}
	public BigDecimal getBonusSumFrom() {
		return bonusSumFrom;
	}
	public BigDecimal getBonusSumTo() {
		return bonusSumTo;
	}
	public String getBonusAddName() {
		return bonusAddName;
	}
	
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	public void setBonusStyle(String bonusStyle) {
		this.bonusStyle = bonusStyle;
	}
	public void setBonusSumFrom(BigDecimal bonusSumFrom) {
		this.bonusSumFrom = bonusSumFrom;
	}
	public void setBonusSumTo(BigDecimal bonusSumTo) {
		this.bonusSumTo = bonusSumTo;
	}
	public void setBonusAddName(String bonusAddName) {
		this.bonusAddName = bonusAddName;
	}	
	public void setBonusTimeStart(Date bonusTimeStart) {
		this.bonusTimeStart = bonusTimeStart;
	}
	public void setBonusTimeEnd(Date bonusTimeEnd) {
		this.bonusTimeEnd = bonusTimeEnd;
	}
	
	@SuppressWarnings({ "serial"})
	public static Specification<Bonus> getWhereClause(final BonusQueryDTO bonusQueryDTO) {
		return new Specification<Bonus>() {
			@Override
			public Predicate toPredicate(Root<Bonus> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
			
				List<Predicate> predicate = new ArrayList<>();
				
				if (StringUtils.isNotBlank(bonusQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + bonusQueryDTO.getEmployeeId() + "%"));
				}
				if (null!=bonusQueryDTO.getBonusTimeStart()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("bonusYM").as(Date.class),
							bonusQueryDTO.getBonusTimeStart()));
				}
				if (null!=bonusQueryDTO.getBonusTimeEnd()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("bonusYM").as(Date.class),
							bonusQueryDTO.getBonusTimeEnd()));
				}
				if (StringUtils.isNotBlank(bonusQueryDTO.getBonusStyle())) {
					predicate.add(criteriaBuilder.like(root.get("bonusStyle").as(String.class),
							"%" + bonusQueryDTO.getBonusStyle() + "%"));
				}
				if(null!=bonusQueryDTO.getBonusSumFrom()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("bonusSum").as(BigDecimal.class), 
							bonusQueryDTO.getBonusSumFrom()));
				}
				if(null!=bonusQueryDTO.getBonusSumTo()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("bonusSum").as(BigDecimal.class), 
							bonusQueryDTO.getBonusSumTo()));
				}
				if(StringUtils.isNotBlank(bonusQueryDTO.getBonusAddName())) {
					predicate.add(criteriaBuilder.like(root.get("bonusAddName").as(String.class),
							"%" + bonusQueryDTO.getBonusAddName() + "%"));
				}
				
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}
