package com.hrs.lizhuhao.attendance.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.lizhuhao.attendance.dao.AttendanceDao;
import com.hrs.lizhuhao.attendance.domain.Attendance;
import com.hrs.lizhuhao.attendance.domain.AttendanceDTO;

@Service
@Transactional
public class AttendanceService implements IAttendanceService {
	@Autowired
	private AttendanceDao attendanceDao;
	
	//增加对象
	public void save(AttendanceDTO dto) {
		Attendance entity=new Attendance();
		AttendanceDTO.dto2Entity(dto, entity);
        attendanceDao.save(entity);
	}
	//通过ID查找对象
	@Transactional(readOnly=true)
	public AttendanceDTO findById(Long id) {
		Attendance entity=attendanceDao.findById(id).get();
		AttendanceDTO dto=new AttendanceDTO();
		AttendanceDTO.entity2Dto(entity, dto);
		return dto;
	}
	//通过id判断是否存在对象
	public boolean existsById(Long id) {
		return attendanceDao.existsById(id);
	}
	//统计表中数据总数
	public long count() {
		return attendanceDao.count();
	}
	//通过id删除对象
	public void deleteById(Long id) {
		attendanceDao.deleteById(id);
	}
     //批量删除
	public void deleteAll(Long[] ids) {
		List<Long> idLists = new ArrayList<Long>(Arrays.asList(ids));
		List<Attendance> attendances = (List<Attendance>) attendanceDao.findAllById(idLists);
		if(attendances!=null) {
			attendanceDao.deleteAll(attendances);
		}
	}
	//查看全部
	public Page<AttendanceDTO> findAll(Specification<Attendance> spec, Pageable pageable) {
		Page<Attendance> entityList=attendanceDao.findAll(spec,pageable);
		List<AttendanceDTO> dtoList = new ArrayList<AttendanceDTO>();
		for(Attendance entity:entityList) {
			AttendanceDTO dto=new AttendanceDTO();
			AttendanceDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return new PageImpl<AttendanceDTO>(dtoList,pageable,entityList.getTotalElements());
	}
	
	public List<AttendanceDTO> findByIdDate(String employeeId, String attendanceDate){
		List<Attendance> entityList=attendanceDao.findByIdDate(employeeId, attendanceDate);
		List<AttendanceDTO> dtoList = new ArrayList<AttendanceDTO>();
		for (Attendance entity : entityList) {
			AttendanceDTO dto=new AttendanceDTO();
			AttendanceDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return dtoList;
	}
}