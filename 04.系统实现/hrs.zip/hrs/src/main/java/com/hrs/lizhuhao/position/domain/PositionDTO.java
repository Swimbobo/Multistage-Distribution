package com.hrs.lizhuhao.position.domain;

import com.hrs.common.beans.BeanUtils;

public class PositionDTO {
	private Long id;					//id
	private String positionName;		//职位名称
    private String branchName;			//所属部门名称
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPositionName() {
		return positionName;
	}
	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	//前端到后台（接收表单数据）
	public static void dto2Entity(PositionDTO dto ,Position entity) {
		BeanUtils.copyProperties(dto, entity);
	}
	//后台到前端（返回JSON数据）
	public  static void entity2Dto(Position entity ,PositionDTO dto) {
		BeanUtils.copyProperties(entity,dto);
	}
}