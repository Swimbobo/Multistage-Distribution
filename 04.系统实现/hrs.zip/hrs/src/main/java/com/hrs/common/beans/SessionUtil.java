package com.hrs.common.beans;

import javax.servlet.http.HttpSession;
import com.hrs.zhanshiyang.log.domain.Log;

public class SessionUtil {
	public static String USER="log";
	public static String EMPLOYEEID="employeeId";
	public static String EMPLOYEENAME="employeeName";
	/*设置用户到session*/
	public static void setUser(HttpSession session,Log log){
		session.setAttribute(USER,log);
		setEmployeeId(session,log.getEmployeeId());
		setEmployeeName(session,log.getEmployeeName());
    }
	/*从session中取登录信息*/
	public static Log getUser(HttpSession session){
		Object log=session.getAttribute(USER);
		return log==null?null:(Log) log;
		}
	/*设置employeeId到session*/
	public static void setEmployeeId(HttpSession session,String employeeId){
		session.setAttribute(EMPLOYEEID,employeeId);
	}
	/*获取employeeId*/
	public static String getEmployeeId(HttpSession session){
        Object employeeId=session.getAttribute(EMPLOYEEID);
        return employeeId==null?null:(String) employeeId;
    }
	/*设置employeeName到session*/
	public static void setEmployeeName(HttpSession session,String employeeName){
		session.setAttribute(EMPLOYEENAME,employeeName);
	}
	/*获取employeeName*/
	public static String getEmployeeName(HttpSession session){
        Object employeeName=session.getAttribute(EMPLOYEENAME);
        return employeeName==null?null:(String) employeeName;
    }
	/*移除session*/
	public static void removeAttribute(HttpSession session){
		session.removeAttribute(USER);
		session.removeAttribute(EMPLOYEEID);
		session.removeAttribute(EMPLOYEENAME);
    }
}