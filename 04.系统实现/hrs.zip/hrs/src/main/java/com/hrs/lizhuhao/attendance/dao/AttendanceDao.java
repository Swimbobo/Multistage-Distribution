package com.hrs.lizhuhao.attendance.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.lizhuhao.attendance.domain.Attendance;

@Repository
public interface AttendanceDao extends PagingAndSortingRepository<Attendance,Long>,JpaSpecificationExecutor<Attendance>{
	@Query(value="select * from t_attendance where employeeId=?1 and attendanceDate=?2",nativeQuery=true)
	public List<Attendance> findByIdDate(String employeeId,String attendanceDate);
}