package com.hrs.zhanshiyang.welfare.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.zhanshiyang.welfare.domain.Welfare;

@Repository
public interface WelfareDao extends 
		PagingAndSortingRepository<Welfare,Long>,JpaSpecificationExecutor<Welfare>
{

}
