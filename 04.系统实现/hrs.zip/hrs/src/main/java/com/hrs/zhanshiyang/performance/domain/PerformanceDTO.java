package com.hrs.zhanshiyang.performance.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;
import com.hrs.zhanshiyang.template.domain.Template;

public class PerformanceDTO {
	private Long id;
	private String employeeId;//员工工号ID
	private Long performanceFraction;//员工的绩效分数
	private String performanceContent;//经理对属下员工的评估内容描述
	private Boolean performanceStatus;//评估状态（默认值为false，评估完成为true）
	private String performanceAssessName;//评估人的名字（自动获取）
	private String performanceStaffName;//被评估人的名字（模板发布时自动获取）
	
	private Long templateId;
	private String templateHead;//评估模板标题
	private Boolean templateStatus;//评估模板的发布状态（默认值为false，评估完成为true）
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date templateTimeStart;//员工绩效评估开始时间
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date templateTimeEnd;//员工绩效评估结束时间 
	
	public Long getId() {
		return id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public Long getPerformanceFraction() {
		return performanceFraction;
	}
	public String getPerformanceContent() {
		return performanceContent;
	}
	public Boolean getPerformanceStatus() {
		return performanceStatus;
	}
	public String getPerformanceAssessName() {
		return performanceAssessName;
	}
	public String getPerformanceStaffName() {
		return performanceStaffName;
	}
	public Long getTemplateId() {
		return templateId;
	}
	public String getTemplateHead() {
		return templateHead;
	}
	public Boolean getTemplateStatus() {
		return templateStatus;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getTemplateTimeStart() {
		return templateTimeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getTemplateTimeEnd() {
		return templateTimeEnd;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setPerformanceFraction(Long performanceFraction) {
		this.performanceFraction = performanceFraction;
	}
	public void setPerformanceContent(String performanceContent) {
		this.performanceContent = performanceContent;
	}
	public void setPerformanceStatus(Boolean performanceStatus) {
		this.performanceStatus = performanceStatus;
	}
	public void setPerformanceAssessName(String performanceAssessName) {
		this.performanceAssessName = performanceAssessName;
	}
	public void setPerformanceStaffName(String performanceStaffName) {
		this.performanceStaffName = performanceStaffName;
	}
	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}
	public void setTemplateHead(String templateHead) {
		this.templateHead = templateHead;
	}
	public void setTemplateStatus(Boolean templateStatus) {
		this.templateStatus = templateStatus;
	}
	public void setTemplateTimeStart(Date templateTimeStart) {
		this.templateTimeStart = templateTimeStart;
	}
	public void setTemplateTimeEnd(Date templateTimeEnd) {
		this.templateTimeEnd = templateTimeEnd;
	}
	
	@Override
	public String toString() {
		return "PerformanceDTO [id=" + id + ", employeeId=" + employeeId + ", performanceFraction="
				+ performanceFraction + ", performanceContent=" + performanceContent + ", performanceStatus="
				+ performanceStatus + ", performanceAssessName=" + performanceAssessName + ", performanceStaffName="
				+ performanceStaffName + ", templateId=" + templateId + ", templateHead=" + templateHead
				+ ", templateStatus=" + templateStatus + ", templateTimeStart=" + templateTimeStart
				+ ", templateTimeEnd=" + templateTimeEnd + "]";
	}
	
	//前端到后台（接收表单数据）:save 和 update	如何维护关联关系？
	public  static void dto2Entity(PerformanceDTO dto ,Performance entity) {
		BeanUtils.copyProperties(dto, entity);
		if(dto.getTemplateId()!=null) {
			Template template= new Template();
			template.setId(dto.getTemplateId());
			//建立单向关联关系
			entity.setTemplate(template);
		}
	}
	//后台到前端（返回JSON数据）：find	显示什么数据？
	public  static void entity2Dto(Performance entity ,PerformanceDTO dto) {
		BeanUtils.copyProperties(entity , dto);
		if(entity.getTemplate()!=null) {
			dto.setTemplateId(entity.getTemplate().getId());
			dto.setTemplateHead(entity.getTemplate().getTemplateHead());
			dto.setTemplateStatus(entity.getTemplate().getTemplateStatus());
			dto.setTemplateTimeStart(entity.getTemplate().getTemplateTimeStart());
			dto.setTemplateTimeEnd(entity.getTemplate().getTemplateTimeEnd());
		}
	}
	
}
