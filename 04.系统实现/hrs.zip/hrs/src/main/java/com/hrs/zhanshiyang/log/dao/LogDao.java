package com.hrs.zhanshiyang.log.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.zhanshiyang.log.domain.Log;

@Repository
public interface LogDao extends PagingAndSortingRepository<Log,Long>,JpaSpecificationExecutor<Log>{
	@Query("from Log where employeeId=?1 and logPassword=?2")
	public Log Login(String employeeId,String logPassword);
	public Log findByEmployeeId(String employeeId);
	
	@Modifying
	@Query("update Log set logPassword=?1 where employeeId=?2 and logPassword=?3")
	public void updatePassword(String logPassword,String employeeId,String oldPassword);
}