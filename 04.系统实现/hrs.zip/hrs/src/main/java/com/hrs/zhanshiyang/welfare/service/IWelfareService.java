package com.hrs.zhanshiyang.welfare.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.zhanshiyang.welfare.domain.Welfare;
import com.hrs.zhanshiyang.welfare.domain.WelfareDTO;

public interface IWelfareService {
//	CrudRepository接口：
	public void save(WelfareDTO dto);
	public WelfareDTO findById(Long id);
	public void deleteById(Long id);
	public void deleteAll(List<WelfareDTO> dtoLists);
//	PagingAndSortingRepository extends CrudRepository接口：
	public Page<WelfareDTO> findAll(Specification<Welfare> spec, Pageable pageable);

}
