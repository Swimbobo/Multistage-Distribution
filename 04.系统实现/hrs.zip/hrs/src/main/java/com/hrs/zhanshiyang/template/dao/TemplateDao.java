package com.hrs.zhanshiyang.template.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.zhanshiyang.template.domain.Template;

@Repository
public interface TemplateDao extends 
		PagingAndSortingRepository<Template,Long>,JpaSpecificationExecutor<Template>
{

}
