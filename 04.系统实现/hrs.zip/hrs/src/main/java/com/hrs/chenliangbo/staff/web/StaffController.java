package com.hrs.chenliangbo.staff.web;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.chenliangbo.staff.domain.Staff;
import com.hrs.chenliangbo.staff.domain.StaffDTO;
import com.hrs.chenliangbo.staff.domain.StaffQueryDTO;
import com.hrs.chenliangbo.staff.service.IStaffService;
import com.hrs.common.beans.BeanUtils;
import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@RestController
@RequestMapping("/staff")
public class StaffController {
	@Autowired
	private IStaffService staffService;
	
	@Autowired
	private IRecordService recordService;
	
	//分页查询所有记录
	@GetMapping
	public Page<StaffDTO> getPage(StaffQueryDTO staffQueryDTO,ExtjsPageRequest pageRequest){
		return staffService.findAll(StaffQueryDTO.getWhereClause(staffQueryDTO),pageRequest.getPageable());
	}
	
	@GetMapping("/getOne")
	public Page<StaffDTO> getPageByEmployeeId(StaffQueryDTO staffQueryDTO,ExtjsPageRequest pageRequest){
		return staffService.findAll(StaffQueryDTO.getWhereByEmployeeId(staffQueryDTO),pageRequest.getPageable());
	}
	
	//查询一个记录(根据id)
	@GetMapping(value="{id}")
	public StaffDTO getOneById(@PathVariable("id") Long id){
		return staffService.findById(id);
	}
	
	//删除一个记录
	@DeleteMapping(value="{id}")
	public ExtAjaxResponse delete(@PathVariable("id") Long id){
		try {
			if(id!=null) {
				staffService.deleteById(id);
				//日志
				writeLog("删除");
			}
			return new ExtAjaxResponse(true,"删除成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"删除失败！");
		}
	}
	
	
	//更新一个记录
	@PutMapping(value="{id}")
	public ExtAjaxResponse update(@PathVariable("id") Long myId,@RequestBody Staff dto){
		try {
			//查找一个记录
			StaffDTO entity = staffService.findById(myId);
			if(entity!=null) {
				BeanUtils.copyProperties(dto, entity);//使用自定义的BeanUtils
				staffService.save(entity);
				//日志
				writeLog("修改");
			}
			return new ExtAjaxResponse(true,"更新成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"更新失败！");
		}
	}
	
	//保存一个记录
	@PostMapping
	public ExtAjaxResponse save(@RequestBody StaffDTO staff){
		try {
			staffService.save(staff);
			//日志
			writeLog("添加");
			return new ExtAjaxResponse(true,"保存成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"保存失败！");
		}
	}
	
	//日志方法
	public void writeLog(String operation){
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession  session=request.getSession();
		String employeeId=SessionUtil.getEmployeeId(session);
		
		RecordDTO recordDTO = new RecordDTO();
		recordDTO.setEmployeeId(employeeId);
		recordDTO.setRecordContent(operation+" 档案信息成功");
		recordDTO.setRecordTime(new Date());
		recordService.save(recordDTO);

	}
}