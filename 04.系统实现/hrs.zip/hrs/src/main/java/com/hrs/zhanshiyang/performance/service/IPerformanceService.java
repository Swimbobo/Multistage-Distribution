package com.hrs.zhanshiyang.performance.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.zhanshiyang.performance.domain.Performance;
import com.hrs.zhanshiyang.performance.domain.PerformanceDTO;

public interface IPerformanceService 
{
//	CrudRepository接口：
	public void save(PerformanceDTO dto);
//	PagingAndSortingRepository extends CrudRepository接口：
	public Page<PerformanceDTO> findAll(Specification<Performance> spec, Pageable pageable);
	
}
