package com.hrs.lizhuhao.leave.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.common.beans.SessionUtil;

public class LeaveQueryDTO {
	private String employeeId;			//员工工号
	private String employeeName;		//员工姓名
	@DateTimeFormat(pattern="yyyy/MM/dd") 
	private Date leaveStartTime;		//开始时间
	@DateTimeFormat(pattern="yyyy/MM/dd") 
	private Date leaveEndTime;			//结束时间
	private String leaveReasion;		//请假原因
	private String leaveType;			//请假类型（病假，出差）
	private String leaveProcessStatus;	//审核状态（待审核，通过，未通过）
	
	//getters
	public String getEmployeeId() {
		return employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	
	public Date getLeaveStartTime() {
		return leaveStartTime;
	}
	
	public Date getLeaveEndTime() {
		return leaveEndTime;
	}
	public String getLeaveReasion() {
		return leaveReasion;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public String getLeaveProcessStatus() {
		return leaveProcessStatus;
	}
	//setters
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setLeaveStartTime(Date leaveStartTime) {
		this.leaveStartTime = leaveStartTime;
	}
	public void setLeaveEndTime(Date leaveEndTime) {
		this.leaveEndTime = leaveEndTime;
	}
	public void setLeaveReasion(String leaveReasion) {
		this.leaveReasion = leaveReasion;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public void setLeaveProcessStatus(String leaveProcessStatus) {
		this.leaveProcessStatus = leaveProcessStatus;
	}
	
	@SuppressWarnings({ "serial"})
	public static Specification<Leave> getWhereClause(final LeaveQueryDTO leaveQueryDTO) {
		return new Specification<Leave>() {
			@Override
			public Predicate toPredicate(Root<Leave> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();
				if (StringUtils.isNotBlank(leaveQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + leaveQueryDTO.getEmployeeId() + "%"));
				}
				if (StringUtils.isNotBlank(leaveQueryDTO.getEmployeeName())) {
					predicate.add(criteriaBuilder.like(root.get("employeeName").as(String.class),
							"%" + leaveQueryDTO.getEmployeeName() + "%"));
				}
				if (StringUtils.isNotBlank(leaveQueryDTO.getLeaveType())) {
					predicate.add(criteriaBuilder.like(root.get("leaveType").as(String.class),
							"%" + leaveQueryDTO.getLeaveType() + "%"));
				}
				if (StringUtils.isNotBlank(leaveQueryDTO.getLeaveProcessStatus())) {
					predicate.add(criteriaBuilder.equal(root.get("leaveProcessStatus").as(String.class),
							leaveQueryDTO.getLeaveProcessStatus()));
				}
				if (null!=leaveQueryDTO.getLeaveStartTime()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("leaveStartTime").as(Date.class),
							leaveQueryDTO.getLeaveStartTime()));
				}
				if (null!=leaveQueryDTO.getLeaveEndTime()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("leaveStartTime").as(Date.class),
							leaveQueryDTO.getLeaveEndTime()));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
	
	@SuppressWarnings({ "serial"})
	public static Specification<Leave> getWhereByEmployeeId(final LeaveQueryDTO leaveQueryDTO) {
		return new Specification<Leave>() {
			@Override
			public Predicate toPredicate(Root<Leave> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();
				HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
				HttpSession  session=request.getSession();
				String emp=SessionUtil.getEmployeeId(session);
				predicate.add(criteriaBuilder.equal(root.get("employeeId").as(String.class),emp));
				if (StringUtils.isNotBlank(leaveQueryDTO.getEmployeeName())) {
					predicate.add(criteriaBuilder.like(root.get("employeeName").as(String.class),
							"%" + leaveQueryDTO.getEmployeeName() + "%"));
				}
				if (StringUtils.isNotBlank(leaveQueryDTO.getLeaveType())) {
					predicate.add(criteriaBuilder.like(root.get("leaveType").as(String.class),
							"%" + leaveQueryDTO.getLeaveType() + "%"));
				}
				if (StringUtils.isNotBlank(leaveQueryDTO.getLeaveProcessStatus())) {
					predicate.add(criteriaBuilder.equal(root.get("leaveProcessStatus").as(String.class),
							leaveQueryDTO.getLeaveProcessStatus()));
				}
				if (null!=leaveQueryDTO.getLeaveStartTime()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("leaveStartTime").as(Date.class),
							leaveQueryDTO.getLeaveStartTime()));
				}
				if (null!=leaveQueryDTO.getLeaveEndTime()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("leaveStartTime").as(Date.class),
							leaveQueryDTO.getLeaveEndTime()));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}