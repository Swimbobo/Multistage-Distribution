package com.hrs.chenliangbo.file.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_file")
public class File extends BaseDomain<Long>{
	private String employeeId;	//工号
	private String fileContent;	//工作内容
	private String fileResults;	//业绩
	private String fileSchool;	//学校
	private String fileMajor;	//专业
	private String fileEduBackground;//学历背景
	
	//getters
	@Column(nullable=false)
	public String getEmployeeId() {
		return employeeId;
	}
	@Column(nullable=false)
	public String getFileContent() {
		return fileContent;
	}
	@Column(nullable=false)
	public String getFileResults() {
		return fileResults;
	}
	@Column(nullable=false)
	public String getFileSchool() {
		return fileSchool;
	}
	@Column(nullable=false)
	public String getFileMajor() {
		return fileMajor;
	}
	@Column(nullable=false)
	public String getFileEduBackground() {
		return fileEduBackground;
	}
	
	//setters
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}
	public void setFileResults(String fileResults) {
		this.fileResults = fileResults;
	}
	public void setFileSchool(String fileSchool) {
		this.fileSchool = fileSchool;
	}
	public void setFileMajor(String fileMajor) {
		this.fileMajor = fileMajor;
	}
	public void setFileEduBackground(String fileEduBackground) {
		this.fileEduBackground = fileEduBackground;
	}	
}