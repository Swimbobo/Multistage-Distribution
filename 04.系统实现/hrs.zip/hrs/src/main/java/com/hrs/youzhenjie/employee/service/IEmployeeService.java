package com.hrs.youzhenjie.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.youzhenjie.employee.domain.Employee;

public interface IEmployeeService {
	/*
	 * 查
	 */
	//通过ID查询
	public Optional<Employee> searchById(Long id);
	
	//查询所有(没有分页)
	public List<Employee> searchAll();
	
	//查询所有(分页）
	public Page<Employee> searchAllByPage(Specification<Employee> sepc,Pageable pageable);
	
	//通过名字查询
	public Employee findByEmployeeId(String name);
	
	//通过employeeName查询
	public Employee findByEmployeeName(String employeeName);
	
	/*
	 * 增&&改&& 删
	 * 软删除：
	 * 删除员工相当于update员工的在职状态为0
	 */
	public Employee saveOrUpdate(Employee employee);
	

	//预留删除接口：
	public void deleteById(Long id);
	
	public void deleteAll(Long[] ids);
	
	
	//统计
	public long count();
	
	//是否存在
	public boolean existsById(Long id);

}
