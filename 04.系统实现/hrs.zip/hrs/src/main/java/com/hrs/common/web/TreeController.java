package com.hrs.common.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hrs.common.beans.NavigationTree;
import com.hrs.zhanshiyang.log.service.ILogService;




@RestController
@RequestMapping("/tree")
public class TreeController {
	@Autowired
	private ILogService logService;
	@RequestMapping(value="/gettree")
	public NavigationTree getTree(@RequestParam(name="employeeId") String employeeId) {
		NavigationTree root = new NavigationTree(true,null,null,null,false,true,null);
		NavigationTree dashboard = new NavigationTree(false,"Dashboard","x-fa fa-desktop","admindashboard",true,true,null);
		/*NavigationTree login = new NavigationTree(false,"login","x-fa fa-check","login",true,true,null);*/
		//员工信息
		NavigationTree emp = new NavigationTree(false,"员工基本信息","x-fa fa-cubes",null,false,true,null);
		NavigationTree staffSearch=new NavigationTree(false,"查看个人信息", "x-fa fa-cube","staffSearchOne",true, true, null);
		NavigationTree fileSearch=new NavigationTree(false,"查看档案信息", "x-fa fa-cube","fileSearchOne", true, true, null);
		NavigationTree overtimeSearch=new NavigationTree(false,"查看加班信息", "x-fa fa-cube","overtimeSearch", true, true, null);
		NavigationTree leaveSearch=new NavigationTree(false,"查看请假信息", "x-fa fa-cube","leaveSearch", true, true, null);
		NavigationTree attendanceSearch=new NavigationTree(false,"查看考勤信息", "x-fa fa-cube","attendanceSearch", true, true, null);
		//档案信息
		NavigationTree file = new NavigationTree(false,"员工档案信息","x-fa fa-book","file",true,true,null);
		
		List<NavigationTree> empChildren = new ArrayList<>();
		empChildren.add(staffSearch);
		empChildren.add(fileSearch);
		empChildren.add(overtimeSearch);
		empChildren.add(leaveSearch);
		empChildren.add(attendanceSearch);
		emp.setChildren(empChildren);
		
		if(logService.findByEmployeeId(employeeId).getLogPermission().equals("1")) {
			List<NavigationTree> rootChildren = new ArrayList<>();
			rootChildren.add(dashboard);
			rootChildren.add(emp);
			rootChildren.add(file);
			root.setChildren(rootChildren);
		}
		else {
			List<NavigationTree> rootChildren = new ArrayList<>();
			rootChildren.add(dashboard);
			rootChildren.add(emp);
			root.setChildren(rootChildren);
		}
		return root;
	}
	
	@RequestMapping(value="/gettree1")
	public String getTree1(@RequestParam(name="employeeId") String employeeId) {
		if(logService.findByEmployeeId(employeeId).getLogPermission().equals("1")) {
			System.out.println("111");
			return "1";
		}
		else return"0";
	}

}
