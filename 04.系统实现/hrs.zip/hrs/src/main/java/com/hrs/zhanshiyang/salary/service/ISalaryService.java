package com.hrs.zhanshiyang.salary.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.zhanshiyang.salary.domain.Salary;
import com.hrs.zhanshiyang.salary.domain.SalaryDTO;

public interface ISalaryService {
	//	CrudRepository接口：
	public void save(SalaryDTO dto);
	public SalaryDTO findById(Long id);
	public List<SalaryDTO> findAllById(List<Long> ids);
	public void deleteById(Long id);
	public void deleteAll(List<SalaryDTO> dtoLists);
	//	PagingAndSortingRepository extends CrudRepository接口：
	public Page<SalaryDTO> findAll(Specification<Salary> spec, Pageable pageable);	
	//	自定义查询：
	public BigDecimal findBonus(String employeeId,String date);//查找奖金表
	public BigDecimal findWelfare(String employeeId,String date);//查找福利表
	public BigDecimal findContract(String employeeId);//查找合同表
	public int findAttendance(String employeeId,String date);//查找考勤表
	public String findOvertime(String employeeId,String date);//查找加班表
	public String findLeave(String employeeId,String date);//查找请假
	public String findBusiniss(String employeeId,String date);//查找出差
}