package com.hrs.huangwenkang.resume.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.huangwenkang.resume.dao.ResumeDao;
import com.hrs.huangwenkang.resume.domain.Resume;
import com.hrs.huangwenkang.resume.domain.ResumeDTO;

@Service
@Transactional
public class ResumeService implements IResumeService{
	@Autowired
	private ResumeDao resumeDao;
	
	//增加对象
	public Resume save(ResumeDTO dto) {
		Resume entity=new Resume();
		ResumeDTO.dto2Entity(dto,entity);
		return resumeDao.save(entity);
	}
	//通过id删除对象
	public void deleteById(Long id) {
		resumeDao.deleteById(id);
	}
	//批量删除
	public void deleteAll(Long[] ids) {
		List<Long> idLists = new ArrayList<Long>(Arrays.asList(ids));
		List<Resume> resumes = (List<Resume>) resumeDao.findAllById(idLists);
		if(resumes!=null) {
			resumeDao.deleteAll(resumes);
		}
	}
	//通过id查找对象
	@SuppressWarnings("static-access")
	public ResumeDTO findById(Long id) {
		Resume entity=resumeDao.findById(id).get();
		ResumeDTO dto=new ResumeDTO();
		dto.entity2Dto(entity, dto);
		return dto;
	}
	//通过id判断是否存在对象
	public boolean existsById(Long id) {
		return resumeDao.existsById(id);
	}
	//统计表中数据总数
	public long count() {
		return resumeDao.count();
	}
	//查看全部
	public Page<ResumeDTO> findAll(Specification<Resume> spec, Pageable pageable) {
		Page<Resume> entityList=resumeDao.findAll(spec,pageable);
		List<ResumeDTO> dtoList = new ArrayList<ResumeDTO>();
		for(Resume entity:entityList) {
			ResumeDTO dto=new ResumeDTO();
			ResumeDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return new PageImpl<ResumeDTO>(dtoList,pageable,entityList.getTotalElements());
	}
	//修改简历状态
	public void updateResumeStatus(String resumeStatus,Long id) {
		resumeDao.updateResumeStatus(resumeStatus,id);
	}
}