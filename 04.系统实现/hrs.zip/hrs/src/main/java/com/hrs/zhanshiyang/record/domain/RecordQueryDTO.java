package com.hrs.zhanshiyang.record.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class RecordQueryDTO {
	private String employeeId;//员工工号ID
	private String recordContent;//操作内容
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date recordTimeStart;//搜索操作时间的左边界
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date recordTimeEnd;//搜索操作时间的右边界
	
	public String getEmployeeId() {
		return employeeId;
	}
	public String getRecordContent() {
		return recordContent;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getRecordTimeStart() {
		return recordTimeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getRecordTimeEnd() {
		return recordTimeEnd;
	}
	
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setRecordContent(String recordContent) {
		this.recordContent = recordContent;
	}
	public void setRecordTimeStart(Date recordTimeStart) {
		this.recordTimeStart = recordTimeStart;
	}
	public void setRecordTimeEnd(Date recordTimeEnd) {
		this.recordTimeEnd = recordTimeEnd;
	}
	
	@SuppressWarnings({ "serial"})
	public static Specification<Record> getWhereClause(final RecordQueryDTO recordQueryDTO) {
		return new Specification<Record>() {
			@Override
			public Predicate toPredicate(Root<Record> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
			
				List<Predicate> predicate = new ArrayList<>();
				
				if (StringUtils.isNotBlank(recordQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + recordQueryDTO.getEmployeeId() + "%"));
				}
				if (null!=recordQueryDTO.getRecordTimeStart()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("recordTime").as(Date.class),
							recordQueryDTO.getRecordTimeStart()));
				}
				if (null!=recordQueryDTO.getRecordTimeEnd()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("recordTime").as(Date.class),
							recordQueryDTO.getRecordTimeEnd()));
				}
				if (StringUtils.isNotBlank(recordQueryDTO.getRecordContent())) {
					predicate.add(criteriaBuilder.like(root.get("recordContent").as(String.class),
							"%" + recordQueryDTO.getRecordContent() + "%"));
				}
				
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}