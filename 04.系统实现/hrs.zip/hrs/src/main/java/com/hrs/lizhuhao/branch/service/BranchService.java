package com.hrs.lizhuhao.branch.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.lizhuhao.branch.dao.BranchDao;
import com.hrs.lizhuhao.branch.domain.Branch;
import com.hrs.lizhuhao.branch.domain.BranchDTO;

@Service
@Transactional
public class BranchService implements IBranchService {
	@Autowired
	private BranchDao branchDao;
	
	//增加对象
	public void save(BranchDTO dto) {
		Branch entity=new Branch();
		BranchDTO.dto2Entity(dto, entity);
        branchDao.save(entity);
	}
	//通过id删除对象
	public void deleteById(Long id) {
		branchDao.deleteById(id);
	}
	//批量删除
	public void deleteAll(Long[] ids) {
		List<Long> idLists=new ArrayList<Long>(Arrays.asList(ids));
		List<Branch> branchs = (List<Branch>) branchDao.findAllById(idLists);
		if(branchs!=null) {
			branchDao.deleteAll(branchs);
		}
	}
	//通过ID查找对象
	public BranchDTO findById(Long id) {
		Branch entity=branchDao.findById(id).get();
		BranchDTO dto=new BranchDTO();
		BranchDTO.entity2Dto(entity, dto);
		return dto;
	}
	//通过id判断是否存在对象
	public boolean existsById(Long id) {
		return branchDao.existsById(id);
	}
	//统计表中数据总数
	public long count() {
		return branchDao.count();
	}
	//查看全部
	public Page<BranchDTO> findAll(Specification<Branch> spec, Pageable pageable) {
		Page<Branch> entityList=branchDao.findAll(spec,pageable);
		List<BranchDTO> dtoList = new ArrayList<BranchDTO>();
		for(Branch entity:entityList) {
			BranchDTO dto=new BranchDTO();
			BranchDTO.entity2Dto(entity, dto);
			dtoList.add(dto);
		}
		return new PageImpl<BranchDTO>(dtoList,pageable,entityList.getTotalElements());
	}
	//查看全部
	public List<BranchDTO> findAll(){
		List<Branch> entities = (List<Branch>) branchDao.findAll();
		List<BranchDTO> dtoLists = new ArrayList<BranchDTO>();
		for (Branch entity : entities) {
			BranchDTO dto = new BranchDTO();
			BranchDTO.entity2Dto(entity, dto);
			dtoLists.add(dto);
		}
		return dtoLists;
	}
}