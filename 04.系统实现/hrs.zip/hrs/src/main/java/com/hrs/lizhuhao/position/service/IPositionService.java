package com.hrs.lizhuhao.position.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.lizhuhao.position.domain.Position;
import com.hrs.lizhuhao.position.domain.PositionDTO;

public interface IPositionService {
	public void save(PositionDTO dto);					//增加对象
	public void deleteById(Long id);					//通过id删除对象
	public void deleteAll(Long[] ids);					//批量删除
	public PositionDTO findById(Long id);				//通过id查找对象
	public boolean existsById(Long id);					//通过id判断是否存在对象
	public long count();								//统计表中数据总数
	public List<PositionDTO> findBranchName(String positionName);//通过职位名查找对应的部门
	public List<PositionDTO> findPosition(String branchName);//通过部门名查找对应的职位
	public void deleteAll(List<PositionDTO> dtoLists);//删除全部
	public Page<PositionDTO> findAll(Specification<Position> spec,Pageable pageable);
}