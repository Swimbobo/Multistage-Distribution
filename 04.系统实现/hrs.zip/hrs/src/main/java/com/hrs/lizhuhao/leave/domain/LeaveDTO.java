package com.hrs.lizhuhao.leave.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;

public class LeaveDTO {
	private Long id;					//id
	private String employeeId;			//员工工号
	private String employeeName;		//员工姓名
	private Date leaveStartTime;		//开始时间
	private Date leaveEndTime;			//结束时间
	private String days1;				//请假天数
	private String leaveReasion;		//请假原因
	private String leaveType;			//请假类型（病假，出差）
	private String leaveProcessStatus;	//审核状态（待审核，通过，未通过）
	
	//getters
	public Long getId() {
		return id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getLeaveStartTime() {
		return leaveStartTime;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getLeaveEndTime() {
		return leaveEndTime;
	}
	public String getDays1() {
		return days1;
	}
	public String getLeaveReasion() {
		return leaveReasion;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public String getLeaveProcessStatus() {
		return leaveProcessStatus;
	}
	//setters
	public void setId(Long id) {
		this.id = id;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setLeaveStartTime(Date leaveStartTime) {
		this.leaveStartTime = leaveStartTime;
	}
	public void setDays1(String days1) {
		this.days1 = days1;
	}
	public void setLeaveEndTime(Date leaveEndTime) {
		this.leaveEndTime = leaveEndTime;
	}
	public void setLeaveReasion(String leaveReasion) {
		this.leaveReasion = leaveReasion;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	public void setLeaveProcessStatus(String leaveProcessStatus) {
		this.leaveProcessStatus = leaveProcessStatus;
	}
	//前端到后台（接收表单数据）
	public static void dto2Entity(LeaveDTO dto ,Leave entity) {
		int i=Integer.parseInt(dto.getDays1());
		entity.setDays(i);
		BeanUtils.copyProperties(dto, entity);
	}
	//后台到前端（返回JSON数据）
	public  static void entity2Dto(Leave entity ,LeaveDTO dto) {
		int i=entity.getDays();
		dto.setDays1(Integer.toString(i));
		BeanUtils.copyProperties(entity,dto);
	}
}