package com.hrs.youzhenjie.contract.domain;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.BaseDomain;
import com.hrs.youzhenjie.employee.domain.Employee;

@Entity
@Table(name = "t_contract")
public class Contract extends BaseDomain<Long> {

	private String employeeId;// 工号
	private String contractType;// 合同类型
	private String contractState;// 合同状态
	private String contractFile;// 合同文档
	private String contractProperties;// 合同属性
	private double contractSalary; // 基本工资
	private Date contractStartTime;// 合同开始时间
	private Date contractEndTime;// 合同结束时间
	private Date contractProbationDate;// 试用期结束时间
	
	//附加
	private String sfzcard;// 身份证

	private Employee employee;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="referenceId")
	public Employee getEmployee() {
		return employee;
	}

	@Column(unique = true, nullable = false)
	@NotNull
	public String getEmployeeId() {
		return employeeId;
	}

	public String getContractType() {
		return contractType;
	}

	@Column(length = 3)
	public String getContractState() {
		return contractState;
	}

	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss", timezone = "GMT+8")
	public Date getContractStartTime() {
		return contractStartTime;
	}

	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss", timezone = "GMT+8")
	public Date getContractEndTime() {
		return contractEndTime;
	}

	public String getContractProperties() {
		return contractProperties;
	}

	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss", timezone = "GMT+8")
	public Date getContractProbationDate() {
		return contractProbationDate;
	}

	public String getContractFile() {
		return contractFile;
	}

	public double getContractSalary() {
		return contractSalary;
	}
	

	public String getSfzcard() {
		return sfzcard;
	}

	public void setSfzcard(String sfzcard) {
		this.sfzcard = sfzcard;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public void setContractState(String contractState) {
		this.contractState = contractState;
	}

	public void setContractStartTime(Date contractStartTime) {
		this.contractStartTime = contractStartTime;
	}

	public void setContractEndTime(Date contractEndTime) {
		this.contractEndTime = contractEndTime;
	}

	public void setContractProperties(String contractProperties) {
		this.contractProperties = contractProperties;
	}

	public void setContractProbationDate(Date contractProbationDate) {
		this.contractProbationDate = contractProbationDate;
	}

	public void setContractFile(String contractFile) {
		this.contractFile = contractFile;
	}

	public void setContractSalary(double contractSalary) {
		this.contractSalary = contractSalary;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
}
