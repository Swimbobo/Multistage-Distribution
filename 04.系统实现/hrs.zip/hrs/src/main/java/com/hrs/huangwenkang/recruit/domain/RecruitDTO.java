package com.hrs.huangwenkang.recruit.domain;

import com.hrs.common.beans.BeanUtils;

public class RecruitDTO {
	private Long id;						//id
	private String recruitJob;				//需求职位
	private String recruitNumber1;			//招聘人数
	private String recruitRequirement;		//岗位需求
	private String recruitTreatment;		//公司待遇
	private String recruitAbout;			//关于公司
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getRecruitJob() {
		return recruitJob;
	}
	public void setRecruitJob(String recruitJob) {
		this.recruitJob = recruitJob;
	}
	public String getRecruitNumber1() {
		return recruitNumber1;
	}
	public void setRecruitNumber1(String recruitNumber1) {
		this.recruitNumber1 = recruitNumber1;
	}
	public String getRecruitRequirement() {
		return recruitRequirement;
	}
	public void setRecruitRequirement(String recruitRequirement) {
		this.recruitRequirement = recruitRequirement;
	}
	public String getRecruitTreatment() {
		return recruitTreatment;
	}
	public void setRecruitTreatment(String recruitTreatment) {
		this.recruitTreatment = recruitTreatment;
	}
	public String getRecruitAbout() {
		return recruitAbout;
	}
	public void setRecruitAbout(String recruitAbout) {
		this.recruitAbout = recruitAbout;
	}
	//前端到后台（接收表单数据）
	public static void dto2Entity(RecruitDTO dto ,Recruit entity) {
		//类型转换
		int i=Integer.parseInt(dto.getRecruitNumber1());
		entity.setRecruitNumber(i);
		BeanUtils.copyProperties(dto, entity);
	}
	//后台到前端（返回JSON数据）
	public  static void entity2Dto(Recruit entity ,RecruitDTO dto) {
		//类型转换
		int i=entity.getRecruitNumber();
		String s=Integer.toString(i);
		dto.setRecruitNumber1(s);
		BeanUtils.copyProperties(entity,dto);
	}
}