package com.hrs.zhanshiyang.template.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_template")
@XmlRootElement
public class Template extends BaseDomain<Long> {
	private String templateHead;//评估模板标题
	private Boolean templateStatus;//评估模板的发布状态（默认值为false，评估完成为true）
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date templateTimeStart;//员工绩效评估开始时间
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date templateTimeEnd;//员工绩效评估结束时间
	
	public Template() {
		this.templateStatus = false;
	}
	
//	getters
	@Column(nullable=false)
	public String getTemplateHead() {
		return templateHead;
	}
	@Column(nullable=false,columnDefinition="bit(1) default 0")
	public Boolean getTemplateStatus() {
		return templateStatus;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	@Column(nullable=false)
	public Date getTemplateTimeStart() {
		return templateTimeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	@Column(nullable=false)
	public Date getTemplateTimeEnd() {
		return templateTimeEnd;
	}
	
//	setters
	public void setTemplateHead(String templateHead) {
		this.templateHead = templateHead;
	}
	public void setTemplateStatus(Boolean templateStatus) {
		this.templateStatus = templateStatus;
	}
	public void setTemplateTimeStart(Date templateTimeStart) {
		this.templateTimeStart = templateTimeStart;
	}
	public void setTemplateTimeEnd(Date templateTimeEnd) {
		this.templateTimeEnd = templateTimeEnd;
	}
	
	@Override
	public String toString() {
		return "Template [templateHead=" + templateHead + ", templateStatus=" + templateStatus + ", templateTimeStart="
				+ templateTimeStart + ", templateTimeEnd=" + templateTimeEnd + "]";
	}
	
}
