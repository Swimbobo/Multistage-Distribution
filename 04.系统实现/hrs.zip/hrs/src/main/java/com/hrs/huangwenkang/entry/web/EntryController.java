package com.hrs.huangwenkang.entry.web;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.huangwenkang.entry.domain.EntryDTO;
import com.hrs.huangwenkang.entry.domain.EntryQueryDTO;
import com.hrs.huangwenkang.entry.service.IEntryService;
import com.hrs.huangwenkang.interview.service.IInterviewService;
import com.hrs.huangwenkang.resume.service.IResumeService;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@RestController
@RequestMapping("/entry")
public class EntryController {
	@Autowired
	private IEntryService entryService;
	@Autowired
	private IInterviewService interviewService;
	@Autowired
	private IResumeService resumeService;
	@Autowired
	private IRecordService recordService;
	
	//显示全部数据
	@GetMapping
	public @ResponseBody Page<EntryDTO> getPage(EntryQueryDTO entryQueryDTO , ExtjsPageRequest pageRequest) {
		return entryService.findAll(EntryQueryDTO.getWhereClause(entryQueryDTO), pageRequest.getPageable());
	}
	//显示某条数据
	@GetMapping(value="{id}")
	public EntryDTO getOne(@PathVariable("id") Long id) {
		return entryService.findById(id);
	}
	//增加数据
	@PostMapping("/save")
	public ExtAjaxResponse save(@RequestParam(value = "id") String id,
			@RequestParam(value = "resumeId1") String resumeId1,
			@RequestParam(value = "interviewName") String interviewName,
			@RequestParam(value = "interviewSex") String interviewSex,
			@RequestParam(value = "interviewTel") String interviewTel,
			@RequestParam(value = "interviewJobWanted") String interviewJobWanted,
			@RequestParam(value = "interviewComment") String interviewComment,
			@RequestParam(value = "interviewRes") String interviewRes){
		//String类型转换为Long
		Long i=Long.valueOf(id);
		Long ii=Long.valueOf(resumeId1);
		//向DTO注入属性
		EntryDTO dto=new EntryDTO();
		dto.setInterviewId1(id);
		dto.setResumeId1(resumeId1);
		dto.setEntryName(interviewName);
		dto.setEntrySex(interviewSex);
		dto.setEntryTel(interviewTel);
		dto.setEntryposition(interviewJobWanted);
		if(interviewRes.equals("待入职")) {
			try{
				entryService.save(dto);
				interviewService.updateinterviewComment(interviewComment, i);
				interviewService.updateInterviewRes("待入职",i);
				resumeService.updateResumeStatus("面试结束",ii);
				writeLog("添加");
				return new ExtAjaxResponse(true,"保存成功！");
			}catch(Exception e) {
				return new ExtAjaxResponse(true,"保存失败！");
			}
		}else{
			try{
				interviewService.updateInterviewRes("不通过",i);
				resumeService.updateResumeStatus("面试结束",ii);
				return new ExtAjaxResponse(true,"保存成功！");
			}catch(Exception e) {
				return new ExtAjaxResponse(true,"保存失败！");
				}
		}
	}
	//日志操作
	public void writeLog(String operation){
		HttpServletRequest request=((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session=request.getSession();
		String employeeId=SessionUtil.getEmployeeId(session);
		RecordDTO recordDTO=new RecordDTO();
		recordDTO.setEmployeeId(employeeId);
		recordDTO.setRecordContent(operation+" 待入职信息成功");
		recordDTO.setRecordTime(new Date());
		recordService.save(recordDTO);
	}
}