package com.hrs.lizhuhao.overtime.domain;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_overtime")
public class Overtime extends BaseDomain<Long>{
	private String employeeId;				//员工工号
	private String employeeName;			//员工姓名
	@DateTimeFormat(pattern="yyyy/MM/dd")
	private Date overtimeDate;				//加班日期
	private int overtimeStartTime;			//开始时间
	private int overtimeEndTime;			//结束时间
	private int hour;						//一次加班为多长
	private String overtimeStatus;			//状态
	
	public  Overtime() {
		this.overtimeStatus="待审批";
	}
	//getters
	@Column(nullable=false)
	public String getEmployeeId() {
		return employeeId;
	}
	@Column(nullable=false)
	public String getEmployeeName() {
		return employeeName;
	}
	@Column(nullable=false)
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getOvertimeDate() {
		return overtimeDate;
	}
	@Column(nullable=false)
	public int getOvertimeStartTime() {
		return overtimeStartTime;
	}
	@Column(nullable=false)
	public int getOvertimeEndTime() {
		return overtimeEndTime;
	}
	@Column(nullable=false)
	public int getHour() {
		return hour;
	}
	@Column(nullable=false)
	public String getOvertimeStatus() {
		return overtimeStatus;
	}
	//setters
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setOvertimeDate(Date overtimeDate) {
		this.overtimeDate = overtimeDate;
	}
	public void setOvertimeStartTime(int overtimeStartTime) {
		this.overtimeStartTime = overtimeStartTime;
	}
	public void setOvertimeEndTime(int overtimeEndTime) {
		this.overtimeEndTime = overtimeEndTime;
	}
	public void setHour(int hour) {
		this.hour = hour;
	}
	public void setOvertimeStatus(String overtimeStatus) {
		this.overtimeStatus = overtimeStatus;
	}
}