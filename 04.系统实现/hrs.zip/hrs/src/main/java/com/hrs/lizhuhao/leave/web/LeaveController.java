package com.hrs.lizhuhao.leave.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hrs.common.beans.BeanUtils;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.lizhuhao.leave.domain.Leave;
import com.hrs.lizhuhao.leave.domain.LeaveDTO;
import com.hrs.lizhuhao.leave.domain.LeaveQueryDTO;
import com.hrs.lizhuhao.leave.service.ILeaveService;

@RestController
@RequestMapping("/leave")
public class LeaveController {
	@Autowired
	private ILeaveService leaveService;
	//显示全部数据
	@GetMapping
	public @ResponseBody Page<LeaveDTO> getPage(LeaveQueryDTO leaveQueryDTO , ExtjsPageRequest pageRequest) {
		return leaveService.findAll(LeaveQueryDTO.getWhereClause(leaveQueryDTO), pageRequest.getPageable());
	}
	//显示当前数据
	@GetMapping("/getOne")
	public @ResponseBody Page<LeaveDTO> getPageByEmployeeId(LeaveQueryDTO leaveQueryDTO , ExtjsPageRequest pageRequest) {
		return leaveService.findAll(LeaveQueryDTO.getWhereByEmployeeId(leaveQueryDTO), pageRequest.getPageable());
	}
	//显示某条数据
	@GetMapping("{id}")
	public LeaveDTO getOne(@PathVariable("id") Long id) {
		return leaveService.findById(id);
	}
	//删除某条数据
	@PostMapping("/getOne/detete")
	public ExtAjaxResponse delete(@RequestParam(name="id") String id) {
		Long i=Long.valueOf(id);
		try {
			if(i!=null) {
				leaveService.deleteById(i);
			}
			return new ExtAjaxResponse(true,"删除成功！");
		}catch (Exception e) {
			return new ExtAjaxResponse(true,"删除失败！");
			}
	}
	//批量删除
	@PostMapping("/deletes")
	public ExtAjaxResponse deleteRows(@RequestParam(name="ids") Long[] ids) {
		try {
			if(ids!=null) {
				leaveService.deleteAll(ids);
			}
			return new ExtAjaxResponse(true,"批量删除成功！");
		}catch (Exception e) {
			return new ExtAjaxResponse(true,"批量删除失败！");
			}
	}
	//修改数据
	@PutMapping(value="{id}",consumes=MediaType.APPLICATION_JSON_VALUE)
	public ExtAjaxResponse update(@PathVariable("id") Long myId,@RequestBody Leave dto) {
		try {
			LeaveDTO entity = leaveService.findById(myId);
			if(entity!=null) {
				BeanUtils.copyProperties(dto, entity);//使用自定义的BeanUtils
				leaveService.save(entity);
			}
			return new ExtAjaxResponse(true,"更新成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"更新失败！");
		}
	}
	//增加数据
	@PostMapping(consumes=MediaType.APPLICATION_JSON_VALUE)
	public ExtAjaxResponse save(@RequestBody LeaveDTO leave) {
		try {
			leaveService.save(leave);
			return new ExtAjaxResponse(true,"保存成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"保存失败！");
		}
	}
}