package com.hrs.zhanshiyang.bonus.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.zhanshiyang.bonus.domain.Bonus;

@Repository
public interface BonusDao extends 
		PagingAndSortingRepository<Bonus,Long>,JpaSpecificationExecutor<Bonus>
{

}
