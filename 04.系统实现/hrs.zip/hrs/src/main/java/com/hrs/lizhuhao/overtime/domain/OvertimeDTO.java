package com.hrs.lizhuhao.overtime.domain;

import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;

public class OvertimeDTO {
	private Long id;						//id
	private String employeeId;				//员工工号
	private String employeeName;			//员工姓名
	@DateTimeFormat(pattern="yyyy/MM/dd")
	private Date overtimeDate;				//加班日期
	private String overtimeStartTime1;		//开始时间
	private String overtimeEndTime1;		//结束时间
	private String hour1;					//一次加班为多长
	private String overtimeStatus;			//状态
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getOvertimeDate() {
		return overtimeDate;
	}
	public void setOvertimeDate(Date overtimeDate) {
		this.overtimeDate = overtimeDate;
	}
	public String getOvertimeStartTime1() {
		return overtimeStartTime1;
	}
	public void setOvertimeStartTime1(String overtimeStartTime1) {
		this.overtimeStartTime1 = overtimeStartTime1;
	}
	public String getOvertimeEndTime1() {
		return overtimeEndTime1;
	}
	public void setOvertimeEndTime1(String overtimeEndTime1) {
		this.overtimeEndTime1 = overtimeEndTime1;
	}
	public String getHour1() {
		return hour1;
	}
	public void setHour1(String hour1) {
		this.hour1 = hour1;
	}
	public String getOvertimeStatus() {
		return overtimeStatus;
	}
	public void setOvertimeStatus(String overtimeStatus) {
		this.overtimeStatus = overtimeStatus;
	}
	//前端到后台（接收表单数据）
	public static void dto2Entity(OvertimeDTO dto ,Overtime entity) {
		//类型转换
		int s=Integer.parseInt(dto.getOvertimeStartTime1());
		int e=Integer.parseInt(dto.getOvertimeEndTime1());
		int i=Integer.parseInt(dto.getHour1());
		entity.setHour(i);
		entity.setOvertimeStartTime(s);
		entity.setOvertimeEndTime(e);
		BeanUtils.copyProperties(dto, entity);
	}
	//后台到前端（返回JSON数据）
	public  static void entity2Dto(Overtime entity ,OvertimeDTO dto) {
		int i=entity.getHour();
		int s=entity.getOvertimeStartTime();
		int e=entity.getOvertimeEndTime();
		dto.setHour1(Integer.toString(i));
		dto.setOvertimeStartTime1(Integer.toString(s));
		dto.setOvertimeEndTime1(Integer.toString(e));
		BeanUtils.copyProperties(entity,dto);
	}
}