package com.hrs.huangwenkang.interview.web;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.huangwenkang.interview.domain.InterviewDTO;
import com.hrs.huangwenkang.interview.domain.InterviewQueryDTO;
import com.hrs.huangwenkang.interview.service.IInterviewService;
import com.hrs.huangwenkang.resume.service.IResumeService;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@RestController
@RequestMapping("/interview")
public class InterviewController {
	@Autowired
	private IInterviewService interviewService;
	@Autowired
	private IResumeService resumeService;
	@Autowired
	private IRecordService recordService;
	
	//显示全部数据
	@GetMapping
	public @ResponseBody Page<InterviewDTO> getPage(InterviewQueryDTO interviewQueryDTO , ExtjsPageRequest pageRequest) {
		return interviewService.findAll(InterviewQueryDTO.getWhereClause(interviewQueryDTO), pageRequest.getPageable());
	}
	//显示某条数据
	@PostMapping(value="{id}")
	public InterviewDTO getOne(@PathVariable("id") String id) {
		//String类型转换为Long
		Long i=Long.valueOf(id);
		InterviewDTO interview=interviewService.findById(i);
		return interview;
	}
	//增加数据
	@PostMapping("/save")
	public ExtAjaxResponse save(@RequestParam(value = "id") String id,
			@RequestParam(value = "resumeName") String resumeName,
			@RequestParam(value = "resumeSex") String resumeSex,
			@RequestParam(value = "resumeTel") String resumeTel,
			@RequestParam(value = "resumeEduBackground") String resumeEduBackground,
			@RequestParam(value = "resumeJobWanted") String resumeJobWanted,
			@RequestParam(value = "interviewTime") String interviewTime,
			@RequestParam(value = "interviewPlace") String interviewPlace) throws ParseException{
		//String类型转换为Date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = sdf.parse(interviewTime);
		//String类型转换为Long
		Long i=Long.valueOf(id);
		//向面试表DTO注入属性
		InterviewDTO dto=new InterviewDTO();
		dto.setResumeId1(id);
		dto.setInterviewName(resumeName);
		dto.setInterviewSex(resumeSex);
		dto.setInterviewTel(resumeTel);
		dto.setInterviewEduBackground(resumeEduBackground);
		dto.setInterviewJobWanted(resumeJobWanted);
		dto.setInterviewTime(date);
		dto.setInterviewPlace(interviewPlace);
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession  session=request.getSession();
		String employeeId=SessionUtil.getEmployeeId(session);
		RecordDTO recordDTO = new RecordDTO();
		recordDTO.setEmployeeId(employeeId);
		recordDTO.setRecordContent("通过 简历信息成功");
		recordDTO.setRecordTime(new Date());
		try {
			interviewService.save(dto);
			resumeService.updateResumeStatus("等待面试",i);
			recordService.save(recordDTO);
			return new ExtAjaxResponse(true,"保存成功！");
		}catch(Exception e) {
			return new ExtAjaxResponse(true,"保存失败！");
			}
		}
	//日志操作
	public void writeLog(String operation){
		HttpServletRequest request=((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session=request.getSession();
		String employeeId=SessionUtil.getEmployeeId(session);
		RecordDTO recordDTO=new RecordDTO();
		recordDTO.setEmployeeId(employeeId);
		recordDTO.setRecordContent(operation+" 面试信息成功");
		recordDTO.setRecordTime(new Date());
		recordService.save(recordDTO);
	}
}