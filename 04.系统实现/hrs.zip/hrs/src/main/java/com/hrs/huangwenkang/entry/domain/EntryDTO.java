package com.hrs.huangwenkang.entry.domain;

import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;

import com.hrs.common.beans.BeanUtils;

public class EntryDTO{
	private Long id;							//id
	private String interviewId1;				//面试表id
	private String resumeId1;					//简历表id
	private String entryName;					//姓名
	private String entrySex;					//性别
	private String entrybranch;					//部门
	private String entryposition;				//职位
	private String entryTel;					//联系电话
	@DateTimeFormat(pattern="yyyy/MM/dd")
	private Date entryExpectedEntryDate;		//预计入职日期
	@DateTimeFormat(pattern="yyyy/MM/dd")
	private Date entryConfirmedEntryDate;		//确认入职日期
	private String entryStatus;					//待入职状态
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getInterviewId1() {
		return interviewId1;
	}
	public void setInterviewId1(String interviewId1) {
		this.interviewId1 = interviewId1;
	}
	public String getResumeId1() {
		return resumeId1;
	}
	public void setResumeId1(String resumeId1) {
		this.resumeId1 = resumeId1;
	}
	public String getEntryName() {
		return entryName;
	}
	public void setEntryName(String entryName) {
		this.entryName = entryName;
	}
	public String getEntrySex() {
		return entrySex;
	}
	public void setEntrySex(String entrySex) {
		this.entrySex = entrySex;
	}
	public String getEntrybranch() {
		return entrybranch;
	}
	public void setEntrybranch(String entrybranch) {
		this.entrybranch = entrybranch;
	}
	public String getEntryposition() {
		return entryposition;
	}
	public void setEntryposition(String entryposition) {
		this.entryposition = entryposition;
	}
	public String getEntryTel() {
		return entryTel;
	}
	public void setEntryTel(String entryTel) {
		this.entryTel = entryTel;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getEntryExpectedEntryDate() {
		return entryExpectedEntryDate;
	}
	public void setEntryExpectedEntryDate(Date entryExpectedEntryDate) {
		this.entryExpectedEntryDate = entryExpectedEntryDate;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getEntryConfirmedEntryDate() {
		return entryConfirmedEntryDate;
	}
	public void setEntryConfirmedEntryDate(Date entryConfirmedEntryDate) {
		this.entryConfirmedEntryDate = entryConfirmedEntryDate;
	}
	public String getEntryStatus() {
		return entryStatus;
	}
	public void setEntryStatus(String entryStatus) {
		this.entryStatus = entryStatus;
	}
	
	//前端到后台（接收表单数据）
	public static void dto2Entity(EntryDTO dto ,Entry entity){
		//类型转换
		Long i=Long.valueOf(dto.getInterviewId1());
		Long ii=Long.valueOf(dto.getResumeId1());
		entity.setInterviewId(i);
		entity.setResumeId(ii);
		BeanUtils.copyProperties(dto, entity);
	}
	//后台到前端（返回JSON数据）
	public  static void entity2Dto(Entry entity ,EntryDTO dto){
		//类型转换
		Long inter=entity.getInterviewId();
		Long resume=entity.getResumeId();
		String inters=Long.toString(inter);
		String resumes=Long.toString(resume);
		dto.setInterviewId1(inters);
		dto.setResumeId1(resumes);
		BeanUtils.copyProperties(entity,dto);
	}
}