package com.hrs.youzhenjie.contract.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;
import com.hrs.youzhenjie.employee.domain.Employee;

public class ContractAndEmployeeDTO{
	private Long id;
	// 查询的参数
	private String employeeId;// 工号

	private String contractType;// 合同类型
	private String contractState;// 合同状态
	private String contractFile;// 合同文档
	private String contractProperties;// 合同属性
	private double contractSalary; // 基本工资
	
	//附加
	private String sfzcard;// 身份证
	
	private Long referenceId; //关联ID

	private Employee emp;
	
	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date contractStartTime;// 合同开始时间

	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date contractEndTime;// 合同结束时间

	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date contractProbationDate;// 试用期结束时间

	private String employeeName;// 姓名
	private String employeeSex;// 性别
	private String employeeDepartment;// 部门
	private String employeePosition;// 职位
	private String employeeTel;// 电话
	private String employeeState;// 在职状态

	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date employeeEntryTime;// 入职日期

	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date employeeLeaveTime;// 离职日期

	
	
	public String getSfzcard() {
		return sfzcard;
	}

	public void setSfzcard(String sfzcard) {
		this.sfzcard = sfzcard;
	}

	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}

	public Long getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(Long referenceId) {
		this.referenceId = referenceId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeSex() {
		return employeeSex;
	}

	public void setEmployeeSex(String employeeSex) {
		this.employeeSex = employeeSex;
	}

	public String getEmployeeDepartment() {
		return employeeDepartment;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setEmployeeDepartment(String employeeDepartment) {
		this.employeeDepartment = employeeDepartment;
	}

	public String getEmployeePosition() {
		return employeePosition;
	}

	public void setEmployeePosition(String employeePosition) {
		this.employeePosition = employeePosition;
	}

	public String getEmployeeTel() {
		return employeeTel;
	}

	public void setEmployeeTel(String employeeTel) {
		this.employeeTel = employeeTel;
	}

	public String getEmployeeState() {
		return employeeState;
	}

	public void setEmployeeState(String employeeState) {
		this.employeeState = employeeState;
	}

	public Date getEmployeeEntryTime() {
		return employeeEntryTime;
	}

	public void setEmployeeEntryTime(Date employeeEntryTime) {
		this.employeeEntryTime = employeeEntryTime;
	}

	public Date getEmployeeLeaveTime() {
		return employeeLeaveTime;
	}

	public void setEmployeeLeaveTime(Date employeeLeaveTime) {
		this.employeeLeaveTime = employeeLeaveTime;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public String getContractState() {
		return contractState;
	}

	public void setContractState(String contractState) {
		this.contractState = contractState;
	}

	public String getContractFile() {
		return contractFile;
	}

	public void setContractFile(String contractFile) {
		this.contractFile = contractFile;
	}

	public String getContractProperties() {
		return contractProperties;
	}

	public void setContractProperties(String contractProperties) {
		this.contractProperties = contractProperties;
	}

	public Date getContractStartTime() {
		return contractStartTime;
	}

	public void setContractStartTime(Date contractStartTime) {
		this.contractStartTime = contractStartTime;
	}

	public Date getContractEndTime() {
		return contractEndTime;
	}

	public double getContractSalary() {
		return contractSalary;
	}

	public void setContractSalary(double contractSalary) {
		this.contractSalary = contractSalary;
	}

	public void setContractEndTime(Date contractEndTime) {
		this.contractEndTime = contractEndTime;
	}

	public Date getContractProbationDate() {
		return contractProbationDate;
	}

	public void setContractProbationDate(Date contractProbationDate) {
		this.contractProbationDate = contractProbationDate;
	}

	// 前端到后台（接收表单数据）
	public static void dto2EntityCon(ContractAndEmployeeDTO dto, Contract entity) {
		BeanUtils.copyProperties(dto, entity);
	}

	// 后台到前端（返回JSON数据）：find 显示什么数据？
	public static void entityCon2Dto(Contract entity, ContractAndEmployeeDTO dto) {
		BeanUtils.copyProperties(entity, dto);
	}

	
}
