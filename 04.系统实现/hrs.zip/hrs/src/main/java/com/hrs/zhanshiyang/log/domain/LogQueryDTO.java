package com.hrs.zhanshiyang.log.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

public class LogQueryDTO {
	private String employeeId;//员工工号ID
	private String logPermission;//员工的权限设置（0-9，权限逐级递减，默认权限最小）
	
	public String getEmployeeId() {
		return employeeId;
	}
	public String getLogPermission() {
		return logPermission;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setLogPermission(String logPermission) {
		this.logPermission = logPermission;
	}

	@SuppressWarnings({ "serial"})
	public static Specification<Log> getWhereClause(final LogQueryDTO logQueryDTO) {
		return new Specification<Log>() {
			@Override
			public Predicate toPredicate(Root<Log> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();
				if (StringUtils.isNotBlank(logQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("emploeeId").as(String.class),
							"%" + logQueryDTO.getEmployeeId() + "%"));
				}
				if (StringUtils.isNotBlank(logQueryDTO.getLogPermission())) {
					predicate.add(criteriaBuilder.equal(root.get("logPermission").as(String.class),
							logQueryDTO.getLogPermission()));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}