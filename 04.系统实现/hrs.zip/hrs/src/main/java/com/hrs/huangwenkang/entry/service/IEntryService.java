package com.hrs.huangwenkang.entry.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.huangwenkang.entry.domain.Entry;
import com.hrs.huangwenkang.entry.domain.EntryDTO;

public interface IEntryService {
	public Entry save(EntryDTO dto);			//增加对象
	public void deleteById(Long id);			//通过id删除对象
	public void deleteAll(Long[] ids);			//批量删除
	public EntryDTO findById(Long id);			//通过id查找对象
	public boolean existsById(Long id);			//通过id判断是否存在对象
	public long count();						//统计表中数据总数
	public void updateEntryRes(Long id);		//
	public Page<EntryDTO> findAll(Specification<Entry> spec, Pageable pageable);
}