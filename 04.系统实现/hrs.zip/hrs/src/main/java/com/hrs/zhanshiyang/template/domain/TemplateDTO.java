package com.hrs.zhanshiyang.template.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;

public class TemplateDTO {
	private Long id;
	private String templateHead;//评估模板标题
	private Boolean templateStatus;//评估模板的发布状态（默认值为false，评估完成为true）
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date templateTimeStart;//员工绩效评估开始时间
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date templateTimeEnd;//员工绩效评估结束时间
	
	public Long getId() {
		return id;
	}
	public String getTemplateHead() {
		return templateHead;
	}
	public Boolean getTemplateStatus() {
		return templateStatus;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getTemplateTimeStart() {
		return templateTimeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getTemplateTimeEnd() {
		return templateTimeEnd;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public void setTemplateHead(String templateHead) {
		this.templateHead = templateHead;
	}
	public void setTemplateStatus(Boolean templateStatus) {
		this.templateStatus = templateStatus;
	}
	public void setTemplateTimeStart(Date templateTimeStart) {
		this.templateTimeStart = templateTimeStart;
	}
	public void setTemplateTimeEnd(Date templateTimeEnd) {
		this.templateTimeEnd = templateTimeEnd;
	}
	
	//前端到后台（接收表单数据）:save 和 update	如何维护关联关系？
	public  static void dto2Entity(TemplateDTO dto ,Template entity) {
		BeanUtils.copyProperties(dto, entity);	
	}
	//后台到前端（返回JSON数据）：find	显示什么数据？
	public  static void entity2Dto(Template entity ,TemplateDTO dto) {
		BeanUtils.copyProperties(entity , dto);
	}
}
