package com.hrs.huangwenkang.interview.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class InterviewQueryDTO {
	private String interviewName;				//面试者姓名
	private String interviewEduBackground;		//面试者最高学历
	@DateTimeFormat(pattern="yyyy/MM/dd HH:mm:ss")
	private Date interviewTimeStart;			//查询开始时间
	@DateTimeFormat(pattern="yyyy/MM/dd HH:mm:ss")
	private Date interviewTimeEnd;				//查询结束时间
	private String interviewRes;				//面试结果
	
	public String getInterviewName() {
		return interviewName;
	}
	public void setInterviewName(String interviewName) {
		this.interviewName = interviewName;
	}
	public String getInterviewEduBackground() {
		return interviewEduBackground;
	}
	public void setInterviewEduBackground(String interviewEduBackground) {
		this.interviewEduBackground = interviewEduBackground;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getInterviewTimeStart() {
		return interviewTimeStart;
	}
	public void setInterviewTimeStart(Date interviewTimeStart) {
		this.interviewTimeStart = interviewTimeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getInterviewTimeEnd() {
		return interviewTimeEnd;
	}
	public void setInterviewTimeEnd(Date interviewTimeEnd) {
		this.interviewTimeEnd = interviewTimeEnd;
	}
	public String getInterviewRes() {
		return interviewRes;
	}
	public void setInterviewRes(String interviewRes) {
		this.interviewRes = interviewRes;
	}
	@SuppressWarnings({ "serial"})
	public static Specification<Interview> getWhereClause(final InterviewQueryDTO interviewQueryDTO) {
		return new Specification<Interview>() {
			@Override
			public Predicate toPredicate(Root<Interview> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();
				if (StringUtils.isNotBlank(interviewQueryDTO.getInterviewName())) {
					predicate.add(criteriaBuilder.like(root.get("interviewName").as(String.class),
							"%"+interviewQueryDTO.getInterviewName()+"%"));
				}
				if (StringUtils.isNotBlank(interviewQueryDTO.getInterviewEduBackground())) {
					predicate.add(criteriaBuilder.like(root.get("interviewEduBackground").as(String.class),
							"%"+interviewQueryDTO.getInterviewEduBackground()+"%"));
				}
				if (null!=interviewQueryDTO.getInterviewTimeStart()){
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("interviewTime").as(Date.class),
							interviewQueryDTO.getInterviewTimeStart()));
				}
				if (null!=interviewQueryDTO.getInterviewTimeEnd()){
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("interviewTime").as(Date.class),
							interviewQueryDTO.getInterviewTimeEnd()));
				}
				if (StringUtils.isNotBlank(interviewQueryDTO.getInterviewRes())) {
					predicate.add(criteriaBuilder.equal(root.get("interviewRes").as(String.class),
							interviewQueryDTO.getInterviewRes()));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}