package com.hrs.zhanshiyang.log.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.zhanshiyang.log.domain.Log;
import com.hrs.zhanshiyang.log.domain.LogDTO;

public interface ILogService {
//	CrudRepository接口：
	public void save(LogDTO dto);
	public LogDTO findById(Long id);
	public void deleteById(Long id);
	public void deleteAll(List<LogDTO> dtoLists);
//	PagingAndSortingRepository extends CrudRepository接口：
	public Page<LogDTO> findAll(Specification<Log> spec, Pageable pageable);
//	自定义查询：
	public void saveByEntity(Log log);
	public Log Login(String employeeId,String logPassword);
	public Log findByEmployeeId(String employeeId);
	public void updatePassword(String logPassword,String employeeId,String oldPassword);
}