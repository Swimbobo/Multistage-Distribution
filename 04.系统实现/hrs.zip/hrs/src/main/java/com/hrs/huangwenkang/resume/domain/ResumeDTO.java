package com.hrs.huangwenkang.resume.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;

public class ResumeDTO {
	private Long id;						//Id
	private String resumeName;				//姓名
	private String resumeSex;				//性别
	private String resumeTel;				//联系电话
	private String resumeEmail;				//邮箱
	@DateTimeFormat(pattern="yyyy/MM")
	private Date resumeBirth;				//出生年月
	private String resumeGraduate;			//毕业院校
	@DateTimeFormat(pattern="yyyy/MM")
	private Date resumeGraduateTime;		//毕业年月
	private String resumeMajor;				//所修专业
	private String resumeWorkYear1;			//工作年限
	private String resumeAddress;			//住址
	private String resumeJobWanted;			//应聘职位
	private String resumeExperience;		//个人经历
	private String resumeSupplement;		//补充内容
	private String resumeEduBackground;		//学历背景
	private String resumeStatus;			//简历状态
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getResumeName() {
		return resumeName;
	}
	public void setResumeName(String resumeName) {
		this.resumeName = resumeName;
	}
	public String getResumeSex() {
		return resumeSex;
	}
	public void setResumeSex(String resumeSex) {
		this.resumeSex = resumeSex;
	}
	public String getResumeTel() {
		return resumeTel;
	}
	public void setResumeTel(String resumeTel) {
		this.resumeTel = resumeTel;
	}
	public String getResumeEmail() {
		return resumeEmail;
	}
	public void setResumeEmail(String resumeEmail) {
		this.resumeEmail = resumeEmail;
	}
	@JsonFormat(pattern="yyyy/MM",timezone="GMT+8")
	public Date getResumeBirth() {
		return resumeBirth;
	}
	public void setResumeBirth(Date resumeBirth) {
		this.resumeBirth = resumeBirth;
	}
	public String getResumeGraduate() {
		return resumeGraduate;
	}
	public void setResumeGraduate(String resumeGraduate) {
		this.resumeGraduate = resumeGraduate;
	}
	@JsonFormat(pattern="yyyy/MM",timezone="GMT+8")
	public Date getResumeGraduateTime() {
		return resumeGraduateTime;
	}
	public void setResumeGraduateTime(Date resumeGraduateTime) {
		this.resumeGraduateTime = resumeGraduateTime;
	}
	public String getResumeMajor() {
		return resumeMajor;
	}
	public void setResumeMajor(String resumeMajor) {
		this.resumeMajor = resumeMajor;
	}
	public String getResumeWorkYear1() {
		return resumeWorkYear1;
	}
	public void setResumeWorkYear1(String resumeWorkYear1) {
		this.resumeWorkYear1 = resumeWorkYear1;
	}
	public String getResumeAddress() {
		return resumeAddress;
	}
	public void setResumeAddress(String resumeAddress) {
		this.resumeAddress = resumeAddress;
	}
	public String getResumeJobWanted() {
		return resumeJobWanted;
	}
	public void setResumeJobWanted(String resumeJobWanted) {
		this.resumeJobWanted = resumeJobWanted;
	}
	public String getResumeExperience() {
		return resumeExperience;
	}
	public void setResumeExperience(String resumeExperience) {
		this.resumeExperience = resumeExperience;
	}
	public String getResumeSupplement() {
		return resumeSupplement;
	}
	public void setResumeSupplement(String resumeSupplement) {
		this.resumeSupplement = resumeSupplement;
	}
	public String getResumeEduBackground() {
		return resumeEduBackground;
	}
	public void setResumeEduBackground(String resumeEduBackground) {
		this.resumeEduBackground = resumeEduBackground;
	}
	public String getResumeStatus() {
		return resumeStatus;
	}
	public void setResumeStatus(String resumeStatus) {
		this.resumeStatus = resumeStatus;
	}
	//前端到后台（接收表单数据）
	public static void dto2Entity(ResumeDTO dto ,Resume entity) {
		//类型转换
		int i=Integer.parseInt(dto.getResumeWorkYear1());
		entity.setResumeWorkYear(i);
		BeanUtils.copyProperties(dto,entity);
	}
	//后台到前端（返回JSON数据）
	public  static void entity2Dto(Resume entity ,ResumeDTO dto) {
		//类型转换
		int i=entity.getResumeWorkYear();
		String s=Integer.toString(i);
		dto.setResumeWorkYear1(s);
		BeanUtils.copyProperties(entity,dto);
	}
}