package com.hrs.zhanshiyang.salary.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class SalaryQueryDTO {
	private String employeeId;//员工工号ID
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date salaryTimeStart;//搜索操作时间的左边界
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date salaryTimeEnd;//搜索操作时间的右边界
	private BigDecimal salaryRealFrom;//实发工资
	private BigDecimal salaryRealTo;//实发工资
	private Boolean salaryStatus;//发放状态（默认值为false，评估完成为true）
	
	public String getEmployeeId() {
		return employeeId;
	}
	public Boolean getSalaryStatus() {
		return salaryStatus;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getSalaryTimeStart() {
		return salaryTimeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getSalaryTimeEnd() {
		return salaryTimeEnd;
	}	
	public BigDecimal getSalaryRealFrom() {
		return salaryRealFrom;
	}
	public BigDecimal getSalaryRealTo() {
		return salaryRealTo;
	}
	
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setSalaryStatus(Boolean salaryStatus) {
		this.salaryStatus = salaryStatus;
	}
	public void setSalaryTimeStart(Date salaryTimeStart) {
		this.salaryTimeStart = salaryTimeStart;
	}
	public void setSalaryTimeEnd(Date salaryTimeEnd) {
		this.salaryTimeEnd = salaryTimeEnd;
	}	
	public void setSalaryRealFrom(BigDecimal salaryRealFrom) {
		this.salaryRealFrom = salaryRealFrom;
	}
	public void setSalaryRealTo(BigDecimal salaryRealTo) {
		this.salaryRealTo = salaryRealTo;
	}
	
	@SuppressWarnings({ "serial"})
	public static Specification<Salary> getWhereClause(final SalaryQueryDTO salaryQueryDTO) {
		return new Specification<Salary>() {
			@Override
			public Predicate toPredicate(Root<Salary> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
			
				List<Predicate> predicate = new ArrayList<>();
				
				if (StringUtils.isNotBlank(salaryQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + salaryQueryDTO.getEmployeeId() + "%"));
				}
				if (null!=salaryQueryDTO.getSalaryTimeStart()) {
					predicate.add(criteriaBuilder.equal(root.get("salaryYM").as(Date.class),
							salaryQueryDTO.getSalaryTimeStart()));
				}
				if (null!=salaryQueryDTO.getSalaryTimeEnd()) {
					predicate.add(criteriaBuilder.equal(root.get("salaryYM").as(Date.class),
							salaryQueryDTO.getSalaryTimeEnd()));
				}
				if (null!=salaryQueryDTO.getSalaryRealFrom()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("salaryReal").as(BigDecimal.class),
							salaryQueryDTO.getSalaryRealFrom()));
				}
				if (null!=salaryQueryDTO.getSalaryRealTo()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("salaryReal").as(BigDecimal.class),
							salaryQueryDTO.getSalaryRealTo()));
				}
				if (null!=salaryQueryDTO.getSalaryStatus()) {
					predicate.add(criteriaBuilder.equal(root.get("salaryStatus").as(Boolean.class),
							salaryQueryDTO.getSalaryStatus()));
				}
				
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}
