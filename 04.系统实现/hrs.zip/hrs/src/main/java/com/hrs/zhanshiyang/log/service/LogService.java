package com.hrs.zhanshiyang.log.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.zhanshiyang.log.dao.LogDao;
import com.hrs.zhanshiyang.log.domain.Log;
import com.hrs.zhanshiyang.log.domain.LogDTO;
import com.hrs.zhanshiyang.log.service.ILogService;

@Service
@Transactional
public class LogService implements ILogService {
	@Autowired
	private LogDao logDao;
	
	@Transactional
	public void save(LogDTO dto) {
		Log entity = new Log();
		LogDTO.dto2Entity(dto, entity);
		logDao.save(entity);
	}
	
	@Transactional
	public void saveByEntity(Log log) {
		logDao.save(log);
	}
	
	@Transactional
	public LogDTO findById(Long id) {
		Log entity = logDao.findById(id).get();
		LogDTO dto = new LogDTO();
		LogDTO.entity2Dto(entity, dto);
		return dto;
	}
	
	
	public void deleteById(Long id) {
		logDao.deleteById(id);
	}
	
	public void deleteAll(List<LogDTO> dtoLists) {
		List<Log> entities = new ArrayList<Log>();
		
		for (LogDTO dto : dtoLists) {
			Log entity = new Log();
			LogDTO.dto2Entity(dto, entity);
			entities.add(entity);
		}
		logDao.deleteAll(entities);
	}
	
	public Page<LogDTO> findAll(Specification<Log> spec, Pageable pageable) {
		Page<Log> entities = logDao.findAll(spec,pageable);
		
		List<LogDTO> dtoLists = new ArrayList<LogDTO>();
		for (Log entity : entities) {
			LogDTO dto = new LogDTO();
			LogDTO.entity2Dto(entity, dto);
			dtoLists.add(dto);
		}
		return new PageImpl<LogDTO>(dtoLists, pageable, entities.getTotalElements());
	}
	
	public Log Login(String employeeId,String logPassword) {
		return logDao.Login(employeeId, logPassword);
	}
	
	public Log findByEmployeeId(String employeeId) {
		return logDao.findByEmployeeId(employeeId);
	}
	
	public void updatePassword(String logPassword,String employeeId,String oldPassword) {
		logDao.updatePassword(logPassword, employeeId, oldPassword);
	}
}