package com.hrs.youzhenjie.contract.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.youzhenjie.contract.dao.IContractDao;
import com.hrs.youzhenjie.contract.domain.Contract;
import com.hrs.youzhenjie.contract.domain.ContractAndEmployeeDTO;
import com.hrs.youzhenjie.employee.dao.IEmployeeDao;
import com.hrs.youzhenjie.employee.domain.Employee;

@Service
@Transactional
public class ContractService implements IContractService {

	@Autowired 
	private IContractDao contractDao;
	
	@Autowired
	private IEmployeeDao employeeDao;
	
	@Override
	public void saveOrUpdate(ContractAndEmployeeDTO dto) {
		Contract contract=new Contract();
		System.out.println(dto.getContractSalary());
		ContractAndEmployeeDTO.dto2EntityCon(dto, contract);
		System.out.println("+++++"+contract.getEmployee());
		contract.setEmployee(dto.getEmp());
		 contractDao.save(contract);
	}
	
	
	@Override
	public void save(Contract contract) {
		// TODO Auto-generated method stub
		 contractDao.save(contract);
	}
	
	@Override
	public ContractAndEmployeeDTO searchById(Long id) {
		// TODO Auto-generated method stub
		Contract contract=contractDao.findById(id).get();
		ContractAndEmployeeDTO dto=new ContractAndEmployeeDTO();
		ContractAndEmployeeDTO.entityCon2Dto(contract, dto);
		return dto;
	}

	@Override
	public List<ContractAndEmployeeDTO> searchAll() {
		//得到两个表的数据
		List<Contract> contracts=(List<Contract>) contractDao.findAll();
		
		List<ContractAndEmployeeDTO> dtoList=new ArrayList<ContractAndEmployeeDTO>();
		for (Contract contract : contracts) {
			ContractAndEmployeeDTO dto=new ContractAndEmployeeDTO();
			ContractAndEmployeeDTO.entityCon2Dto(contract, dto);
			dtoList.add(dto);
		}
		
		
		
		return dtoList;
	}

	@Override
	public Page<ContractAndEmployeeDTO> searchAllByPage(Specification<Contract> sepc, Pageable pageable) {
		Page<Contract> contractLists=contractDao.findAll(sepc, pageable);
		
		
		List<ContractAndEmployeeDTO> dtoList=new ArrayList<ContractAndEmployeeDTO>();
		for (Contract contract : contractLists) {
			ContractAndEmployeeDTO dto=new ContractAndEmployeeDTO();
			ContractAndEmployeeDTO.entityCon2Dto(contract, dto);
			Employee emp = contract.getEmployee();
			if(emp!=null){
				dto.setEmployeeName(emp.getEmployeeName());	
				dto.setReferenceId(emp.getId());
				dto.setEmployeeSex(emp.getEmployeeSex());
				dto.setEmployeeDepartment(emp.getEmployeeDepartment());
				dto.setEmployeePosition(emp.getEmployeePosition());
				dto.setEmployeeTel(emp.getEmployeeTel());
				dto.setEmployeeEntryTime(emp.getEmployeeEntryTime());
				dto.setEmployeeLeaveTime(emp.getEmployeeLeaveTime());
				
			}
			dtoList.add(dto);
		}
		return new PageImpl<ContractAndEmployeeDTO>(dtoList, pageable, contractLists.getTotalElements());
	}

	

	@Override
	public void deleteById(Long id) {
		Contract contract=contractDao.findById(id).get();
		if (contract!= null) {
			//移除关系 referenceID为空 合同grid中不会显示出来
			contract.setEmployee(null);
			contractDao.save(contract);
			//删除 保留，如果需要就保留，不需要就注释
			contractDao.deleteById(id);
		}
		
	}

	@Override
	public void deleteAll(Long[] ids) {
		 List<Long> empIdLists = new ArrayList<Long>();
		 for (int i = 0; i < ids.length; i++) {
		 empIdLists.add(ids[i]);
		 }
		
		 List<Contract> contracts = (List<Contract>) contractDao.findAllById(empIdLists);
		 if (contracts != null) {
			 contractDao.deleteAll(contracts);
		 }

	}

	@Override
	public long count() {
		return contractDao.count();
	}

	@Override
	public boolean existsById(Long id) {
		// TODO Auto-generated method stub
		return contractDao.existsById(id);
	}


	@Override
	public Contract findByEmployeeId(String name) {
		// TODO Auto-generated method stub
		System.out.println("Service"+name);
		return contractDao.findByEmployeeId(name);
	}




}
