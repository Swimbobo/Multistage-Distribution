package com.hrs.chenliangbo.file.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.common.beans.SessionUtil;

public class FileQueryDTO {
	private String employeeId;			//工号
	private String fileContent;			//工作内容
	private String fileResults;			//业绩
	private String fileSchool;			//学校
	private String fileMajor;			//专业
	private String fileEduBackground;	//学历背景
	
	public String getEmployeeId() {
		return employeeId;
	}
	public String getFileContent() {
		return fileContent;
	}
	public String getFileResults() {
		return fileResults;
	}
	public String getFileSchool() {
		return fileSchool;
	}
	public String getFileMajor() {
		return fileMajor;
	}
	public String getFileEduBackground() {
		return fileEduBackground;
	}
	
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}
	public void setFileResults(String fileResults) {
		this.fileResults = fileResults;
	}
	public void setFileSchool(String fileSchool) {
		this.fileSchool = fileSchool;
	}
	public void setFileMajor(String fileMajor) {
		this.fileMajor = fileMajor;
	}
	public void setFileEduBackground(String fileEduBackground) {
		this.fileEduBackground = fileEduBackground;
	}
	
	/*  查询条件拼接   */
	@SuppressWarnings({ "serial"})
	public static Specification<File> getWhereClause(final FileQueryDTO fileQueryDTO) {
		return new Specification<File>() {
			@Override
			public Predicate toPredicate(Root<File> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
			
				List<Predicate> predicate = new ArrayList<>();//条件数组
				
				/*  查询条件   */
				if (StringUtils.isNotBlank(fileQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + fileQueryDTO.getEmployeeId() + "%"));
				}
				if (StringUtils.isNotBlank(fileQueryDTO.getFileSchool())) {
					predicate.add(criteriaBuilder.like(root.get("fileSchool").as(String.class),
							"%" + fileQueryDTO.getFileSchool() + "%"));
				}
				/*拼接查询条件*/
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
	@SuppressWarnings({ "serial"})
	public static Specification<File> getWhereByEmployeeId(final FileQueryDTO fileQueryDTO) {
		return new Specification<File>() {
			@Override
			public Predicate toPredicate(Root<File> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
			
				List<Predicate> predicate = new ArrayList<>();//条件数组
				
				/*  查询条件   */
				HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
				HttpSession  session=request.getSession();
				String emp=SessionUtil.getEmployeeId(session);
				
				predicate.add(criteriaBuilder.equal(root.get("employeeId").as(String.class),emp));
				
				if (StringUtils.isNotBlank(fileQueryDTO.getFileSchool())) {
					predicate.add(criteriaBuilder.like(root.get("fileSchool").as(String.class),
							"%" + fileQueryDTO.getFileSchool() + "%"));
				}
				/*拼接查询条件*/
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}