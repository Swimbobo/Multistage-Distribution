package com.hrs.huangwenkang.entry.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;

public class EntryQueryDTO{
	private String entryName;					//姓名
	private String entrybranch;					//部门
	private String entryposition;				//职位
	@DateTimeFormat(pattern="yyyy/MM/dd")		//预计入职开始时间
	private Date entryTimeStart;
	@DateTimeFormat(pattern="yyyy/MM/dd")		//预计入职结束时间
	private Date entryTimeEnd;
	private String entryStatus;					//待入职状态

	public String getEntryName() {
		return entryName;
	}
	public void setEntryName(String entryName) {
		this.entryName = entryName;
	}
	public String getEntrybranch() {
		return entrybranch;
	}
	public void setEntrybranch(String entrybranch) {
		this.entrybranch = entrybranch;
	}
	public String getEntryposition() {
		return entryposition;
	}
	public void setEntryposition(String entryposition) {
		this.entryposition = entryposition;
	}
	public String getEntryStatus() {
		return entryStatus;
	}
	public void setEntryStatus(String entryStatus) {
		this.entryStatus = entryStatus;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getEntryTimeStart() {
		return entryTimeStart;
	}
	public void setEntryTimeStart(Date entryTimeStart) {
		this.entryTimeStart = entryTimeStart;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getEntryTimeEnd() {
		return entryTimeEnd;
	}
	public void setEntryTimeEnd(Date entryTimeEnd) {
		this.entryTimeEnd = entryTimeEnd;
	}
	@SuppressWarnings({ "serial"})
	public static Specification<Entry> getWhereClause(final EntryQueryDTO entryQueryDTO) {
		return new Specification<Entry>() {
			@Override
			public Predicate toPredicate(Root<Entry> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();
				if (StringUtils.isNotBlank(entryQueryDTO.getEntryName())) {
					predicate.add(criteriaBuilder.like(root.get("entryName").as(String.class),
							"%"+entryQueryDTO.getEntryName()+"%"));
				}
				if (StringUtils.isNotBlank(entryQueryDTO.getEntrybranch())) {
					predicate.add(criteriaBuilder.like(root.get("entrybranch").as(String.class),
							"%"+entryQueryDTO.getEntrybranch()+"%"));
				}
				if (StringUtils.isNotBlank(entryQueryDTO.getEntryposition())) {
					predicate.add(criteriaBuilder.like(root.get("entryposition").as(String.class),
							"%"+entryQueryDTO.getEntryposition()+"%"));
				}
				if (null!=entryQueryDTO.getEntryTimeStart()){
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("entryExpectedEntryDate").as(Date.class),
							entryQueryDTO.getEntryTimeStart()));
				}
				if (null!=entryQueryDTO.getEntryTimeEnd()){
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("entryExpectedEntryDate").as(Date.class),
							entryQueryDTO.getEntryTimeEnd()));
				}
				if (StringUtils.isNotBlank(entryQueryDTO.getEntryStatus())) {
					predicate.add(criteriaBuilder.like(root.get("entryStatus").as(String.class),
							"%"+entryQueryDTO.getEntryStatus()+"%"));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}
}