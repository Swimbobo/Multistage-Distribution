package com.hrs.zhanshiyang.welfare.domain;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;

public class WelfareDTO {
	private Long id;
	private String employeeId;//员工工号ID
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date welfareYM;//福利时间（年月）
	private String welfareStyle;//福利简述
	private BigDecimal welfareSum;//福利金额
	private String welfareAddName;//录入管理员名字
	private String welfareRemark;//备注
	
	public Long getId() {
		return id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getWelfareYM() {
		return welfareYM;
	}
	public String getWelfareStyle() {
		return welfareStyle;
	}
	public BigDecimal getWelfareSum() {
		return welfareSum;
	}
	public String getWelfareAddName() {
		return welfareAddName;
	}
	public String getWelfareRemark() {
		return welfareRemark;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setWelfareYM(Date welfareYM) {
		this.welfareYM = welfareYM;
	}
	public void setWelfareStyle(String welfareStyle) {
		this.welfareStyle = welfareStyle;
	}
	public void setWelfareSum(BigDecimal welfareSum) {
		this.welfareSum = welfareSum;
	}
	public void setWelfareAddName(String welfareAddName) {
		this.welfareAddName = welfareAddName;
	}
	public void setWelfareRemark(String welfareRemark) {
		this.welfareRemark = welfareRemark;
	}
	
	//前端到后台（接收表单数据）:save 和 update	如何维护关联关系？
	public  static void dto2Entity(WelfareDTO dto ,Welfare entity) {
		BeanUtils.copyProperties(dto, entity);	
	}
	//后台到前端（返回JSON数据）：find	显示什么数据？
	public  static void entity2Dto(Welfare entity ,WelfareDTO dto) {
		BeanUtils.copyProperties(entity , dto);
	}
	
}
