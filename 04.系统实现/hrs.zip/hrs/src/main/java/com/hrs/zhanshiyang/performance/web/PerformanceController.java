package com.hrs.zhanshiyang.performance.web;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.zhanshiyang.performance.domain.PerformanceDTO;
import com.hrs.zhanshiyang.performance.domain.PerformanceQueryDTO;
import com.hrs.zhanshiyang.performance.service.IPerformanceService;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@RestController
@RequestMapping("/performance")
public class PerformanceController {
	@Autowired
	private IPerformanceService performanceService;
	
	@Autowired
	private IRecordService recordService;
	
//	添加
	@PostMapping
	public ExtAjaxResponse save(@RequestBody PerformanceDTO dto) 
	{
		try {
			dto.setPerformanceStatus(true);
			performanceService.save(dto);
			writeLog("评估/修改");
			return new ExtAjaxResponse(true,"保存成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"保存失败！");
		}
	}
	
//	根据所需字段搜索分页显示，Postman用Params测试
	@GetMapping
	public Page<PerformanceDTO> getPage(PerformanceQueryDTO performanceQueryDTO , ExtjsPageRequest pageRequest) 
	{
		return performanceService.findAll(PerformanceQueryDTO.getWhereClause(performanceQueryDTO), pageRequest.getPageable());
	}
	
//	日志方法
	public void writeLog(String operation){
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession  session=request.getSession();
		String employeeId=SessionUtil.getEmployeeId(session);
		
		RecordDTO recordDTO = new RecordDTO();
		recordDTO.setEmployeeId(employeeId);
		recordDTO.setRecordContent(operation+" 绩效信息成功");
		recordDTO.setRecordTime(new Date());
		recordService.save(recordDTO);

	}
}
