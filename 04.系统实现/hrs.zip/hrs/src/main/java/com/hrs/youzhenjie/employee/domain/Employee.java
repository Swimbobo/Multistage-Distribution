package com.hrs.youzhenjie.employee.domain;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.lang.NonNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.BaseDomain;
import com.hrs.youzhenjie.contract.domain.Contract;

import jdk.nashorn.internal.ir.annotations.Reference;

@Entity
@Table(name = "t_employee")
public class Employee extends BaseDomain<Long> {

	private String employeeId;// 工号
	private String employeeName;// 姓名
	private String employeeSex;// 性别
	private String employeeDepartment;// 部门
	private String employeePosition;// 职位
	private String employeeTel;// 电话
	private String employeeState;// 在职状态
	private Date employeeEntryTime;// 入职日期
	private Date employeeLeaveTime;// 离职日期

	//private Contract contract;
	
//	@OneToOne(cascade=CascadeType.ALL)
	//@JoinColumn(name="referenceId")
//
	//@OneToOne(fetch=FetchType.EAGER,mappedBy="employee")
//	public Contract getContract() {
//		return contract;
//	}

	@Column(unique = true, nullable = false)
	@NotNull
	public String getEmployeeId() {
		return employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public String getEmployeeSex() {
		return employeeSex;
	}

	public String getEmployeeDepartment() {
		return employeeDepartment;
	}

	public String getEmployeePosition() {
		return employeePosition;
	}

	public String getEmployeeTel() {
		return employeeTel;
	}

	@Column(length = 1)
	public String getEmployeeState() {
		return employeeState;
	}

	@Temporal(TemporalType.DATE)
//	@DateTimeFormat(pattern="yyyy/MM/dd")
	@JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
	public Date getEmployeeEntryTime() {
		return employeeEntryTime;
	}

	@Temporal(TemporalType.DATE)
//	@DateTimeFormat(pattern="yyyy/MM/dd")
	@JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
	public Date getEmployeeLeaveTime() {
		return employeeLeaveTime;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public void setEmployeeSex(String employeeSex) {
		this.employeeSex = employeeSex;
	}

	public void setEmployeeDepartment(String employeeDepartment) {
		this.employeeDepartment = employeeDepartment;
	}

	public void setEmployeePosition(String employeePosition) {
		this.employeePosition = employeePosition;
	}

	public void setEmployeeTel(String employeeTel) {
		this.employeeTel = employeeTel;
	}

	public void setEmployeeState(String employeeState) {
		this.employeeState = employeeState;
	}

	public void setEmployeeEntryTime(Date employeeEntryTime) {
		this.employeeEntryTime = employeeEntryTime;
	}

	public void setEmployeeLeaveTime(Date employeeLeaveTime) {
		this.employeeLeaveTime = employeeLeaveTime;
	}

//	public void setContract(Contract contract) {
//		this.contract = contract;
//	}

}
