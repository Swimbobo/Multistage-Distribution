package com.hrs.zhanshiyang.performance.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.hrs.common.BaseDomain;
import com.hrs.zhanshiyang.template.domain.Template;

@Entity
@Table(name="t_performance")
public class Performance extends BaseDomain<Long> {
	private String employeeId;//员工工号ID
	private Long performanceFraction;//员工的绩效分数
	private String performanceContent;//经理对属下员工的评估内容描述
	private Boolean performanceStatus;//评估状态（默认值为false，评估完成为true）
	private String performanceAssessName;//评估人的名字（自动获取）
	private String performanceStaffName;//被评估人的名字（模板发布时自动获取）
	private Template template;//外键，关联评估模板的id（自动获取）
	
	public Performance() {
		this.performanceStatus = false;
	}
	
//	getters
	@Column(nullable= false)
	public String getEmployeeId() {
		return employeeId;
	}
	public Long getPerformanceFraction() {
		return performanceFraction;
	}
	public String getPerformanceContent() {
		return performanceContent;
	}
	@Column(nullable= false,columnDefinition="bit(1) default 0")
	public Boolean getPerformanceStatus() {
		return performanceStatus;
	}
	public String getPerformanceAssessName() {
		return performanceAssessName;
	}
	@Column(nullable= false)
	public String getPerformanceStaffName() {
		return performanceStaffName;
	}
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="templateId", referencedColumnName = "id")
	public Template getTemplate() {
		return template;
	}
	
//	setters
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setPerformanceFraction(Long performanceFraction) {
		this.performanceFraction = performanceFraction;
	}
	public void setPerformanceContent(String performanceContent) {
		this.performanceContent = performanceContent;
	}
	public void setPerformanceStatus(Boolean performanceStatus) {
		this.performanceStatus = performanceStatus;
	}
	public void setPerformanceAssessName(String performanceAssessName) {
		this.performanceAssessName = performanceAssessName;
	}
	public void setPerformanceStaffName(String performanceStaffName) {
		this.performanceStaffName = performanceStaffName;
	}
	public void setTemplate(Template template) {
		this.template = template;
	}

	@Override
	public String toString() {
		return "Performance [employeeId=" + employeeId + ", performanceFraction=" + performanceFraction
				+ ", performanceContent=" + performanceContent + ", performanceStatus=" + performanceStatus
				+ ", performanceAssessName=" + performanceAssessName + ", performanceStaffName=" + performanceStaffName
				+ ", template=" + template + "]";
	}

}
