package com.hrs.lizhuhao.branch.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.lizhuhao.branch.domain.Branch;
import com.hrs.lizhuhao.branch.domain.BranchDTO;

public interface IBranchService {
	public void save(BranchDTO dto);		//增加对象
	public void deleteById(Long id);		//通过id删除对象
	public void deleteAll(Long[] ids);		//批量删除
	public BranchDTO findById(Long id);		//通过id查找对象
	public boolean existsById(Long id);		//通过id判断是否存在对象
	public long count();					//统计表中数据总数
	public List<BranchDTO> findAll();		//查看全部
	public Page<BranchDTO> findAll(Specification<Branch> spec,Pageable pageable);
}