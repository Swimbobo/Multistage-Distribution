package com.hrs.youzhenjie.contract.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;


public class ContractQueryDTO {
	// 查询的参数
	private String employeeId;// 工号
	
	private String contractType;// 合同类型
	private String contractState;// 合同状态
	private String contractFile;// 合同文档
	private String contractProperties;// 合同属性
	
	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date contractStartTime;// 合同开始时间
	
	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date contractEndTime;// 合同结束时间

	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	private Date contractProbationDate;// 试用期结束时间
	

	public String getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}


	public String getContractType() {
		return contractType;
	}


	public void setContractType(String contractType) {
		this.contractType = contractType;
	}


	public String getContractState() {
		return contractState;
	}


	public void setContractState(String contractState) {
		this.contractState = contractState;
	}


	public String getContractFile() {
		return contractFile;
	}


	public void setContractFile(String contractFile) {
		this.contractFile = contractFile;
	}


	public String getContractProperties() {
		return contractProperties;
	}


	public void setContractProperties(String contractProperties) {
		this.contractProperties = contractProperties;
	}


	public Date getContractStartTime() {
		return contractStartTime;
	}


	public void setContractStartTime(Date contractStartTime) {
		this.contractStartTime = contractStartTime;
	}


	public Date getContractEndTime() {
		return contractEndTime;
	}


	public void setContractEndTime(Date contractEndTime) {
		this.contractEndTime = contractEndTime;
	}


	public Date getContractProbationDate() {
		return contractProbationDate;
	}


	public void setContractProbationDate(Date contractProbationDate) {
		this.contractProbationDate = contractProbationDate;
	}

// 动态查询 
	@SuppressWarnings({ "serial"})
	public static Specification<Contract> getWhereClause(final ContractQueryDTO contractQueryDTO) {
		return new Specification<Contract>() {
			@Override
			public Predicate toPredicate(Root<Contract> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();
				//employeeId
				if (StringUtils.isNotBlank(contractQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + contractQueryDTO.getEmployeeId() + "%"));
				}
				//contractType
				if (null != contractQueryDTO.getContractType()) {
					predicate.add(criteriaBuilder.like(root.get("contractType").as(String.class),
							"%" + contractQueryDTO.getContractType() + "%"));
				}
				//contractState
				if (null != contractQueryDTO.getContractState()) {
					predicate.add(criteriaBuilder.like(root.get("contractState").as(String.class),
							"%" + contractQueryDTO.getContractState() + "%"));
				}
				//contractFile
				if (null != contractQueryDTO.getContractFile()) {
					predicate.add(criteriaBuilder.like(root.get("contractFile").as(String.class),
							"%" + contractQueryDTO.getContractFile() + "%"));
				}
				//contractProperties
				if (null != contractQueryDTO.getContractProperties()) {
					predicate.add(criteriaBuilder.like(root.get("contractProperties").as(String.class),
							"%" + contractQueryDTO.getContractProperties() + "%"));
				}
				//contractStartTime
				if (null!=contractQueryDTO.getContractStartTime()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("contractStartTime").as(Date.class),
							contractQueryDTO.getContractStartTime()));
				}
				//contractEndTime
				if (null!=contractQueryDTO.getContractEndTime()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("contractEndTime").as(Date.class),
							contractQueryDTO.getContractEndTime()));
				}
				//contractProbationDate
				if (null!=contractQueryDTO.getContractProbationDate()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("contractProbationDate").as(Date.class),
							contractQueryDTO.getContractProbationDate()));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
