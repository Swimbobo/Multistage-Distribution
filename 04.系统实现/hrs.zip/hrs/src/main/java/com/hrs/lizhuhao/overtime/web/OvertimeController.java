package com.hrs.lizhuhao.overtime.web;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.common.beans.BeanUtils;
import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.lizhuhao.overtime.domain.Overtime;
import com.hrs.lizhuhao.overtime.domain.OvertimeDTO;
import com.hrs.lizhuhao.overtime.domain.OvertimeQueryDTO;
import com.hrs.lizhuhao.overtime.service.IOvertimeService;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@RestController
@RequestMapping("/overtime")
public class OvertimeController {
	@Autowired
	private IOvertimeService overtimeService;
	@Autowired
	private IRecordService recordService;
	
	//显示申请中数据
	@GetMapping
	public @ResponseBody Page<OvertimeDTO> getPage(OvertimeQueryDTO overtimeQueryDTO , ExtjsPageRequest pageRequest) {
		return overtimeService.findAll(OvertimeQueryDTO.getWhereClause(overtimeQueryDTO), pageRequest.getPageable());
	}
	//显示某条数据（按EmployeeId）
	@GetMapping("/getOne")
	public @ResponseBody Page<OvertimeDTO> getPageByEmployeeId(OvertimeQueryDTO overtimeQueryDTO , ExtjsPageRequest pageRequest) {
		return overtimeService.findAll(OvertimeQueryDTO.getWhereByEmployeeId(overtimeQueryDTO), pageRequest.getPageable());
	}
	//显示某条数据(按id)
	@GetMapping("{id}")
	public OvertimeDTO getOne(@PathVariable("id") Long id) {
		return overtimeService.findById(id);
	}
	//删除某条数据
	@PostMapping("/getOne/detete")
	public ExtAjaxResponse delete(@RequestParam(name="id") String id) {
		Long i=Long.valueOf(id);
		try {
			if(i!=null) {
				overtimeService.deleteById(i);
				writeLog("删除");
			}
			return new ExtAjaxResponse(true,"删除成功！");
		}catch (Exception e) {
			return new ExtAjaxResponse(true,"删除失败！");
			}
	}
	//修改数据
	@PutMapping(value="{id}",consumes=MediaType.APPLICATION_JSON_VALUE)
	public ExtAjaxResponse update(@PathVariable("id") Long myId,@RequestBody Overtime dto) {
		try {
			OvertimeDTO entity = overtimeService.findById(myId);
			if(entity!=null) {
				BeanUtils.copyProperties(dto, entity);//使用自定义的BeanUtils
				overtimeService.save(entity);
				writeLog("修改");
			}
			return new ExtAjaxResponse(true,"更新成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"更新失败！");
		}
	}
	//增加数据
	@PostMapping(consumes=MediaType.APPLICATION_JSON_VALUE)
	public ExtAjaxResponse save(@RequestBody OvertimeDTO overtime) {
		try {
			overtimeService.save(overtime);
			writeLog("添加");
			return new ExtAjaxResponse(true,"保存成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"保存失败！");
		}
	}
	//日志操作
	public void writeLog(String operation){
		HttpServletRequest request=((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session=request.getSession();
		String employeeId=SessionUtil.getEmployeeId(session);
		RecordDTO recordDTO=new RecordDTO();
		recordDTO.setEmployeeId(employeeId);
		recordDTO.setRecordContent(operation+" 加班信息成功");
		recordDTO.setRecordTime(new Date());
		recordService.save(recordDTO);
	}
}