package com.hrs.youzhenjie.employee.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.youzhenjie.employee.domain.Employee;

@Repository
public interface IEmployeeDao extends PagingAndSortingRepository<Employee, Long>, JpaSpecificationExecutor<Employee> {

	//JPA 高级查询
	public Employee findByEmployeeId(String name);
	
	public Employee findByEmployeeName(String employeeName);
}
