package com.hrs.huangwenkang.recruit.web;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.common.beans.BeanUtils;
import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.huangwenkang.recruit.domain.Recruit;
import com.hrs.huangwenkang.recruit.domain.RecruitDTO;
import com.hrs.huangwenkang.recruit.domain.RecruitQueryDTO;
import com.hrs.huangwenkang.recruit.service.IRecruitService;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@RestController
@RequestMapping("/recruit")
public class RecruitController {
	@Autowired
	private IRecruitService recruitService;
	@Autowired
	private IRecordService recordService;
		
	//显示全部数据
	@GetMapping
	public @ResponseBody Page<RecruitDTO> getPage(RecruitQueryDTO recruitQueryDTO , ExtjsPageRequest pageRequest){
		return recruitService.findAll(RecruitQueryDTO.getWhereClause(recruitQueryDTO), pageRequest.getPageable());
	}
	//显示某条数据
	@GetMapping(value="{id}")
	public RecruitDTO getOne(@PathVariable("id") Long id){
		return recruitService.findById(id);
	}
	//删除某条数据
	@DeleteMapping(value="{id}")
	public ExtAjaxResponse delete(@PathVariable("id") Long id){
		try{
			if(id!=null){
				recruitService.deleteById(id);
				writeLog("删除");
			}
			return new ExtAjaxResponse(true,"删除成功！");
		}catch(Exception e){
			return new ExtAjaxResponse(true,"删除失败！");
			}
	}
	//批量删除
	@PostMapping("/deletes")
	public ExtAjaxResponse deleteRows(@RequestParam(name="ids") Long[] ids){
		try{
			if(ids!=null){
				recruitService.deleteAll(ids);
				writeLog("批量删除");
			}
			return new ExtAjaxResponse(true,"批量删除成功！");
		}catch(Exception e){
			return new ExtAjaxResponse(true,"批量删除失败！");
			}
	}
	//增加数据
	@PostMapping()
	public ExtAjaxResponse save(@RequestBody RecruitDTO recruit){
		try{
			recruitService.save(recruit);
			writeLog("添加");
			return new ExtAjaxResponse(true,"保存成功！");
		}catch(Exception e){
			return new ExtAjaxResponse(true,"保存失败！");
			}
	}
	//修改数据
	@PutMapping(value="{id}",consumes=MediaType.APPLICATION_JSON_VALUE)
	public ExtAjaxResponse update(@PathVariable("id") Long myId,@RequestBody Recruit dto){
		try{
			RecruitDTO recruit=recruitService.findById(myId);
			if(recruit!=null){
				BeanUtils.copyProperties(dto, recruit);
				recruitService.save(recruit);
				writeLog("修改");
			}
			return new ExtAjaxResponse(true,"更新成功！");
		}catch(Exception e){
			return new ExtAjaxResponse(true,"更新失败！");
			}
	}
	//日志操作
	public void writeLog(String operation){
		HttpServletRequest request=((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session=request.getSession();
		String employeeId=SessionUtil.getEmployeeId(session);
		RecordDTO recordDTO=new RecordDTO();
		recordDTO.setEmployeeId(employeeId);
		recordDTO.setRecordContent(operation+" 招聘信息成功");
		recordDTO.setRecordTime(new Date());
		recordService.save(recordDTO);
	}
}