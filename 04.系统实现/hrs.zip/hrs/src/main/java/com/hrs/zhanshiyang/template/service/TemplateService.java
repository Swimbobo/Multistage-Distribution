package com.hrs.zhanshiyang.template.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hrs.youzhenjie.employee.dao.IEmployeeDao;
import com.hrs.youzhenjie.employee.domain.Employee;
import com.hrs.zhanshiyang.performance.dao.PerformanceDao;
import com.hrs.zhanshiyang.performance.domain.Performance;
import com.hrs.zhanshiyang.template.dao.TemplateDao;
import com.hrs.zhanshiyang.template.domain.Template;
import com.hrs.zhanshiyang.template.domain.TemplateDTO;
import com.hrs.zhanshiyang.template.service.ITemplateService;

@Service
@Transactional
public class TemplateService implements ITemplateService 
{
	@Autowired
	private TemplateDao templateDao;
	
	@Autowired
	private IEmployeeDao employeeDao;
	
	@Autowired
	private PerformanceDao performanceDao;

	@Transactional
	public void save(TemplateDTO dto) {
		Template entity = new Template();
		TemplateDTO.dto2Entity(dto, entity);
		templateDao.save(entity);
	}

	@Transactional
	public TemplateDTO findById(Long id) {
		Template entity = templateDao.findById(id).get();
		TemplateDTO dto = new TemplateDTO();
		TemplateDTO.entity2Dto(entity, dto);
		return dto;
	}

	public List<TemplateDTO> findAllById(List<Long> ids) {
		List<Template> entities = (List<Template>) templateDao.findAllById(ids);
		
		List<TemplateDTO> dtoLists = new ArrayList<TemplateDTO>();
		for (Template entity : entities) {
			TemplateDTO dto = new TemplateDTO();
			TemplateDTO.entity2Dto(entity, dto);
			dtoLists.add(dto);
		}
		return dtoLists;
	}

	public void deleteById(Long id) {
		templateDao.deleteById(id);
	}

	public void deleteAll(List<TemplateDTO> dtoLists) {
		List<Template> entities = new ArrayList<Template>();
		
		for (TemplateDTO dto : dtoLists) {
			Template entity = new Template();
			TemplateDTO.dto2Entity(dto, entity);
			entities.add(entity);
		}
		templateDao.deleteAll(entities);
	}

	@Transactional
	public void release(TemplateDTO dto) {
		Template template = templateDao.findById(dto.getId()).get();
		
		List<Employee> employeeLists = (List<Employee>) employeeDao.findAll();
		List<Performance> entities = new ArrayList<Performance>();

		for (Employee employee : employeeLists) {
			if(employee.getEmployeeState().equals("1")) {//在职员工生成绩效表
				Performance performance = new Performance();
				performance.setEmployeeId(employee.getEmployeeId());
				performance.setPerformanceStaffName(employee.getEmployeeName());
				performance.setTemplate(template);
				entities.add(performance);
			}
		}
		performanceDao.saveAll(entities);
		template.setTemplateStatus(true);
	}

	public Page<TemplateDTO> findAll(Specification<Template> spec, Pageable pageable) {
		Page<Template> entities = templateDao.findAll(spec,pageable);
		
		List<TemplateDTO> dtoLists = new ArrayList<TemplateDTO>();
		for (Template entity : entities) {
			TemplateDTO dto = new TemplateDTO();
			TemplateDTO.entity2Dto(entity, dto);
			dtoLists.add(dto);
		}
		return new PageImpl<TemplateDTO>(dtoLists, pageable, entities.getTotalElements());
	}

}
