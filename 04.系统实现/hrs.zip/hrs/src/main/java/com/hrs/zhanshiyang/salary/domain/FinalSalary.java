package com.hrs.zhanshiyang.salary.domain;

import java.math.BigDecimal;

public class FinalSalary {
	private String employeeId;			//员工工号
	private String salaryYM;			//计算薪资时间（年月)
	private int salaryAttendance;//出勤
	private int salaryPerleave;//事假（天）
	private int salarySicleave;//出差（天）
	private int salaryOvertime;//加班（时）
	private BigDecimal salaryBasic;//基本工资
	private BigDecimal bonusSum;//奖金金额
	private BigDecimal welfareSum;//福利金额
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getSalaryYM() {
		return salaryYM;
	}
	public void setSalaryYM(String salaryYM) {
		this.salaryYM = salaryYM;
	}
	public int getSalaryAttendance() {
		return salaryAttendance;
	}
	public void setSalaryAttendance(int salaryAttendance) {
		this.salaryAttendance = salaryAttendance;
	}
	public int getSalaryPerleave() {
		return salaryPerleave;
	}
	public void setSalaryPerleave(int salaryPerleave) {
		this.salaryPerleave = salaryPerleave;
	}
	public int getSalarySicleave() {
		return salarySicleave;
	}
	public void setSalarySicleave(int salarySicleave) {
		this.salarySicleave = salarySicleave;
	}
	public int getSalaryOvertime() {
		return salaryOvertime;
	}
	public void setSalaryOvertime(int salaryOvertime) {
		this.salaryOvertime = salaryOvertime;
	}
	public BigDecimal getSalaryBasic() {
		return salaryBasic;
	}
	public void setSalaryBasic(BigDecimal salaryBasic) {
		this.salaryBasic = salaryBasic;
	}
	public BigDecimal getBonusSum() {
		return bonusSum;
	}
	public void setBonusSum(BigDecimal bonusSum) {
		this.bonusSum = bonusSum;
	}
	public BigDecimal getWelfareSum() {
		return welfareSum;
	}
	public void setWelfareSum(BigDecimal welfareSum) {
		this.welfareSum = welfareSum;
	}
}