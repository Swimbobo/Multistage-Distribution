package com.hrs.zhanshiyang.salary.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.BaseDomain;

@Entity
@Table(name="t_salary")
public class Salary extends BaseDomain<Long> {
	private String employeeId;//员工工号ID
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date salaryYM;//薪资时间（年月）
	private BigDecimal salaryAttendance;//出勤（天）
	private BigDecimal salaryAbsence;//缺勤（天）
	private BigDecimal salaryPerleave;//事假（天）
	private BigDecimal salarySicleave;//出差（天）
	private BigDecimal salaryOvertime;//加班（时）
	private BigDecimal salaryBasic;//基本工资
	private BigDecimal salaryAttsub;//考勤扣款
	private BigDecimal salaryInssub;//五险一金扣款
	private BigDecimal salaryBeftax;//税前工资（个人当月所有薪资收入，包括奖金）
	private BigDecimal salarySeltax;//个人所得税（计税工资：税前工资-五险一金）
	private BigDecimal salaryReal;//实发工资
	private Boolean salaryStatus;//发放状态（默认值为false，评估完成为true）
	private String salaryRemark;//备注
	
	public Salary() {
		this.salaryStatus = false;
	}
	
//	getters
	@Column(nullable=false)
	public String getEmployeeId() {
		return employeeId;
	}
	@Temporal(TemporalType.DATE)
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	@Column(nullable=false)
	public Date getSalaryYM() {
		return salaryYM;
	}
	@Column(nullable=false,scale=1)
	public BigDecimal getSalaryAttendance() {
		return salaryAttendance;
	}
	@Column(nullable=false,scale=1)
	public BigDecimal getSalaryAbsence() {
		return salaryAbsence;
	}
	@Column(nullable=false,scale=1)
	public BigDecimal getSalaryPerleave() {
		return salaryPerleave;
	}
	@Column(nullable=false,scale=1)
	public BigDecimal getSalarySicleave() {
		return salarySicleave;
	}
	@Column(nullable=false,scale=1)
	public BigDecimal getSalaryOvertime() {
		return salaryOvertime;
	}
	@Column(nullable=false,scale=2)
	public BigDecimal getSalaryBasic() {
		return salaryBasic;
	}
	@Column(nullable=false,scale=2)
	public BigDecimal getSalaryAttsub() {
		return salaryAttsub;
	}
	@Column(nullable=false,scale=2)
	public BigDecimal getSalaryInssub() {
		return salaryInssub;
	}
	@Column(nullable=false,scale=2)
	public BigDecimal getSalaryBeftax() {
		return salaryBeftax;
	}
	@Column(nullable=false,scale=2)
	public BigDecimal getSalarySeltax() {
		return salarySeltax;
	}
	@Column(nullable=false,scale=2)
	public BigDecimal getSalaryReal() {
		return salaryReal;
	}
	@Column(nullable=false,columnDefinition="bit(1) default 0")
	public Boolean getSalaryStatus() {
		return salaryStatus;
	}
	public String getSalaryRemark() {
		return salaryRemark;
	}
	
//	setters
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setSalaryYM(Date salaryYM) {
		this.salaryYM = salaryYM;
	}
	public void setSalaryAttendance(BigDecimal salaryAttendance) {
		this.salaryAttendance = salaryAttendance;
	}
	public void setSalaryAbsence(BigDecimal salaryAbsence) {
		this.salaryAbsence = salaryAbsence;
	}
	public void setSalaryPerleave(BigDecimal salaryPerleave) {
		this.salaryPerleave = salaryPerleave;
	}
	public void setSalarySicleave(BigDecimal salarySicleave) {
		this.salarySicleave = salarySicleave;
	}
	public void setSalaryOvertime(BigDecimal salaryOvertime) {
		this.salaryOvertime = salaryOvertime;
	}
	public void setSalaryBasic(BigDecimal salaryBasic) {
		this.salaryBasic = salaryBasic;
	}
	public void setSalaryAttsub(BigDecimal salaryAttsub) {
		this.salaryAttsub = salaryAttsub;
	}
	public void setSalaryInssub(BigDecimal salaryInssub) {
		this.salaryInssub = salaryInssub;
	}
	public void setSalaryBeftax(BigDecimal salaryBeftax) {
		this.salaryBeftax = salaryBeftax;
	}
	public void setSalarySeltax(BigDecimal salarySeltax) {
		this.salarySeltax = salarySeltax;
	}
	public void setSalaryReal(BigDecimal salaryReal) {
		this.salaryReal = salaryReal;
	}
	public void setSalaryStatus(Boolean salaryStatus) {
		this.salaryStatus = salaryStatus;
	}
	public void setSalaryRemark(String salaryRemark) {
		this.salaryRemark = salaryRemark;
	}
}
