package com.hrs.youzhenjie.contract.web;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.hrs.common.beans.BeanUtils;
import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.youzhenjie.contract.domain.Contract;
import com.hrs.youzhenjie.contract.domain.ContractAndEmployeeDTO;
import com.hrs.youzhenjie.contract.domain.ContractQueryDTO;
import com.hrs.youzhenjie.contract.service.IContractService;
import com.hrs.youzhenjie.employee.domain.Employee;
import com.hrs.youzhenjie.employee.service.IEmployeeService;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;

@RestController
@RequestMapping(value = "contract")
public class ContractController {

	@Autowired
	private IContractService contractService;

	@Autowired
	private IEmployeeService employeeService;
	
	@Autowired
	private IRecordService recordService;
	/*
	 * 查询所有
	 */
	@GetMapping
	public Page<ContractAndEmployeeDTO> findAll(ContractQueryDTO dto, ExtjsPageRequest pageRequest) {
		System.out.println("Contract FindALL");
		return contractService.searchAllByPage(dto.getWhereClause(dto), pageRequest.getPageable());
	}

	/*
	 * 查询单个
	 */
	@GetMapping(value = "{id}")
	public ContractAndEmployeeDTO findOne(@PathVariable Long id) {
		System.out.println(id);
		return contractService.searchById(id);
	}

	/*
	 * 保存和更新
	 */
	@PutMapping(value = "{id}")
	public ExtAjaxResponse update(@PathVariable Long id, @RequestBody Contract contractdto) {
		System.out.println("upate Contract");
		try {
			ContractAndEmployeeDTO contract = contractService.searchById(id);
			
			if (contract != null) {
				Employee employee=employeeService.findByEmployeeId(contract.getEmployeeId());
				contract.setEmp(employee);
				if(contractdto.getContractSalary()==0){
					double temp=contract.getContractSalary();
					BeanUtils.copyProperties(contractdto, contract);
					contract.setContractSalary(temp);
				}else{
					BeanUtils.copyProperties(contractdto, contract);
				}
				contractService.saveOrUpdate(contract);
				
				//日志
				writeLog("修改");
			}
			return new ExtAjaxResponse(true, "更新成功");
		} catch (Exception e) {
			return new ExtAjaxResponse(false, "更新失败");
		}
	}

	/*
	 * 添加controller
	 */
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ExtAjaxResponse save(@RequestBody ContractAndEmployeeDTO contract) {
		try {
			if (contract.getEmployeeId() != null) {
				System.out.println("SAVE"+contract.getEmployeeId());
				Contract dto=contractService.findByEmployeeId(contract.getEmployeeId());
				//判断是否contract唯一
				if(dto == null){
					System.out.println("合同表中没有该员工ID，可以插入");
					//得到对应的员工
					Employee employee=employeeService.findByEmployeeId(contract.getEmployeeId());
//					//建立联系
					contract.setEmp(employee);
					//保存
					contractService.saveOrUpdate(contract);
					
					//日志
					writeLog("添加");
				}
				else{
					System.out.println("合同表中有该员工ID，拒绝可以插入修改");
					System.out.println(dto.getContractState());
				}

			}
			return new ExtAjaxResponse(true, "保存成功");
		} catch (Exception e) {
			return new ExtAjaxResponse(false, "保存失败");
		}
	}
	/*
	 * 删除单个
	 */

	@DeleteMapping(value="{id}")
	public ExtAjaxResponse delete(@PathVariable Long id){
		try {
			if(id !=null){
				//1-修改状态
				/*Contract contract=contractService.searchById(id).get();
				contract.setContractState("0");
				contractService.saveOrUpdate(contract);*/
				
				//2-直接删除 不推荐				
				contractService.deleteById(id);
				//日志
				writeLog("删除");
			}
			return new ExtAjaxResponse(true, "删除成功");
		} catch (Exception e) {
			return new ExtAjaxResponse(false, "删除失败");
		}
	}
	/*
	 * 删除所有
	 */
	
	@PostMapping("/deletes")
	public ExtAjaxResponse deleteRows(@RequestParam(name="ids") Long[] ids){
		System.out.println("--------批量删除---------");
		try {
			if(ids!=null){
				contractService.deleteAll(ids);
				//日志
				writeLog("批量删除");
			}
			return new ExtAjaxResponse(true, "批量删除成功");
		} catch (Exception e) {
			return new ExtAjaxResponse(false, "批量删除失败");
		}
	}
	
	
	
	//上传图片
	@RequestMapping(value="/importPhoto",method={RequestMethod.POST,RequestMethod.GET})
	public void importPhoto(@RequestParam(name="photo") MultipartFile photo,HttpServletRequest request, HttpServletResponse response) throws IOException{
		System.out.println("Coming 图片上传--------"+photo.getOriginalFilename());
		try {	
				if(photo!=null){
					//获取上传文件的名字
					String fileName=photo.getOriginalFilename();
					//获取上传文件的名字 “.“需要转义字符
					String[] fileParts=photo.getOriginalFilename().split("\\.");
					String filePartsLast=fileParts[1];
					//判断图片格式
					if(filePartsLast.equals("jpg") || filePartsLast.equals("bmp") || filePartsLast.equals("gif") || filePartsLast.equals("png")){
						//截取参数之后剩余的字符串并返回（返回文件名中“.”的索引值），获取上传图片的后缀名
						String Path = System.getProperty("user.dir")+"/src/main/webapp/resources/images/product";
						System.out.println(fileName);
						
						//写入图片方法
						commonUpLoad(Path, photo);
						
						response.getWriter().write("true");
					}else{
						System.out.println("false");
						response.getWriter().write("false");
					}
			}
		} catch (Exception e) {
			response.getWriter().write("false");
		}
	}
	
	
	//上传文件
	//前端传参不到后台
	@RequestMapping(value="/importFile",method={RequestMethod.POST,RequestMethod.GET})
	public void importFile(@RequestParam(name="upfile") MultipartFile upfile,HttpServletRequest request, HttpServletResponse response) throws IOException{
		System.out.println("Coming 图片上传--------"+upfile.getOriginalFilename()+"Size:"+upfile.getSize());
		try {	
			if(upfile!=null){
				//获取上传文件的名字
				String fileName=upfile.getOriginalFilename();
				//获取上传文件的名字 “.“需要转义字符
				String[] fileParts=upfile.getOriginalFilename().split("\\.");
				String filePartsLast=fileParts[1];
				//判断文件格式
				if(filePartsLast.equals("doc") || filePartsLast.equals("txt") || filePartsLast.equals("xls") || filePartsLast.equals("pdf")||filePartsLast.equals("docx")){
					//判断文件大小，设置为0-5M之内 
					//1M=1024Kb 1kb=1024字节 getsize得到的是字节
					
					if(upfile.getSize()>0L && upfile.getSize()<=5242880L){
						String Path = System.getProperty("user.dir")+"/src/main/webapp/resources/images/contract";
						//写入文件方法
						commonUpLoad(Path, upfile);
						
						response.getWriter().write("true");
					}else{
						response.getWriter().write("false");
					}
				}else{
					response.getWriter().write("false");
				}
		}
	} catch (Exception e) {
		response.getWriter().write("false");
	}
		
	}
	
	//重复方法放在一个方法中
	public void commonUpLoad(String Path,MultipartFile file ){
		//截取参数之后剩余的字符串并返回（返回文件名中“.”的索引值），获取上传图片的后缀名
		String fileName=file.getOriginalFilename();
		System.out.println(fileName);
		
		//根据指定存储路径新建file对象
		File flist = new File(Path);
		if(!Path.isEmpty()){
			//检查指定路径下是否有文件夹，没有创建相应文件夹
			flist.mkdir();
		}
		
		//查看指定路径下的文件夹内的文件
		for(File f : flist.listFiles()){
			if(f.getName().contains(fileName)){
				//将指定的文件删除
				f.delete();
			}
		}
		
		//图片上传的路径和上传后的名称+原始后缀名
		File fileFolder = new File(Path,fileName);
		try {
			file.transferTo(fileFolder);
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	//日志方法
		public void writeLog(String operation){
			HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
			HttpSession  session=request.getSession();
			String employeeId=SessionUtil.getEmployeeId(session);
			
			RecordDTO recordDTO = new RecordDTO();
			recordDTO.setEmployeeId(employeeId);
			recordDTO.setRecordContent(operation+" 合同信息成功");
			recordDTO.setRecordTime(new Date());
			recordService.save(recordDTO);

		}
}