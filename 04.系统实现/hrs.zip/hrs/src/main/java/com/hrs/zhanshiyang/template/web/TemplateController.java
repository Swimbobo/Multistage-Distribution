package com.hrs.zhanshiyang.template.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.zhanshiyang.record.domain.RecordDTO;
import com.hrs.zhanshiyang.record.service.IRecordService;
import com.hrs.zhanshiyang.template.domain.TemplateDTO;
import com.hrs.zhanshiyang.template.domain.TemplateQueryDTO;
import com.hrs.zhanshiyang.template.service.ITemplateService;

@RestController
@RequestMapping("/template")
public class TemplateController {
	@Autowired
	private ITemplateService templateService;
	
	@Autowired
	private IRecordService recordService;
	
//	添加
	@PostMapping
	public ExtAjaxResponse save(@RequestBody TemplateDTO dto) 
	{
		try {
			templateService.save(dto);
			writeLog("保存/修改");
			return new ExtAjaxResponse(true,"保存成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"保存失败！");
		}
	}
	
//	根据id删除数据
	@DeleteMapping(value="{id}")
	public ExtAjaxResponse delete(@PathVariable("id") Long id) 
	{
		try {
			if(id!=null) {
				templateService.deleteById(id);
				writeLog("删除");
			}
			return new ExtAjaxResponse(true,"删除成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"删除失败！");
		}
	}
	
//	根据数组id批量删除数据
	@PostMapping("/deletes")
	public ExtAjaxResponse deleteRows(@RequestParam(name="ids") Long[] ids) 
	{
		try {
			List<TemplateDTO> dtoLists = new ArrayList<>();
			for (int i = 0; i < ids.length; i++) {
				Long id = ids[i];
				dtoLists.add(templateService.findById(id));
			}
			if(ids!=null) {
				templateService.deleteAll(dtoLists);
				writeLog("批量删除");
			}
			return new ExtAjaxResponse(true,"批量删除成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"批量删除失败！");
		}
	}
	
	@PostMapping("/release")
	public ExtAjaxResponse release(@RequestParam(name="id") Long id) 
	{
		try {
			TemplateDTO dto = templateService.findById(id);
			System.out.println(dto);
			if(id!=null) {
				templateService.release(dto);
				writeLog("发布");
			}
			return new ExtAjaxResponse(true,"发布成功！");
		} catch (Exception e) {
			return new ExtAjaxResponse(true,"发布失败！");
		}
	}
	
//	根据所需字段搜索分页显示，Postman用Params测试
	@GetMapping
	public Page<TemplateDTO> getPage(TemplateQueryDTO templateQueryDTO , ExtjsPageRequest pageRequest) 
	{
		return templateService.findAll(TemplateQueryDTO.getWhereClause(templateQueryDTO), pageRequest.getPageable());
	}
	
//	日志方法
	public void writeLog(String operation){
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession  session=request.getSession();
		String employeeId=SessionUtil.getEmployeeId(session);
		
		RecordDTO recordDTO = new RecordDTO();
		recordDTO.setEmployeeId(employeeId);
		recordDTO.setRecordContent(operation+" 评估模板信息成功");
		recordDTO.setRecordTime(new Date());
		recordService.save(recordDTO);
	}
}
