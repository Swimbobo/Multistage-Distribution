package com.hrs.lizhuhao.leave.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.lizhuhao.leave.domain.Leave;

@Repository
public interface LeaveDao extends PagingAndSortingRepository<Leave,Long>,JpaSpecificationExecutor<Leave>{}