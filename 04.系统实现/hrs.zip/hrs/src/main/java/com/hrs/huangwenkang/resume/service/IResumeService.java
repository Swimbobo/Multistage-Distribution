package com.hrs.huangwenkang.resume.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.huangwenkang.resume.domain.Resume;
import com.hrs.huangwenkang.resume.domain.ResumeDTO;

public interface IResumeService {
	public Resume save(ResumeDTO dto);			//增加对象
	public void deleteById(Long id);			//通过id删除对象
	public void deleteAll(Long[] ids);			//批量删除
	public ResumeDTO findById(Long id);			//通过id查找对象
	public boolean existsById(Long id);			//通过id判断是否存在对象
	public long count();						//统计表中数据总数
	public void updateResumeStatus(String resumeStatus,Long id);	//修改简历的状态
	public Page<ResumeDTO> findAll(Specification<Resume> spec, Pageable pageable);
}