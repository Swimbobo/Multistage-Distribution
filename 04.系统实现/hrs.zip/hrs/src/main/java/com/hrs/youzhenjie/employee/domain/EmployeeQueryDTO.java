package com.hrs.youzhenjie.employee.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class EmployeeQueryDTO {
	// 查询的参数
	private String employeeId;// 工号

	@JsonFormat(pattern = "yyyy/MM/dd")
	@DateTimeFormat(pattern="yyyy/MM/dd")  
	private Date employeeEntryTime;// 入职日期

	@JsonFormat(pattern = "yyyy/MM/dd")
	@DateTimeFormat(pattern="yyyy/MM/dd")  
	private Date employeeLeaveTime;// 离职日期

	private String employeeDepartment;// 部门
	private String employeePosition;// 职位

	@SuppressWarnings({ "serial" })
	public static Specification<Employee> getWhereClause(final EmployeeQueryDTO employeeQueryDTO) {
		return new Specification<Employee>() {

			@Override
			public Predicate toPredicate(Root<Employee> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
				List<Predicate> predicate = new ArrayList<>();

				if (StringUtils.isNotBlank(employeeQueryDTO.getEmployeeId())) {
					predicate.add(criteriaBuilder.like(root.get("employeeId").as(String.class),
							"%" + employeeQueryDTO.getEmployeeId() + "%"));
				}
				if (null != employeeQueryDTO.getEmployeeEntryTime()) {
					predicate.add(criteriaBuilder.greaterThanOrEqualTo(root.get("employeeEntryTime").as(Date.class),
							employeeQueryDTO.getEmployeeEntryTime()));
				}
				if (null != employeeQueryDTO.getEmployeeLeaveTime()) {
					predicate.add(criteriaBuilder.lessThanOrEqualTo(root.get("employeeLeaveTime").as(Date.class),
							employeeQueryDTO.getEmployeeLeaveTime()));
				}
				if (null != employeeQueryDTO.getEmployeeDepartment()) {
					predicate.add(criteriaBuilder.like(root.get("employeeDepartment").as(String.class),
							"%" + employeeQueryDTO.getEmployeeDepartment() + "%"));
				}
				if (null != employeeQueryDTO.getEmployeePosition()) {
					predicate.add(criteriaBuilder.like(root.get("employeePosition").as(String.class),
							"%" + employeeQueryDTO.getEmployeePosition() + "%"));
				}
				Predicate[] pre = new Predicate[predicate.size()];
				return query.where(predicate.toArray(pre)).getRestriction();
			}
		};

	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public Date getEmployeeEntryTime() {
		return employeeEntryTime;
	}

	public void setEmployeeEntryTime(Date employeeEntryTime) {
		this.employeeEntryTime = employeeEntryTime;
	}

	public Date getEmployeeLeaveTime() {
		return employeeLeaveTime;
	}

	public void setEmployeeLeaveTime(Date employeeLeaveTime) {
		this.employeeLeaveTime = employeeLeaveTime;
	}

	public String getEmployeeDepartment() {
		return employeeDepartment;
	}

	public void setEmployeeDepartment(String employeeDepartment) {
		this.employeeDepartment = employeeDepartment;
	}

	public String getEmployeePosition() {
		return employeePosition;
	}

	public void setEmployeePosition(String employeePosition) {
		this.employeePosition = employeePosition;
	}

}
