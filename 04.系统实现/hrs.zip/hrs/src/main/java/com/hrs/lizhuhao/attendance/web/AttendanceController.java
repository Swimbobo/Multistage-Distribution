package com.hrs.lizhuhao.attendance.web;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.hrs.common.beans.SessionUtil;
import com.hrs.common.web.ExtAjaxResponse;
import com.hrs.common.web.ExtjsPageRequest;
import com.hrs.lizhuhao.attendance.domain.AttendanceDTO;
import com.hrs.lizhuhao.attendance.domain.AttendanceQueryDTO;
import com.hrs.lizhuhao.attendance.service.IAttendanceService;

@RestController
@RequestMapping("/attendance")
public class AttendanceController {
	@Autowired
	private IAttendanceService attendanceService;
	//显示全部数据
	@GetMapping
	public @ResponseBody Page<AttendanceDTO> getPage(AttendanceQueryDTO attendanceQueryDTO , ExtjsPageRequest pageRequest) {
		return attendanceService.findAll(AttendanceQueryDTO.getWhereClause(attendanceQueryDTO), pageRequest.getPageable());
	}
	//显示某条数据（按EmployeeId）
	@GetMapping("/getOne")
	public @ResponseBody Page<AttendanceDTO> getPageByEmployeeId(AttendanceQueryDTO attendanceQueryDTO , ExtjsPageRequest pageRequest) {
		return attendanceService.findAll(AttendanceQueryDTO.getWhereByEmployeeId(attendanceQueryDTO), pageRequest.getPageable());
	}
	//显示某条数据
	@GetMapping("{id}")
	public AttendanceDTO getOne(@PathVariable("id") Long id) {
		return attendanceService.findById(id);
	}
	//增加数据
	@PostMapping("/save")
	public ExtAjaxResponse save() throws ParseException{
		//取session
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession  session=request.getSession();
		String emp=SessionUtil.getEmployeeId(session);
		String empName=SessionUtil.getEmployeeName(session);
		//定义打卡日期attendanceDate和当前时间one
		Date date=new Date();
		SimpleDateFormat dateFormat1=new SimpleDateFormat("yyyy/MM/dd");
		String attendanceDate=dateFormat1.format(date);
		Date sql=dateFormat1.parse(attendanceDate);
		SimpleDateFormat dateFormat2= new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String timeOne=dateFormat2.format(date);
		Date one=dateFormat2.parse(timeOne);
		//根据打卡日期和工号查出数据，无则设置上班时间，有则设置下班时间
		List<AttendanceDTO> dtoList=attendanceService.findByIdDate(emp, attendanceDate);
		if(dtoList.size()==0){
		    //创建一条新记录
			AttendanceDTO dto=new AttendanceDTO();
			dto.setEmployeeId(emp);
			dto.setAttendanceDate(sql);
			dto.setEmployeeName(empName);
			dto.setAttendanceTimeOne(one);
			attendanceService.save(dto);
		}else{
			Date getOne=dtoList.get(0).getAttendanceTimeOne();
			//上下班时间比较
			if(getOne.getTime()<one.getTime()) {
				dtoList.get(0).setAttendanceTimeTwo(one);
				//设置比较变量9点
				SimpleDateFormat sta = new SimpleDateFormat("HH:mm:ss");
			    String str1= "09:00:00";
			    Date start=sta.parse(str1);
			    //设置比较变量18点
			    SimpleDateFormat en = new SimpleDateFormat("HH:mm:ss");
			    String str2 = "18:00:00";
			    Date end=en.parse(str2);
			    //比较有无迟到早退，无则设置考勤状态为出勤
			    if((getOne.getTime()>start.getTime())&&(one.getTime()<end.getTime()))
				{
			    	dtoList.get(0).setAttendanceStatus("出勤");
			    }
				attendanceService.save(dtoList.get(0));
			}
		}
		return new ExtAjaxResponse(true,"打卡成功！");
	}
}