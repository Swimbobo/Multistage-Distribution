package com.hrs.zhanshiyang.bonus.domain;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;

public class BonusDTO {
	private Long id;
	private String employeeId;//员工工号ID
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date bonusYM;//奖金时间（年月）
	private String bonusStyle;//奖金简述
	private BigDecimal bonusSum;//奖金金额
	private String bonusAddName;//录入管理员名字
	private String bonusRemark;//备注
	
	public Long getId() {
		return id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getBonusYM() {
		return bonusYM;
	}
	public String getBonusStyle() {
		return bonusStyle;
	}
	public BigDecimal getBonusSum() {
		return bonusSum;
	}
	public String getBonusAddName() {
		return bonusAddName;
	}	
	public String getBonusRemark() {
		return bonusRemark;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setBonusYM(Date bonusYM) {
		this.bonusYM = bonusYM;
	}
	public void setBonusStyle(String bonusStyle) {
		this.bonusStyle = bonusStyle;
	}
	public void setBonusSum(BigDecimal bonusSum) {
		this.bonusSum = bonusSum;
	}
	public void setBonusAddName(String bonusAddName) {
		this.bonusAddName = bonusAddName;
	}
	public void setBonusRemark(String bonusRemark) {
		this.bonusRemark = bonusRemark;
	}
	
	//前端到后台（接收表单数据）:save 和 update	如何维护关联关系？
	public  static void dto2Entity(BonusDTO dto ,Bonus entity) {
		BeanUtils.copyProperties(dto, entity);	
	}
	//后台到前端（返回JSON数据）：find	显示什么数据？
	public  static void entity2Dto(Bonus entity ,BonusDTO dto) {
		BeanUtils.copyProperties(entity , dto);
	}
	
}
