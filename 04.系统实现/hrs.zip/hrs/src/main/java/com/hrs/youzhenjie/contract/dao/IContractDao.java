package com.hrs.youzhenjie.contract.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.hrs.youzhenjie.contract.domain.Contract;
import com.hrs.youzhenjie.employee.domain.Employee;

@Repository
public interface IContractDao extends PagingAndSortingRepository<Contract, Long>,JpaSpecificationExecutor<Contract>{

	//JPA高级查询
	public Contract findByEmployeeId(String name);
}
