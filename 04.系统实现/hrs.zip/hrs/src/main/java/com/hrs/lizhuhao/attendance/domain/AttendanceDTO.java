package com.hrs.lizhuhao.attendance.domain;

import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrs.common.beans.BeanUtils;

public class AttendanceDTO {
	private Long id;					//id
	private String employeeId;			//工号
	private String employeeName;		//员工姓名
	@DateTimeFormat(pattern="yyyy/MM/dd")
	private Date attendanceDate;		//打卡年月日
	@DateTimeFormat(pattern="yyyy/MM/dd HH:mm:ss")  
	private Date attendanceTimeOne;		//上班打卡时间
	@DateTimeFormat(pattern="yyyy/MM/dd HH:mm:ss")
	private Date attendanceTimeTwo;		//上班打卡时间
	private String attendanceStatus;	//出勤状态
	
	//getters
	public Long getId() {
		return id;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	@JsonFormat(pattern="yyyy/MM/dd",timezone="GMT+8")
	public Date getAttendanceDate() {
		return attendanceDate;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getAttendanceTimeOne() {
		return attendanceTimeOne;
	}
	@JsonFormat(pattern="yyyy/MM/dd HH:mm:ss",timezone="GMT+8")
	public Date getAttendanceTimeTwo() {
		return attendanceTimeTwo;
	}
	public String getAttendanceStatus() {
		return attendanceStatus;
	}
	//setters
	public void setId(Long id) {
		this.id = id;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setAttendanceDate(Date attendanceDate) {
		this.attendanceDate = attendanceDate;
	}
	public void setAttendanceTimeOne(Date attendanceTimeOne) {
		this.attendanceTimeOne = attendanceTimeOne;
	}
	public void setAttendanceTimeTwo(Date attendanceTimeTwo) {
		this.attendanceTimeTwo = attendanceTimeTwo;
	}
	public void setAttendanceStatus(String attendanceStatus) {
		this.attendanceStatus = attendanceStatus;
	}
	//前端到后台（接收表单数据）
	public static void dto2Entity(AttendanceDTO dto ,Attendance entity) {
		BeanUtils.copyProperties(dto, entity);
	}
	//后台到前端（返回JSON数据）
	public  static void entity2Dto(Attendance entity ,AttendanceDTO dto) {
		BeanUtils.copyProperties(entity,dto);
	}	
}