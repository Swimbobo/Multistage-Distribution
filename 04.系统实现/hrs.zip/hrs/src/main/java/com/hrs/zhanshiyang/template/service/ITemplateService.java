package com.hrs.zhanshiyang.template.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.hrs.zhanshiyang.template.domain.Template;
import com.hrs.zhanshiyang.template.domain.TemplateDTO;

public interface ITemplateService 
{
//	CrudRepository接口：
	public void save(TemplateDTO dto);
	public TemplateDTO findById(Long id);
	public List<TemplateDTO> findAllById(List<Long> ids);
	public void deleteById(Long id);
	public void deleteAll(List<TemplateDTO> dtoLists);
//	PagingAndSortingRepository extends CrudRepository接口：
	public Page<TemplateDTO> findAll(Specification<Template> spec, Pageable pageable);
	
//	自定义：
	public void release(TemplateDTO dto);
}
